# Shared Viewer V1 — host update

This adds private shared captions to your working CommsTranslate companion. Friends use a separate native Windows viewer and do not need Discord modifications, an OpenAI account, or a translation key.

## Install on the host

1. Close CommsTranslate and its overlay. Discord can stay open.
2. Extract this ZIP to its own folder in Downloads, separate from your existing application.
3. Run **Apply-Shared-Viewer-V1.cmd** normally. Do not run anything inside `payload`.
4. Start your usual **Start-CommsTranslate.cmd** from the original application folder.

The update finds the original `Downloads\CommsTranslate-0.1.0-source\comms-translate` folder. If yours is elsewhere, drag no files; open a terminal in this patch folder and run:

```cmd
Apply-Shared-Viewer-V1.cmd "D:\Your folder\comms-translate"
```

This requires the working T4 + S1 application. C1 caption controls are optional. The installer checks known versions, backs up changed files, and verifies the result. It does not install dependencies, rebuild Vencord, reinstall Electron, or change your models, GPU runtime, account data, settings, or other plugins.

## Use shared captions

A relay service must be available at a secure `https://` origin (the apps use WSS for streaming). This release supplies the relay software; it does not deploy or pay for a server automatically. The relay administrator runs its `provision` command to create your private `.commshost` host setup file.

1. In the companion, choose **Manage viewers**, then **Viewer connections → Import host setup**, and select your `.commshost` file. Keep that file private.
2. Enter a friend's name and choose **Add viewer & save setup**. Send that friend's `.commsviewer` file privately to them.
3. Your friend extracts the separate viewer ZIP, runs `CommsViewer.exe`, and chooses **Import .commsviewer setup file**. They only need to import it once.
4. Start your usual Discord captions, then choose **Share captions** in the companion. The friend's viewer automatically receives the reading-language captions while sharing is on. Choose **Stop sharing** to end it.

Give each friend their own setup file. **Remove** revokes that viewer's access; **Save setup** exports its file again. Each viewer receives the host's published reading language. The host still does transcription and translation.
The relay forwards encrypted caption messages; it does not translate them. Read the included protocol and relay documentation before operating a public relay. Verify end-to-end use with a friend before relying on it for a session.

## If the patch stops

Read the printed reason and send `diagnostics\CommsTranslate-Sharing-V1-*.txt`. Do not rerun full setup or delete dependencies. Unknown edits are preserved.

Backups are under the original project's `sharing-v1-backups` folder. To restore a specific patch transaction while the companion is closed:

```cmd
Apply-Shared-Viewer-V1.cmd --rollback "C:\full\project\sharing-v1-backups\timestamp\recovery.json"
```

Restoration refuses to overwrite files changed since the patch. Keep this extracted patch and its manifest for recovery. If a prior update was interrupted, its lock/recovery record must be resolved first; the installer does not remove another updater's locks.

## Validation boundary

See `VALIDATION.md` for the checks performed. A Linux cross-build is not a Windows runtime test. The installer reports file installation, not successful sharing, live audio, account access, or firewall/server configuration.
