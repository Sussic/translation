# Shared captions V1

The existing companion remains the only transcription and translation host. A separate native Windows viewer receives the host's reading-language captions. Adding viewers creates no additional AI requests and does not share the host's AI account.

## Components

| Component | Role |
| --- | --- |
| Companion sharing controls | Import relay setup, pair/revoke viewers, explicitly start/stop publishing |
| `packages/companion/src/sharing` | Protected pairing storage, safe caption projection, encrypted publisher |
| `packages/sharing-protocol` | Strict wire format, bounds, Node cryptography and cross-language test vectors |
| `packages/relay` | Hash-only credential registry and bounded encrypted-message forwarding |
| `viewer` | Self-contained Windows x64 WPF receiver, overlay and portable protocol tests |

The host update ships a bundled publisher module. Applying it does not install dependencies or rebuild Electron, speech workers or Vencord. The additive capture identity in the voice pipeline lets publishing distinguish a normal pause/resume from a different capture session; transcription and translation algorithms are unchanged.

## First use

1. Deploy the relay using `packages/relay/README.md`. Its provisioning command creates a private `.commshost` file for the host only.
2. In the companion, open **Manage viewers**, then **Import host setup**. Enter a friend's name and use **Add viewer & save setup**.
3. Send that friend's `.commsviewer` file privately. They extract the entire viewer ZIP, start `CommsViewer.exe`, and import the file. Make a separate pairing for each friend.
4. Start normal Discord captions, then choose **Share captions**. Pairings persist; sharing permission does not persist across a new capture session or companion restart.
5. Friends can leave the viewer running. It clears captions when sharing ends or the connection is lost. Its optional **Start with Windows** setting is off by default.

The relay is an additional reachable service; the release packages do not deploy it or provide a server address. Both sides make outbound secure connections. The local Discord broker remains local.

## Overlay

Run `CommsViewer.exe --demo` to try static sample text without a relay. Drag its header, resize its edges, then select **Lock**. **Ctrl+Shift+F8** toggles adjustment and click-through. Settings can change the shortcut. A shortcut conflict keeps the overlay interactive.

The tray menu provides **Adjust overlay**, **Recover overlay**, show/hide, settings and exit. Starting the EXE again recovers the existing window. Explicit adjustment remains visible while disconnected; incoming captions do not take keyboard focus. Use windowed or borderless games. Exclusive fullscreen is outside this version's overlay guarantee.

## Data and limits

Only safe reading-language display rows are projected for sharing. Original-language details, audio, model prompts, account information, diagnostics and local RPC commands are not forwarded. Draft translations may still change; sharing does not improve recognition or translation accuracy.

Each viewer has independent relay credentials and a caption encryption secret. The relay stores credential hashes and revocation metadata, not caption keys or history. Host credentials use the existing OS-backed encryption adapter; viewer credentials use Windows CurrentUser protection. Exported setup files are bearer credentials, so keep them private. Removing a viewer prevents future access; it cannot erase text already seen.

The view contains at most two caption rows, updates previews at most four times per second, and sends final/clear transitions promptly. It bounds frames at 8 KiB and pending output at 32 KiB per recipient. Slow recipients are disconnected instead of receiving a growing backlog. The host supports up to 20 paired viewers. Caption expiry and authenticated liveness are independent; a transport heartbeat cannot keep stale captions alive.

## Verification and release boundary

Run the root build, typecheck and test scripts for the JavaScript components. The viewer README documents portable .NET tests, the real TLS relay integration harness, and the Windows publish command. The release's `validation-summary.json` records completed checks and untested areas.

Linux builds and socket tests do not verify native Windows input, mixed-DPI monitors, game interaction, CPU/RAM use, public relay deployment or a real remote friend session. Complete the viewer's native acceptance checklist before treating those behaviours or resource targets as measured.

The host patch contains verified backups and rollback instructions. If it rejects an unknown file version, preserve the installation and use its diagnostic report; rerunning the full dependency installer is unnecessary.
