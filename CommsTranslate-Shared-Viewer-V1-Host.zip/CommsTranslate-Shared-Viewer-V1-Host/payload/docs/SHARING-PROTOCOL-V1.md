# CommsTranslate sharing protocol V1

Frozen wire contract for `@comms/sharing` 0.1.0 and the native viewer. This is separate from the local companion broker. Viewer traffic cannot invoke translation, capture, settings, account or glossary methods. The protocol contains only a current translated display and connection state; no source transcripts, audio, diagnostics or account tokens.

## Encoding and limits

Every WebSocket application message is one UTF-8 JSON object. Binary WebSocket messages and compression are not used. Invalid UTF-8, duplicate object members, unknown fields, unsupported versions, noncanonical encodings and invalid types are rejected. JSON property order is immaterial. JSON nesting is limited to 16 levels.

| Limit | Value |
|---|---:|
| Encoded application frame, including JSON envelope | 8,192 UTF-8 bytes |
| Viewer and relay control frame | 1,024 UTF-8 bytes |
| Imported setup file | 4,096 UTF-8 bytes |
| Pending output per viewer | 32,768 encoded bytes |
| Provisioned viewers per host | 20 |
| Rows in a complete view | 2 |
| Text per row | 2,048 UTF-8 bytes |
| Remaining row lifetime | Integer 1–15,000 ms |
| Minimum interval between viewer handshakes | 1,000 ms |
| Minimum permitted probe interval | 1,000 ms |
| Active liveness probe interval / expiry | Approximately 3,000 / 9,000 ms |
| Sharing-off keepalive interval | Approximately 30,000 ms |

Identifiers (`hostId`, `viewerId`, `connectionId`, `broadcastId`, row `id`) encode 16 random bytes as canonical unpadded base64url: 22 ASCII characters. Credentials, caption secrets, connection salts and challenges encode 32 random bytes in the same format: 43 characters. GCM tags encode 16 bytes. The ciphertext field is canonical, nonempty base64url. Never accept padding, standard-base64 `+`/`/`, unused-bit alternatives or embedded whitespace.

Revisions are JSON integers from 0 through 9,007,199,254,740,991. Connection sequences are **decimal strings**, 1 through 18,446,744,073,709,551,615, without leading zeros. They must not pass through an IEEE-754 number conversion. Plain text must contain valid Unicode scalars. C0 controls other than tab, carriage return and newline, and DEL, are disallowed. Text is rendered literally, never as HTML/Markdown.

The final encoded-frame limit is authoritative even when individual text limits pass: JSON escaping can expand strings. An oversized legitimate view becomes an empty `unavailable` view with a new revision. Do not byte-truncate text or silently label a clipped sentence complete. No outbound queue may accumulate a transcript backlog; replace obsolete queued complete views or disconnect that viewer. Queue and connection limits are independently enforced by relay and host.

## Setup files and endpoints

A `.commsviewer` file has exactly these fields:

```json
{"format":"CommsTranslateViewer","version":1,"relayUrl":"https://captions.example.test","hostId":"<id>","viewerId":"<id>","hostName":"Example host","viewerName":"Example viewer","viewerToken":"<32-byte credential>","captionSecret":"<32-byte encryption secret>"}
```

A host `.commshost` provisioning file has exactly these fields:

```json
{"format":"CommsTranslateHost","version":1,"relayUrl":"https://captions.example.test","hostId":"<id>","hostName":"Example host","publisherToken":"<32-byte credential>"}
```

Names contain 1–80 Unicode scalars, at most 320 UTF-8 bytes, no tab/newline, and at least one non-whitespace character. Credentials are separate random values: viewer relay credentials are not caption secrets or publisher credentials. Store imported secrets with OS-backed encryption, not plaintext settings. Exported files are private bearer transfer artifacts, not public downloads. No credential goes in a query string, log, error, renderer state or exception text.

`relayUrl` is an HTTPS origin, with an optional root `/` only. Credentials, other paths, queries and fragments are forbidden. WebSocket URLs are derived using WSS, with the same host and port. No redirects to a different origin may carry credentials. For explicit local tests only, parsers accept `allowInsecureLoopback:true`, enabling HTTP/WS at `localhost`, `127.0.0.1` or `[::1]`. Production imports do not enable that option; all other insecure hosts remain rejected.

| Method / route | Role / body |
|---|---|
| `POST /v1/hosts/{hostId}/viewers` | Publisher Bearer credential; exact body `{ "viewerId": "<id>", "viewerToken": "<credential>" }`; response `{ "v": 1, "viewerId": "<id>" }` |
| `DELETE /v1/hosts/{hostId}/viewers/{viewerId}` | Publisher Bearer credential; response 204 |
| WebSocket `/v1/hosts/{hostId}/publisher` | Publisher Bearer credential |
| WebSocket `/v1/hosts/{hostId}/viewers/{viewerId}` | That viewer's Bearer credential |

Host provisioning is an administrative relay operation outside viewer traffic. The relay persists credential hashes and revocation state, not caption secrets, ciphertext history or plaintext captions. Registration never accepts caption secrets. Removing a viewer first disables its host-side delivery, then revokes the relay credential. A temporary relay failure cannot cause the host to continue encrypting for a removed identity.

## Relay controls and viewer requests

All objects below include exact `v:1`. A new viewer socket receives `{v:1,type:"connected",connectionId}`. The relay assigns a fresh 16-byte `connectionId`, and informs the publisher with `{v:1,type:"viewer-connected",viewerId,connectionId}`. Disconnection uses `type:"viewer-disconnected"` with the same fields. Frames for a displaced connection ID must not be routed to its replacement.

Additional relay-to-viewer messages have exactly `v` and `type`:

- `publisher-ready`: clear the old connection key/display, generate a fresh hello challenge and handshake again. This also applies when the publisher reconnects while the viewer socket remains open.
- `host-offline`: clear real captions and wait. This is not authenticated caption state and cannot show content.
- `replaced`: another connection used this identity; stop automatic reconnect until explicit user action.

Close codes: 4400 invalid protocol, 4401 unauthorized, 4403 revoked, 4409 replaced, 4413 slow consumer. Authentication errors/revocation/replacement are terminal for automatic retries. Ordinary network failures retry with jittered delays around 1, 2, 5, 10, then 30 seconds. Reconnect begins blank.

Viewer-to-host hello:

```json
{"v":1,"type":"hello","hostId":"<id>","viewerId":"<id>","connectionId":"<id>","challenge":"<fresh 32 bytes>"}
```

Viewer-to-host liveness/current-view request:

```json
{"v":1,"type":"probe","hostId":"<id>","viewerId":"<id>","connectionId":"<id>","challenge":"<fresh 32 bytes>","requestView":false}
```

The relay authenticates the role and checks routing fields against the actual socket before forwarding. Host and relay both enforce one hello attempt per second, one outstanding probe and bounded request rates, **before** key derivation or encryption. They do not accept arbitrary strings, relay-provided publisher instructions or companion RPC. The probe challenge differs from the connection's hello challenge. `requestView:true` requests a complete authenticated view instead of a status-only reply; it cannot request historical captions.

## Connection encryption

The publisher creates a fresh random 32-byte salt for each accepted fresh hello. It uses that device's unique caption secret. The relay's connection ID is a routing binding, not a secret. Derive one host-to-viewer AES-256 key per hello:

```text
key = HKDF-SHA256(ikm=captionSecretRaw32, salt=connectionSaltRaw32,
                 info=infoBytes86, outputLength=32)
```

`infoBytes86`, concatenated in this exact order:

| Offset | Length | Bytes |
|---:|---:|---|
| 0 | 4 | ASCII `CTSV`: `43 54 53 56` |
| 4 | 1 | Protocol version `01` |
| 5 | 1 | Direction, host to viewer: `01` |
| 6 | 16 | Decoded host ID |
| 22 | 16 | Decoded viewer ID |
| 38 | 16 | Decoded relay connection ID |
| 54 | 32 | Decoded fresh viewer hello challenge |

Every encrypted payload increments the same connection-wide sequence, including views, status replies, pauses, sharing-off and new broadcasts. The sequence never resets for a new broadcast. Nonce = four zero bytes followed by the sequence as an unsigned 64-bit big-endian integer, giving 12 bytes. GCM tag length is 16 bytes. Exhaustion requires a fresh handshake/key; failed encryption attempts burn their sequence number.

Encrypted envelope:

```json
{"v":1,"type":"sealed","hostId":"<id>","viewerId":"<id>","connectionId":"<id>","challenge":"<hello challenge>","salt":"<connection salt>","seq":"1","replyTo":null,"ciphertext":"<base64url>","tag":"<base64url16>"}
```

`challenge` always means the hello challenge. `replyTo` is null for unsolicited views or the probe challenge for a reply. The relay can clear its outstanding-probe slot only when `replyTo` matches it. That field is authenticated; it is not a second unauthenticated liveness signal.

AES-GCM AAD is exactly 159 bytes, never JSON:

| Offset | Length | Bytes |
|---:|---:|---|
| 0 | 86 | `infoBytes86` above |
| 86 | 32 | Decoded connection salt |
| 118 | 8 | Unsigned sequence, big-endian |
| 126 | 1 | `00` if `replyTo:null`, otherwise `01` |
| 127 | 32 | All zero if null, otherwise decoded `replyTo` challenge |

Plaintext is the UTF-8 JSON payload below. On receipt, validate header shape, size, routing, expected fresh hello challenge and sequence; verify GCM; validate plaintext shape and `payload.probe === envelope.replyTo`; only then commit the salt/key/sequence and display state. The first accepted message must be a complete view with `probe:null`. Pin its salt; subsequent messages cannot change it without a fresh handshake. Reject duplicate or lower sequences; a gap is allowed because views are complete. Bad tags or malformed payloads must not advance the accepted sequence. The protocol protects against replay/tampering across viewers and connections, not against a viewer modifying their own app or redistributing captions they already received.

## Authenticated payloads

Complete view, exact fields:

```json
{"kind":"view","probe":null,"status":"sharing","broadcastId":"<id>","viewRevision":1,"outputLanguage":"en","rows":[{"id":"<id>","revision":1,"text":"Hold position.","remainingMs":15000,"provisional":false}]}
```

Status reply, exact fields:

```json
{"kind":"status","probe":"<probe challenge>","status":"sharing","broadcastId":"<id>","viewRevision":1}
```

Statuses are `off`, `sharing`, `paused`, `unavailable`. Off requires `broadcastId:null` and no rows. Every other status requires a nonnull broadcast ID. Only `sharing` can contain rows. `outputLanguage` uses the existing application's exact code shape: 2–3 lowercase ASCII letters, optionally followed by one hyphen and 2–8 ASCII letters or digits (`^[a-z]{2,3}(?:-[A-Za-z0-9]{2,8})?$`). Preserve its spelling, including regional/script suffix case; examples include `en`, `pol`, `en-US`, `zh-CN` and `zh-Hant`. This matches accepted app settings rather than attempting to validate every BCP 47 form. A status reply always has a nonnull probe; a view reply echoes its probe, while an unsolicited or initial view has null.

Display revision changes whenever actual display state changes, including status, language, row removal or correction. Heartbeats and the passage of time do not alone increment it. Row revisions change when that row's text/finality changes. A newer connection sequence with unchanged display revision does not justify rerendering or refreshing row lifetimes. Changed state at the same revision is invalid. Within a broadcast, display revisions and per-row revisions cannot go backwards.

Views replace the current display atomically; they never append fragments. On receipt, set each new row's monotonic expiry to now + remainingMs. For an unchanged row/revision retain `min(existingExpiry, now + remainingMs)`, so resync/heartbeats cannot keep an old row alive. Omit expired rows from reconnection snapshots. At expiry clear that row once; no continuous redraw timer. Display at most the newest two usable blocks, independently of local geometry/clipping.

Off retires the previous broadcast ID, immediately clears real captions and hides normal reading mode. A subsequent active view must use a new broadcast ID. Pause clears rows but may keep the current broadcast and resume it. A status/language/broadcast change must clear stale content before replacement. Never revive a retired broadcast even with a higher connection sequence. Keep at most 256 retired IDs per connection, then reconnect with a fresh challenge/key; no unbounded retired-history collection is needed. Reconnect starts with no caption history.

Only a timely response to a fresh outstanding probe renews an active nine-second liveness lease. Its status/broadcast/revision must agree with the displayed state. A mismatch clears content immediately and requests a complete view once at least 1,000 ms has elapsed since the previous probe send; it does not bypass the minimum probe interval. A matching `requestView` response both supplies current state and acknowledges the probe. An authenticated off status clears immediately even when its revision differs. A replayed caption or unsolicited fresh view cannot renew liveness. The initial handshake view grants an initial nine-second lease. While off, use slower keepalive; if sharing starts after that lease would have expired, request fresh current state immediately and wait for its matched response before displaying. Use monotonic time for probes, deadlines and retry intervals.

Explicit local Adjust/Recover mode is independent of remote visibility: connection loss clears real text but must not hide editing controls or prevent local recovery.

## Interoperability and implementation boundary

`packages/sharing-protocol/fixtures/v1-vectors.json` contains public synthetic fixtures: setup examples, raw expected HKDF info/key, exact plaintext UTF-8 hex, AAD, nonce, envelope and sequences covering a new broadcast without counter reset. These are test credentials only. Both Node and C# tests consume them. Separate nonce vectors include values beyond 32 bits and the unsigned 64-bit maximum.

The package validates wire shapes and performs connection crypto. The host owns safe caption projection, authorization lifecycle, rate limiting, expiry and coalescing. The relay owns credential persistence, role isolation, socket routing and bounded queues. The viewer owns retired-broadcast checks, revision consistency, outstanding challenges, monotonic expiry and native UI. Passing schema/crypto validation is necessary, not sufficient, to display a message.
