// Passive startup checks. Never import Electron or execute a dependency installer.
import fs from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import {execFile} from 'node:child_process';

export const ELECTRON_PIN = '44.5.1';
export const RUNTIME_OVERRIDES = Object.freeze(['ELECTRON_OVERRIDE_DIST_PATH','ELECTRON_INSTALL_ARCH','ELECTRON_INSTALL_PLATFORM','npm_config_arch','npm_config_platform','ELECTRON_SKIP_BINARY_DOWNLOAD']);
export const REQUIRED_ELECTRON_FILES = Object.freeze(['electron.exe','d3dcompiler_47.dll','resources.pak','icudtl.dat']);
const COMPILED_FILES = ['packages/companion/dist/core/sharingUi.js','packages/companion/dist/sharing/service.js','packages/companion/ui/sharing-ui.js','packages/companion/dist/main.js','packages/companion/dist/preload.cjs','packages/companion/dist/core/broker.js','packages/companion/dist/core/paths.js','packages/companion/dist/core/startup.js','packages/companion/dist/core/accountStatus.js','packages/companion/dist/core/draftMatching.js','packages/shared/dist/index.js','packages/shared/dist/bridgeProtection.js','packages/shared/dist/bridgeProtectionProcess.js','packages/shared/dist/bridgeProtectionPublisher.js','vendor/siwc-local/dist/index.js','packages/companion/ui/index.html','packages/companion/ui/startup.js','packages/companion/ui/live-state.js','packages/companion/ui/overlay.js','packages/companion/ui/app.js','packages/companion/ui/overlay.html','packages/companion/ui/styles.css'];

export function supportedNode(version,arch) {
    const match = /^(\d+)\.(\d+)\.(\d+)$/.exec(String(version));
    return arch === 'x64' && !!match && (+match[1] > 22 || (+match[1] === 22 && +match[2] >= 18));
}
export async function readJsonBounded(file,maxBytes = 1048576) {
    const stat = await fs.stat(file);
    if (!stat.isFile() || stat.size > maxBytes) throw new Error('BOUNDED_METADATA_UNAVAILABLE');
    return JSON.parse((await fs.readFile(file,'utf8')).replace(/^\uFEFF/,''));
}
export function sanitizedPath(value,env = process.env) {
    let text = String(value);
    for (const profile of [env.USERPROFILE,env.HOME,env.LOCALAPPDATA].filter(Boolean).sort((a,b) => b.length-a.length)) {
        text = text.replace(new RegExp(profile.replace(/[.*+?^${}()|[\]\\]/g,'\\$&'),'gi'),'%USERPROFILE%');
    }
    return text.replace(/[A-Z]:\\Users\\[^\\/\r\n]+/gi,'%USERPROFILE%');
}
export function childEnvironment(env = process.env) {
    const result = {...env};
    for (const name of ['NODE_OPTIONS','NODE_PATH','ELECTRON_RUN_AS_NODE']) delete result[name];
    return result;
}
function invokeProbe(executable,args,env,maxBuffer = 4096) {
    return new Promise((resolve,reject) => execFile(executable,args,{shell:false,windowsHide:true,timeout:5000,maxBuffer,env:childEnvironment(env),encoding:'utf8'},(error,stdout) => error ? reject(error) : resolve(stdout)));
}
export async function chooseNode({env = process.env,current = process.execPath,version = process.versions.node,arch = process.arch,probe = invokeProbe} = {}) {
    // A verified running Node is sufficient for launch. Re-selecting a saved
    // junction/shim can otherwise re-exec forever when execPath is its target.
    if (supportedNode(version,arch)) return current;
    const candidates = [];
    if (env.LOCALAPPDATA) {
        try { const saved = await readJsonBounded(path.join(env.LOCALAPPDATA,'CommsTranslate','setup-tools.json'),32768); if (typeof saved.nodeExe === 'string') candidates.push(saved.nodeExe); } catch { }
    }
    candidates.push(current);
    if (env.ProgramFiles) candidates.push(path.join(env.ProgramFiles,'nodejs','node.exe'));
    for (const directory of String(env.PATH ?? '').split(path.delimiter).slice(0,100)) if (directory) candidates.push(path.join(directory,'node.exe'));
    for (const candidate of [...new Set(candidates)]) {
        if (path.basename(candidate).toLowerCase() !== 'node.exe') continue;
        if (path.resolve(candidate).toLowerCase() === path.resolve(current).toLowerCase()) {
            if (supportedNode(version,arch)) return current;
            continue;
        }
        try {
            if (!(await fs.stat(candidate)).isFile()) continue;
            const result = JSON.parse((await probe(candidate,['-p','JSON.stringify({version:process.versions.node,arch:process.arch})'],env)).trim());
            if (supportedNode(result.version,result.arch)) return candidate;
        } catch { }
    }
    return null;
}
export async function checkElevation({env = process.env,platform = process.platform,probe = invokeProbe} = {}) {
    if (platform !== 'win32') return {known:false,elevated:null};
    try {
        const output = await probe(path.join(env.SystemRoot ?? 'C:\\Windows','System32','whoami.exe'),['/groups','/fo','csv','/nh'],env,262144);
        const levels = [...output.matchAll(/S-1-16-(\d+)/g)].map(match => +match[1]);
        return {known:levels.length > 0,elevated:levels.length ? Math.max(...levels) >= 12288 : null};
    } catch { return {known:false,elevated:null}; }
}
async function projectTarget(root,relative) {
    const target = path.join(root,...relative.split('/'));
    const realRoot = await fs.realpath(root),realTarget = await fs.realpath(target);
    const inside = path.relative(realRoot,realTarget);
    if (inside === '..' || inside.startsWith('..' + path.sep) || path.isAbsolute(inside)) throw new Error('PROJECT_PATH_OUTSIDE');
    return target;
}
async function projectJson(root,relative) { return readJsonBounded(await projectTarget(root,relative)); }
export async function inspectFile(root,relative,{pe = false} = {}) {
    const result = {file:relative,exists:false,readable:false,nonempty:false,contained:false,x64Pe:pe ? false : null};
    let handle;
    try {
        const target = await projectTarget(root,relative); result.contained = true;
        const stat = await fs.stat(target);
        if (!stat.isFile()) return result;
        result.exists = true; result.nonempty = stat.size > 0;
        handle = await fs.open(target,'r');
        const head = Buffer.alloc(64); await handle.read(head,0,64,0); result.readable = true;
        if (pe && stat.size >= 256 && head.readUInt16LE(0) === 0x5a4d) {
            const offset = head.readUInt32LE(60);
            if (offset >= 64 && offset <= 8388608 && offset + 6 <= stat.size) {
                const header = Buffer.alloc(6); await handle.read(header,0,6,offset);
                result.x64Pe = header.readUInt32LE(0) === 0x4550 && header.readUInt16LE(4) === 0x8664;
            }
        }
    } catch { }
    finally { await handle?.close().catch(() => {}); }
    return result;
}
async function exactMarker(file,expected,leadingV = false) {
    try { const stat = await fs.stat(file); if (!stat.isFile() || stat.size > 128) return false; let value = await fs.readFile(file,'utf8'); if (leadingV) value = value.replace(/^v/,''); return value === expected; } catch { return false; }
}
export async function inspectRuntime(root,{env = process.env,platform = process.platform,arch = process.arch,nodeVersion = process.versions.node,release = os.release()} = {}) {
    const checks = [],issues = [],overrideNames = RUNTIME_OVERRIDES.filter(name => typeof env[name] === 'string' && env[name].trim());
    const build = /^(\d+)\.(\d+)\.(\d+)/.exec(String(release));
    if (platform !== 'win32' || arch !== 'x64' || !build || +build[3] < 22000) issues.push('WINDOWS_11_X64_REQUIRED');
    if (!supportedNode(nodeVersion,arch)) issues.push('NODE_UNSUPPORTED');
    if (overrideNames.length) issues.push('ELECTRON_OVERRIDE_UNSUPPORTED');
    let pinVerified = false;
    try {
        const project = await projectJson(root,'package.json');
        const companion = await projectJson(root,'packages/companion/package.json');
        const installed = await projectJson(root,'node_modules/electron/package.json');
        const lock = await projectJson(root,'package-lock.json');
        pinVerified = project.name === 'comms-translate' && companion.name === '@comms/companion' && companion.main === 'dist/main.js' && companion.devDependencies?.electron === ELECTRON_PIN && installed.name === 'electron' && installed.version === ELECTRON_PIN && lock.packages?.['node_modules/electron']?.version === ELECTRON_PIN;
    } catch { }
    if (!pinVerified) issues.push('ELECTRON_PIN_UNVERIFIED');
    try { if (!await exactMarker(await projectTarget(root,'node_modules/electron/path.txt'),'electron.exe')) issues.push('ELECTRON_PATH_MARKER_INVALID'); } catch { issues.push('ELECTRON_PATH_MARKER_INVALID'); }
    try { if (!await exactMarker(await projectTarget(root,'node_modules/electron/dist/version'),ELECTRON_PIN,true)) issues.push('ELECTRON_VERSION_MARKER_INVALID'); } catch { issues.push('ELECTRON_VERSION_MARKER_INVALID'); }
    for (const name of REQUIRED_ELECTRON_FILES) checks.push(await inspectFile(root,'node_modules/electron/dist/' + name,{pe:name === 'electron.exe'}));
    for (const name of ['CommsBridge.exe','comms-capture.exe']) checks.push(await inspectFile(root,'workers/build/bin/' + name,{pe:true}));
    for (const file of COMPILED_FILES) checks.push(await inspectFile(root,file));
    for (const check of checks) if (!check.exists || !check.readable || !check.nonempty || check.x64Pe === false) issues.push('FILE_NOT_READY:' + check.file);
    return {ready:issues.length === 0,pin:ELECTRON_PIN,pinVerified,overrideNames,issues,checks,executable:path.join(root,'node_modules','electron','dist','electron.exe'),appDirectory:path.join(root,'packages','companion')};
}
