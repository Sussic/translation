"use strict";
(() => {
    const $ = id => document.getElementById(id);
    if (!$("sharing-toggle") || !window.comms) return;
    let status = null, busy = false, stopping = false, generation = 0, refreshing = false, refreshAgain = false;
    const rows = new Map();
    const message = (text, error = false) => {
        $("sharing-result").textContent = text;
        $("sharing-result").hidden = !text;
        $("sharing-result").classList.toggle("inline-error", error);
    };
    async function rpc(method, params = {}) {
        const result = await window.comms.invoke(method, params);
        if (result?.ok === false) throw new Error(result.error?.message || "Sharing operation failed.");
        return result?.ok === true ? result.result : result;
    }
    function render() {
        const enabled = status?.enabled === true;
        const viewers = Array.isArray(status?.viewers) ? status.viewers : [];
        const connected = viewers.filter(viewer => viewer.connected).length;
        $("sharing-toggle").textContent = enabled ? "Stop sharing" : "Share captions";
        $("sharing-toggle").setAttribute("aria-pressed", String(enabled));
        $("sharing-toggle").classList.toggle("primary", enabled);
        $("sharing-toggle").disabled = stopping || !status || (!enabled && (busy || !status.configured || !status.canStart));
        $("sharing-status").textContent = !status ? "Sharing unavailable" : status.error?.message
            ? status.error.message : enabled ? `${status.connected ? "Sharing" : "Reconnecting"} ${status.targetLanguage || "captions"} · ${connected} viewer${connected === 1 ? "" : "s"}`
            : !status.configured ? "Set up a relay to share with friends" : "Sharing off";
        $("sharing-relay").textContent = status?.configured
            ? `${status.hostName || "Your captions"} · ${status.relayUrl || "Relay configured"}${status.connected ? " · connected" : " · reconnecting"}`
            : "Import the host setup file created when your relay is deployed.";
        $("sharing-import").disabled = busy || enabled;
        $("sharing-refresh").disabled = busy;
        $("sharing-add").disabled = busy || !status?.configured || viewers.length >= 20;
        $("sharing-viewer-name").disabled = busy || !status?.configured;
        const ids = new Set(viewers.map(viewer => viewer.viewerId));
        for (const [id, row] of rows) if (!ids.has(id)) { row.node.remove(); rows.delete(id); }
        for (const viewer of viewers) {
            let row = rows.get(viewer.viewerId);
            if (!row) {
                const node = document.createElement("li"), text = document.createElement("span"), actions = document.createElement("div");
                actions.className = "actions";
                const save = document.createElement("button"), remove = document.createElement("button");
                save.type = remove.type = "button"; save.textContent = "Save setup"; remove.textContent = "Remove"; remove.className = "text-button";
                save.addEventListener("click", () => act(async () => {
                    const result = await rpc("sharing.viewer.export", { viewerId: viewer.viewerId });
                    message(result.saved ? "Viewer setup saved. Send it privately to that friend." : "Save cancelled.");
                }));
                remove.addEventListener("click", () => act(async () => {
                    const result = await rpc("sharing.viewer.remove", { viewerId: viewer.viewerId });
                    message(result.removed ? "Viewer access removed." : "Removal cancelled.");
                }));
                actions.append(save, remove); node.append(text, actions); $("sharing-viewers").append(node);
                row = { node, text, save, remove }; rows.set(viewer.viewerId, row);
            }
            row.text.textContent = `${viewer.name || viewer.viewerName || "Viewer"} · ${viewer.connected ? "connected" : "offline"}`;
            row.save.disabled = row.remove.disabled = busy;
        }
        $("sharing-empty").hidden = viewers.length > 0;
    }
    async function refresh() {
        if (refreshing) { refreshAgain = true; return; }
        refreshing = true;
        const before = generation;
        try { const next = await rpc("sharing.status"); if (before === generation) { status = next; render(); } }
        catch (error) { if (before === generation) { status = null; render(); message(error.message, true); } }
        finally { refreshing = false; if (refreshAgain) { refreshAgain = false; void refresh(); } }
    }
    async function act(action) {
        if (busy) return;
        busy = true; generation++; render(); message("");
        try { await action(); }
        catch (error) { message(error.message || "Sharing operation failed.", true); }
        finally { busy = false; render(); void refresh(); }
    }
    $("sharing-toggle").addEventListener("click", async () => {
        if (!status?.enabled) { await act(async () => { await rpc("sharing.start"); }); return; }
        if (stopping) return;
        stopping = true; generation++; render();
        try { await rpc("sharing.stop"); }
        catch (error) { message(error.message || "Could not stop sharing.", true); }
        finally { stopping = false; render(); void refresh(); }
    });
    $("sharing-import").addEventListener("click", () => act(async () => {
        const result = await rpc("sharing.import");
        message(result.imported ? "Relay configured. Add a viewer below to create their setup file." : "Import cancelled.");
    }));
    $("sharing-refresh").addEventListener("click", () => act(async () => {
        await rpc("sharing.reconnect");
    }));
    $("sharing-manage").addEventListener("click", () => {
        $("sharing-details").open = true; $("sharing-details").scrollIntoView({ block: "nearest" }); void refresh();
    });
    $("sharing-add-form").addEventListener("submit", event => {
        event.preventDefault();
        const name = $("sharing-viewer-name").value.trim();
        if (!name) return;
        void act(async () => {
            const result = await rpc("sharing.viewer.add", { name });
            if (result.saved) $("sharing-viewer-name").value = "";
            message(result.saved ? "Viewer added and setup saved. Send it privately to that friend." : "Save cancelled.");
        });
    });
    window.comms.subscribe(event => {
        if (event?.type === "sharing") { generation++; status = event.status; render(); }
        else if (event?.type === "status") void refresh();
    });
    window.addEventListener("focus", () => { void refresh(); });
    void refresh();
})();
