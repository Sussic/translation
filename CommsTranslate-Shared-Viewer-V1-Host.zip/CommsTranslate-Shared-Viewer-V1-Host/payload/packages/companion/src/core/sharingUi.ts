import { ProtocolError } from '@comms/shared';
import { HostSharingError } from '../sharing/service.js';

export interface SharingVoiceState {
    active: boolean; starting?: boolean; paused?: boolean;
    sessionId?: string; captureId?: string; channelId?: string; sourceId?: string; targetLanguage?: string;
}
export interface SharingUiService {
    getStatus(): unknown;
    syncVoiceState(value: SharingVoiceState): void;
    importProvisioning(value: unknown): Promise<unknown>;
    addViewer(name: string): Promise<{ viewerId: string }>;
    exportViewer(viewerId: string): unknown | Promise<unknown>;
    removeViewer(viewerId: string): unknown | Promise<unknown>;
    start(value: {sessionId: string; captureId?: string; channelId: string; sourceId: string; targetLanguage: string}): unknown | Promise<unknown>;
    stop(): unknown | Promise<unknown>;
    reconnect(): unknown | Promise<unknown>;
}
export interface SharingUiPorts {
    sharing: () => SharingUiService | undefined;
    voice: () => SharingVoiceState;
    readHostSetup: () => Promise<unknown | undefined>;
    chooseViewerPath: () => Promise<string | undefined>;
    writeViewerSetup: (file: string, value: unknown) => Promise<void>;
}
const methods = new Set(['sharing.status','sharing.start','sharing.stop','sharing.import','sharing.reconnect',
    'sharing.viewer.add','sharing.viewer.export','sharing.viewer.remove']);
function validate(method: unknown, params: unknown): {method: string; params: Record<string, unknown>} {
    if (typeof method !== 'string' || !methods.has(method) || !params || typeof params !== 'object' || Array.isArray(params))
        throw new ProtocolError('INVALID_REQUEST', 'Invalid caption-sharing operation.');
    const fields = method === 'sharing.viewer.add' ? ['name'] : /sharing\.viewer\.(export|remove)$/.test(method) ? ['viewerId'] : [];
    if (Object.keys(params).length !== fields.length || Object.keys(params).some(key => !fields.includes(key)))
        throw new ProtocolError('INVALID_REQUEST', 'Invalid caption-sharing parameters.');
    const p = params as Record<string, unknown>;
    if (fields.includes('name') && (typeof p.name !== 'string' || !p.name.trim() || p.name.length > 64 || /[\x00-\x1f\x7f]/.test(p.name)))
        throw new ProtocolError('INVALID_REQUEST', 'Enter a viewer name of 1–64 characters.');
    if (fields.includes('viewerId') && (typeof p.viewerId !== 'string' || !/^[A-Za-z0-9_-]{22}$/.test(p.viewerId)))
        throw new ProtocolError('INVALID_REQUEST', 'Invalid viewer identity.');
    return {method, params:p};
}
function safeFailure(error: unknown): ProtocolError {
    if (error instanceof ProtocolError) return error;
    if (error instanceof HostSharingError) return new ProtocolError(error.code, error.message);
    return new ProtocolError('SHARING_OPERATION_FAILED', 'The sharing operation could not finish. Check the relay connection and try again. Local captions remain available.');
}
/** Dashboard-only adapter. It never passes credentials or setup-file contents to the renderer. */
export class SharingUiController {
    private busy = false;
    constructor(private ports: SharingUiPorts) {}
    status(): Record<string, unknown> & {canStart: boolean} {
        const voice = this.ports.voice(), service = this.ports.sharing();
        service?.syncVoiceState(voice);
        const value = service?.getStatus();
        return {
            ...(value && typeof value === 'object' ? value : {configured:false, enabled:false, connected:false, viewers:[], error:{code:'SHARING_UNAVAILABLE',message:'Caption sharing is unavailable. Restart the companion to retry.'}}),
            canStart: Boolean(voice.active && !voice.starting && !voice.paused && voice.sessionId && voice.channelId && voice.sourceId && voice.targetLanguage)
        };
    }
    async handle(isDashboard: boolean, method: unknown, params: unknown): Promise<unknown> {
        if (!isDashboard) throw new ProtocolError('UNAUTHORIZED', 'Open caption sharing in the companion dashboard.');
        const request = validate(method,params);
        if (request.method === 'sharing.status') {
            try { return this.status(); } catch (error) { throw safeFailure(error); }
        }
        const service = this.ports.sharing();
        if (!service) throw new ProtocolError('SHARING_UNAVAILABLE', 'Caption sharing is unavailable. Restart the companion to retry.');
        // Stop always remains available, including while a file dialog or network operation is open.
        if (request.method === 'sharing.stop') {
            try { await service.stop(); return this.status(); } catch (error) { throw safeFailure(error); }
        }
        if (this.busy) throw new ProtocolError('SHARING_BUSY', 'Finish the current sharing operation first.');
        this.busy = true;
        try {
            service.syncVoiceState(this.ports.voice());
            switch (request.method) {
                case 'sharing.start': {
                    const v = this.ports.voice();
                    if (!v.active || v.starting || v.paused || !v.sessionId || !v.channelId || !v.sourceId || !v.targetLanguage)
                        throw new ProtocolError('CAPTIONS_NOT_RUNNING', 'Start captions in your Discord voice channel before sharing.');
                    await service.start({sessionId:v.sessionId, ...(v.captureId ? {captureId:v.captureId} : {}), channelId:v.channelId, sourceId:v.sourceId, targetLanguage:v.targetLanguage});
                    return this.status();
                }
                case 'sharing.import': {
                    const file = await this.ports.readHostSetup();
                    if (file === undefined) return {imported:false};
                    await service.importProvisioning(file);
                    return {imported:true};
                }
                case 'sharing.reconnect': await service.reconnect(); return this.status();
                case 'sharing.viewer.add': {
                    const file = await this.ports.chooseViewerPath();
                    if (!file) return {saved:false};
                    const viewer = await service.addViewer((request.params.name as string).trim());
                    try { await this.ports.writeViewerSetup(file,await service.exportViewer(viewer.viewerId)); }
                    catch { throw new ProtocolError('VIEWER_EXPORT_FAILED', 'The viewer was added, but its setup file could not be saved. Use Save setup beside that viewer to try again.'); }
                    return {saved:true};
                }
                case 'sharing.viewer.export': {
                    const file = await this.ports.chooseViewerPath();
                    if (!file) return {saved:false};
                    await this.ports.writeViewerSetup(file,await service.exportViewer(request.params.viewerId as string));
                    return {saved:true};
                }
                case 'sharing.viewer.remove': await service.removeViewer(request.params.viewerId as string); return {removed:true};
            }
        } catch (error) { throw safeFailure(error); }
        finally {
            this.busy=false;
            try { service.syncVoiceState(this.ports.voice()); }
            catch (error) { throw safeFailure(error); }
        }
    }
}
