import {execFile} from 'node:child_process';import {promisify} from 'node:util';import {randomUUID} from 'node:crypto';
import {ProtocolError,language,type LanguageDetection,type AppSettings,type CaptionEvent,type TranslationMode,type VoiceSource} from '@comms/shared';
import {performance} from 'node:perf_hooks';
import {normalizedSpeech as normalized,hasStrictDraftPrefix,matchPartialDraft} from './draftMatching.js';
import type {DraftDiagnosticEvent} from './translationDiagnostics.js';
import {JsonWorker} from './process.js';import type {LocalRuntime} from './local.js';import type {TranslationService} from './translation.js';import type {EventBuffer} from './events.js';
const exec=promisify(execFile);
interface Session {id:string;captureId:string;channelId:string;pid:number;sourceName:string;sourceLanguage:string;targetLanguage:string;mode:TranslationMode;lastHeartbeat:number;createdAt:number;ready:boolean;paused:boolean;profile:AppSettings['profile'];model:string;latencyMode:AppSettings['latencyMode'];speechLanguageMode:AppSettings['speechLanguageMode'];expectedLanguages:string[]}
type Timing=NonNullable<CaptionEvent['timing']>;
interface Job {sessionId:string;utteranceId:string;text:string;duration:number;time:number;uncertain:boolean;timing:Timing;sourceLanguage:string;languageDetection?:LanguageDetection}
interface LiveDraft {
 id:string;request:Job;slot:Job;current:Job;generation:number;active:boolean;valid:boolean;accepted:boolean;
 translated:string;timing:Timing;diagnosticId?:string;firstDisplayedAt?:number;recordDiagnostic?:(event:DraftDiagnosticEvent)=>void;
}
function workerTiming(event:any):Timing {
 const result:Timing={};
 for(const key of ['recognitionMs','recognitionQueueMs','speechMs','endpointWaitMs'] as const){
  const value=event.timing?.[key]??(key==='recognitionMs'?event.inferenceMs:undefined);
  if(typeof value==='number'&&Number.isFinite(value)&&value>=0&&value<=600000)result[key]=Math.round(value);
 }
 return result;
}
export class VoicePipeline {
 private session:Session|undefined;private capture:JsonWorker|undefined;private queue:Job[]=[];private ids=new Set<string>();private translating=new Map<string,Job>();private generation=0;private discontinuity=false;
 private leaseTimer:NodeJS.Timeout;
 private drafts=new Map<string,LiveDraft>();private attemptedDrafts=new Set<string>();private activeDraft:LiveDraft|undefined;
 constructor(private nativeCapture:string,private local:LocalRuntime,private translator:TranslationService,private events:EventBuffer,private settings:()=>AppSettings,private canUsePlan:()=>Promise<boolean>){
  this.local.on('event',e=>this.onWorkerEvent(e));this.local.on('fault',()=>{if(this.session){this.events.push({type:'error',sessionId:this.session.id,error:{code:'WORKER_STOPPED',message:'Local worker stopped. Voice capture has been stopped.'}});void this.stop();}});
  this.leaseTimer=setInterval(()=>{this.pruneDrafts();if(this.session&&(this.session.ready?Date.now()-this.session.lastHeartbeat>8000:Date.now()-this.session.createdAt>30000)){this.events.push({type:'status',text:'Voice connection expired; capture stopped.'});void this.stop();}},1000);this.leaseTimer.unref();
 }
 status(){return this.session?{active:true,starting:!this.session.ready,paused:this.session.paused,sessionId:this.session.id,captureId:this.session.captureId,channelId:this.session.channelId,pid:this.session.pid,sourceName:this.session.sourceName,sourceLanguage:this.session.sourceLanguage,speechLanguageMode:this.session.speechLanguageMode??'fixed',targetLanguage:this.session.targetLanguage,mode:this.session.mode,queueSeconds:this.queue.reduce((n,j)=>n+j.duration,0)}:{active:false,paused:false,starting:false,queueSeconds:0};}
 async sources():Promise<VoiceSource[]>{
  if(process.platform!=='win32')throw new ProtocolError('PLATFORM_UNSUPPORTED','Process audio capture requires Windows 11.');
  let stdout:string;try{({stdout}=await exec(this.nativeCapture,['--list'],{timeout:20000,maxBuffer:262144,windowsHide:true}));}catch{throw new ProtocolError('CAPTURE_UNAVAILABLE','Build the Windows capture helper and start Discord. See SETUP.md.');}
  const lines=stdout.trim().split('\n').map(l=>JSON.parse(l));const result=lines.find(l=>l.type==='processes');
  if(!result)throw new ProtocolError('CAPTURE_UNAVAILABLE','The capture helper did not return a trusted Discord source.');
  return result.processes.filter((s:any)=>s.signatureVerified===true&&Number.isSafeInteger(s.pid)).map((s:any)=>({pid:s.pid,name:`Discord (${s.pid})`,executable:s.path}));
 }
 async start(params:{pid:number;channelId:string;sourceLanguage:string;targetLanguage:string;mode:TranslationMode}){
  await this.stop();const intent=++this.generation;
  const checkIntent=()=>{if(this.generation!==intent)throw new ProtocolError('CAPTURE_CANCELLED','Capture start was cancelled.');};
  if(!this.settings().privacyAcknowledged)throw new ProtocolError('PRIVACY_ACK_REQUIRED','Review and acknowledge the processing mode before starting captions.');
  if(params.mode==='chatgpt'&&(this.settings().speechLanguageMode==='auto'||params.sourceLanguage!==params.targetLanguage)&&!await this.canUsePlan())throw new ProtocolError('SIGN_IN_REQUIRED','Connect ChatGPT and enable plan usage before starting this mode.');
  const source=(await this.sources()).find(s=>s.pid===params.pid);checkIntent();if(!source)throw new ProtocolError('SOURCE_NOT_TRUSTED','Choose a currently verified Discord process.');
  await this.local.ensure(true);checkIntent();
  const caps=this.local.capabilities,auto=this.settings().speechLanguageMode==='auto';if(!auto&&!caps.asrLanguages.includes(params.sourceLanguage))throw new ProtocolError('LANGUAGE_UNSUPPORTED','The installed speech model does not support that source language.');
  if(auto&&caps.asrLanguages.length<2)throw new ProtocolError('AUTO_LANGUAGE_UNSUPPORTED','Automatic language detection needs a multilingual speech model.');
  if(auto&&(this.settings().expectedLanguages??[]).some(code=>!caps.asrLanguages.includes(code)))throw new ProtocolError('LANGUAGE_UNSUPPORTED','An expected language is not supported by this speech model. Check the language hints.');
  if(params.mode==='local'&&!auto&&params.sourceLanguage!==params.targetLanguage&&!caps.localPairs.some(p=>p.sourceLanguage===params.sourceLanguage&&p.targetLanguage===params.targetLanguage))throw new ProtocolError('PAIR_NOT_INSTALLED','Install a direct local translation model for this pair.');
  const s=this.settings(),captureId=randomUUID();this.session={id:captureId,captureId,...params,sourceName:source.name,lastHeartbeat:Date.now(),createdAt:Date.now(),ready:false,paused:false,profile:s.profile,model:s.model,latencyMode:s.latencyMode,speechLanguageMode:s.speechLanguageMode??'fixed',expectedLanguages:[...(s.expectedLanguages??[])]};
  try{await this.local.worker.request('start',{sessionId:this.session.id,sourceLanguage:params.sourceLanguage,latencyMode:s.latencyMode,speechLanguageMode:this.session.speechLanguageMode,expectedLanguages:this.session.expectedLanguages},10000);checkIntent();await this.startCapture();checkIntent();this.session.ready=true;this.session.lastHeartbeat=Date.now();this.events.push({type:'status',sessionId:this.session.id,text:'Listening to mixed Discord audio. Speaker names are unavailable.'});return this.status();}catch(e){await this.stop();throw e;}
 }
 private async startCapture(){
  const s=this.session;if(!s)return;const capture=this.capture=new JsonWorker(this.nativeCapture,['--pid',String(s.pid)]);
  await new Promise<void>((resolve,reject)=>{
   const timer=setTimeout(()=>reject(new ProtocolError('CAPTURE_TIMEOUT','Windows process capture did not become ready.')),20000);
   const fail=(e:Error)=>{clearTimeout(timer);reject(e);};
   capture.on('fault',e=>{fail(e);if(this.session?.id===s.id){this.events.push({type:'error',sessionId:s.id,error:{code:'CAPTURE_STOPPED',message:'Discord audio capture stopped.'}});void this.stop();}});
   capture.on('event',e=>{
    if(this.session?.id!==s.id||this.capture!==capture)return;
    if(e.type==='ready'){clearTimeout(timer);resolve();}
    else if(e.type==='error'){fail(new ProtocolError(e.error?.code??e.code??'CAPTURE_FAILED',e.error?.message??e.message??'Windows process capture failed.'));}
    else if(e.type==='audio'&&!s.paused&&!this.discontinuity){if(!this.local.worker.send({...e,sessionId:s.id})){this.events.push({type:'error',sessionId:s.id,error:{code:'WORKER_STOPPED',message:'Speech worker is unavailable; capture stopped.'}});void this.stop();}}
    else if(e.type==='discontinuity'){
     this.discontinuity=true;this.discardDrafts(true,'audio_gap');this.events.push({type:'skipped',sessionId:s.id,text:'Audio gap; unfinished speech discarded.'});
     void this.local.worker.request('gap',{sessionId:s.id},2000).catch(()=>{if(this.session?.id===s.id&&this.capture===capture)return this.stop();}).finally(()=>{if(this.session?.id===s.id&&this.capture===capture)this.discontinuity=false;});
    }
   });capture.start();
  });
 }
 heartbeat(sessionId:string,channelId:string){if(this.session?.id===sessionId&&this.session.channelId===channelId)this.session.lastHeartbeat=Date.now();return this.status();}
 async pause(paused:boolean){
  const s=this.session;if(!s)return this.status();if(s.paused===paused)return this.status();
  this.capture?.stop();this.capture=undefined;this.generation++;this.discardDrafts(false,'paused');
  for(const job of this.queue)this.failed(job,s,'CAPTION_CANCELLED','Translation cancelled when captions paused.');
  this.queue=[];
  for(const [id,job] of this.translating){this.translator.cancel(id);this.failed(job,s,'CAPTION_CANCELLED','Translation cancelled when captions paused.');}
  this.translating.clear();this.drafts.clear();this.attemptedDrafts.clear();
  const intent=this.generation;s.paused=true;
  // Outputs must clear immediately, before a slow worker-stop acknowledgement.
  this.events.push({type:'status',sessionId:s.id,text:paused?'Captions paused.':'Resuming captions.'});
  await this.local.worker.request('stop',{},2000).catch(()=>{});if(this.session!==s||this.generation!==intent)return this.status();
  if(!paused){
   s.id=randomUUID();s.createdAt=Date.now();s.lastHeartbeat=Date.now();s.ready=false;this.ids.clear();
   try{await this.local.worker.request('start',{sessionId:s.id,sourceLanguage:s.sourceLanguage,latencyMode:s.latencyMode,speechLanguageMode:s.speechLanguageMode??'fixed',expectedLanguages:s.expectedLanguages??[]},10000);if(this.session!==s||this.generation!==intent)return this.status();s.paused=false;await this.startCapture();if(this.session!==s||this.generation!==intent)return this.status();s.ready=true;s.lastHeartbeat=Date.now();}
   catch(e){if(this.session===s)await this.stop();throw e;}
  }
  this.events.push({type:'status',sessionId:s.id,text:paused?'Captions paused.':'Captions resumed.'});return this.status();
 }
 async stop(){
  for(const draft of this.drafts.values())draft.recordDiagnostic?.('stopped');
  const was=this.session;this.session=undefined;this.generation++;this.capture?.stop();this.capture=undefined;this.queue=[];this.ids.clear();this.discontinuity=false;
  for(const id of this.translating.keys())this.translator.cancel(id);this.translating.clear();
  this.drafts.clear();this.attemptedDrafts.clear();this.activeDraft=undefined;this.events.clear();this.translator.clear();this.events.push({type:'status',text:'Capture stopped; session captions cleared.'});if(was)await this.local.worker.request('stop',{},2000).catch(()=>{});return this.status();
 }
 private onWorkerEvent(e:any){
  const s=this.session;if(!s||!s.ready||s.paused||e.sessionId!==s.id)return;
  if(e.type==='overload'||e.type==='audioGap'){this.discardDrafts(e.type==='audioGap',e.type==='audioGap'?'audio_gap':'overload');this.events.push({type:'skipped',sessionId:s.id,text:'Speech worker is behind or audio was missed; stale speech was skipped.'});return;}
  if(e.type==='error'){this.events.push({type:'error',sessionId:s.id,error:e.error});return;}
  if(this.discontinuity||!['transcriptPartial','transcriptFinal'].includes(e.type)||typeof e.text!=='string'||typeof e.utteranceId!=='string')return;
  if(this.ids.has(e.utteranceId))return;
  const timing=workerTiming(e),auto=s.speechLanguageMode==='auto';
  const raw=e.languageDetection;
  const validDetection=!auto||(language(e.sourceLanguage)&&this.local.capabilities.asrLanguages.includes(e.sourceLanguage)&&raw&&typeof raw.confidence==='number'&&Number.isFinite(raw.confidence)&&raw.confidence>=0&&raw.confidence<=1&&typeof raw.uncertain==='boolean'&&(raw.reason===undefined||['short','low_confidence','hint','unexpected'].includes(raw.reason)));
  const sourceLanguage=auto&&validDetection?e.sourceLanguage:s.sourceLanguage;
  const languageDetection:LanguageDetection|undefined=auto?(validDetection?{confidence:raw.confidence,uncertain:raw.uncertain,...(raw.reason?{reason:raw.reason}:{})}:{confidence:0,uncertain:true,reason:'low_confidence'}):undefined;
  const sameLanguage=sourceLanguage===s.targetLanguage&&(!auto||(validDetection&&!languageDetection!.uncertain&&languageDetection!.confidence>=.85));
  const languageFields={sourceLanguage,...(languageDetection?{languageDetection}:{})};
  const duration=Number.isFinite(e.endMs-e.startMs)?Math.max(.1,Math.min(10,(e.endMs-e.startMs)/1000)):1;
  const job:Job={sessionId:s.id,utteranceId:e.utteranceId,text:e.text,duration,time:performance.now(),uncertain:!!e.uncertain,timing,sourceLanguage,languageDetection};
  let draft=this.drafts.get(e.utteranceId);
  // Measure text that was actually available before final ASR, even if that
  // final corrects it. This is an observed lead, never an accuracy guarantee.
  if(e.type==='transcriptFinal'&&draft?.translated.trim()&&draft.firstDisplayedAt!==undefined)timing.draftLeadMs=Math.max(0,Math.round(job.time-draft.firstDisplayedAt));
  const reliable=!job.uncertain&&validDetection&&!languageDetection?.uncertain;
  const partial=e.type==='transcriptPartial';
  if(draft){
   const changedFinal=!partial&&normalized(draft.request.text)!==normalized(e.text);
   if(changedFinal)draft.recordDiagnostic?.('final_changed');
   const match=partial?matchPartialDraft(draft.request.text,e.text):hasStrictDraftPrefix(draft.request.text,e.text)?'strict':undefined;
   const reason:DraftDiagnosticEvent|undefined=!validDetection?'language_unavailable':languageDetection?.uncertain?'language_uncertain':job.uncertain?'recognition_uncertain':sameLanguage?'target_language':draft.request.sourceLanguage!==sourceLanguage?'language_changed':!match?(partial?'source_revised':'final_changed'):undefined;
   if(reason){this.invalidateDraft(draft,false,reason);draft=undefined;}
   else if(match==='formatting')draft.recordDiagnostic?.('formatting_retained');
  }
  if(draft)draft.current=job;
  if(e.type==='transcriptPartial'){
   if(draft)this.emitDraft(draft,s);
   else this.events.push({type:'caption',sessionId:s.id,utteranceId:e.utteranceId,text:e.text,translated:sameLanguage?e.text:'',provisional:true,translationState:'pending',mode:s.mode,...languageFields,targetLanguage:s.targetLanguage,timing});
   if(!draft&&s.latencyMode==='live'&&s.mode==='chatgpt'&&!sameLanguage&&reliable&&!this.attemptedDrafts.has(e.utteranceId)&&
      (timing.speechMs??(e.endMs-e.startMs))>=1200&&(e.text.match(/[\p{L}\p{N}]/gu)?.length??0)>=4&&
      !this.queue.length&&this.translating.size<2&&!this.activeDraft)this.startDraft(job,s);
   return;
  }
  this.rememberFinal(e.utteranceId);
  if(draft&&normalized(draft.request.text)===normalized(job.text)){
   // The final ASR text agrees exactly: keep this request, including an in-flight stream.
   draft.recordDiagnostic?.('final_reused');draft.accepted=true;draft.current=job;
   if(this.activeDraft===draft)this.activeDraft=undefined;
   if(draft.active){draft.slot=job;this.translating.set(draft.id,job);this.emitDraft(draft,s);}
   else {this.emitDraft(draft,s,true);this.drafts.delete(job.utteranceId);}
   this.processQueue();return;
  }
  // Only an exact final can accept an early translation: an appended ending may negate it.
  if(draft)this.invalidateDraft(draft,false,'final_changed');
  this.events.push({type:'caption',sessionId:s.id,utteranceId:e.utteranceId,text:e.text,translated:sameLanguage?e.text:'',provisional:false,translationState:sameLanguage?'complete':'pending',mode:s.mode,...languageFields,targetLanguage:s.targetLanguage,timing});
  // Captions in the spoken language need no translation request or plan usage.
  if(sameLanguage)return;
  if(!validDetection){this.events.push({type:'caption',sessionId:s.id,utteranceId:e.utteranceId,text:e.text,translated:'',provisional:false,translationState:'failed',...languageFields,targetLanguage:s.targetLanguage,timing,error:{code:'LANGUAGE_UNAVAILABLE',message:'The worker did not report a valid detected language. Select a manual language and restart captions.'}});return;}
  this.queue.push(job);
  while(this.queue.reduce((n,j)=>n+j.duration,0)>10){const dropped=this.queue.shift()!;this.failed(dropped,s,'CAPTION_SKIPPED','Older speech skipped to keep captions current.');this.events.push({type:'skipped',sessionId:s.id,text:'Translation queue exceeded ten seconds; oldest speech skipped.'});}
  this.processQueue();
 }
 private rememberFinal(id:string){this.ids.add(id);if(this.ids.size>200)this.ids.delete(this.ids.values().next().value!);}
 private draftTranslationTiming(draft:LiveDraft):Timing {
  return {translationQueueMs:0,...(draft.timing.firstTextMs!==undefined?{firstTextMs:draft.timing.firstTextMs}:{}),...(draft.timing.translationMs!==undefined?{translationMs:draft.timing.translationMs}:{})};
 }
 private emitDraft(draft:LiveDraft,s:Session,complete=false){
  if(!draft.valid)return;
  const job=draft.current,now=performance.now();
  if(draft.translated.trim())draft.firstDisplayedAt??=now;
  const timing:Timing={...job.timing,...this.draftTranslationTiming(draft),...(draft.accepted?{afterRecognitionMs:Math.max(0,Math.round(now-job.time))}:{})};
  this.events.push({type:'caption',sessionId:job.sessionId,utteranceId:job.utteranceId,text:job.text,translated:draft.translated,provisional:!draft.accepted,translationState:complete?'complete':draft.translated.trim()?'streaming':'pending',mode:s.mode,sourceLanguage:job.sourceLanguage,...(job.languageDetection?{languageDetection:job.languageDetection}:{}),targetLanguage:s.targetLanguage,timing,...(draft.diagnosticId?{diagnosticId:draft.diagnosticId}:{})});
 }
 private invalidateDraft(draft:LiveDraft,publish:boolean,reason:DraftDiagnosticEvent){
  if(!draft.valid)return;
  draft.recordDiagnostic?.(reason);
  draft.valid=false;
  if(draft.active){this.translator.cancel(draft.id);if(this.translating.get(draft.id)===draft.slot)this.translating.delete(draft.id);}
  if(this.activeDraft===draft)this.activeDraft=undefined;
  if(this.drafts.get(draft.current.utteranceId)===draft)this.drafts.delete(draft.current.utteranceId);
  const s=this.session,job=draft.current;
  if(publish&&s&&s.id===job.sessionId)this.events.push({type:'caption',sessionId:job.sessionId,utteranceId:job.utteranceId,text:job.text,translated:'',provisional:true,translationState:'pending',mode:s.mode,sourceLanguage:job.sourceLanguage,...(job.languageDetection?{languageDetection:job.languageDetection}:{}),targetLanguage:s.targetLanguage,timing:{...job.timing}});
 }
 private discardDrafts(discardUtterances:boolean,reason:DraftDiagnosticEvent){
  for(const draft of this.drafts.values()){
   if(draft.accepted){if(reason==='paused')draft.recordDiagnostic?.(reason);continue;}
   if(discardUtterances)this.rememberFinal(draft.current.utteranceId);this.invalidateDraft(draft,true,reason);
  }
 }
 private pruneDrafts(){
  for(const draft of this.drafts.values())if(!draft.accepted&&performance.now()-draft.request.time>10000)this.invalidateDraft(draft,true,'expired');
 }
 private startDraft(job:Job,s:Session){
  this.attemptedDrafts.add(job.utteranceId);if(this.attemptedDrafts.size>200){const expired=this.attemptedDrafts.values().next().value!;this.attemptedDrafts.delete(expired);this.rememberFinal(expired);}
  const draft:LiveDraft={id:`voice-draft-${s.id}-${job.utteranceId}-${randomUUID()}`,request:job,slot:job,current:job,generation:this.generation,active:true,valid:true,accepted:false,translated:'',timing:{translationQueueMs:0}};
  this.drafts.set(job.utteranceId,draft);this.activeDraft=draft;this.translating.set(draft.id,job);
  // Completed drafts can await ASR finality, but never accumulate without bound.
  while(this.drafts.size>32){const oldest=[...this.drafts.values()].find(value=>!value.accepted);if(!oldest)break;this.invalidateDraft(oldest,true,'capacity');}
  void this.translateDraft(draft,s);
 }
 private async translateDraft(draft:LiveDraft,s:Session){
  const request=draft.request;
  const isCurrent=()=>draft.valid&&draft.generation===this.generation&&this.session?.id===s.id&&!s.paused&&this.drafts.get(request.utteranceId)===draft;
  const withinDeadline=()=>performance.now()-(draft.accepted?draft.current.time:request.time)<=10000;
  try{
   const result=await this.translator.translate(draft.id,{text:request.text,sourceLanguage:request.sourceLanguage,targetLanguage:s.targetLanguage,mode:s.mode,profile:s.profile,channelId:s.channelId,context:[],model:s.model},10000,{
    live:true,voicePhase:'draft',voiceTiming:{...request.timing,translationQueueMs:0},onDraftDiagnostic:record=>{draft.recordDiagnostic=record;},
    onPreview:(text,timing)=>{
     if(!isCurrent()||!withinDeadline())return;
     draft.translated=text;draft.timing={...draft.timing,...timing};draft.diagnosticId=timing.diagnosticId;
     this.emitDraft(draft,s);
    }
   });
   if(!isCurrent())return;
   if(!withinDeadline()){
    draft.recordDiagnostic?.('expired');
    if(draft.accepted){this.failed(draft.current,s,'CAPTION_SKIPPED','Translation arrived too late to display as current comms.');this.events.push({type:'skipped',sessionId:s.id,text:'A translation arrived too late to display as current comms.'});}
    else this.invalidateDraft(draft,true,'expired');
    return;
   }
   draft.translated=result.text;draft.timing.translationMs=result.elapsedMs;draft.diagnosticId=result.diagnosticId;
   this.emitDraft(draft,s,draft.accepted);
  }catch(e){
   if(!isCurrent())return;
   draft.recordDiagnostic?.('translation_error');
   if(draft.accepted)await this.translationFailed(draft.current,s,e,draft.id);
   else this.invalidateDraft(draft,true,'translation_error');
  }finally{
   draft.active=false;if(this.activeDraft===draft)this.activeDraft=undefined;
   if(this.translating.get(draft.id)===draft.slot)this.translating.delete(draft.id);
   if(draft.accepted&&this.drafts.get(request.utteranceId)===draft)this.drafts.delete(request.utteranceId);
   this.processQueue();
  }
 }
 private failed(job:Job,s:Session,code:string,message:string){
  this.events.push({type:'caption',sessionId:job.sessionId,utteranceId:job.utteranceId,text:job.text,translated:'',provisional:false,translationState:'failed',mode:s.mode,sourceLanguage:job.sourceLanguage,...(job.languageDetection?{languageDetection:job.languageDetection}:{}),targetLanguage:s.targetLanguage,timing:{...job.timing,afterRecognitionMs:Math.round(performance.now()-job.time)},error:{code,message}});
 }
 private processQueue(){
  if(this.queue.length&&this.translating.size>=2&&this.activeDraft)this.invalidateDraft(this.activeDraft,true,'final_priority');
  while(this.queue.length&&this.translating.size<2){
   const job=this.queue.shift()!,s=this.session;if(!s||s.paused||job.sessionId!==s.id)continue;
   if(performance.now()-job.time>10000){this.failed(job,s,'CAPTION_SKIPPED','Older speech skipped to keep captions current.');this.events.push({type:'skipped',sessionId:s.id,text:'A stale speech segment was skipped.'});continue;}
   const generation=this.generation,id=`voice-${s.id}-${job.utteranceId}`;this.translating.set(id,job);
   void this.translateJob(job,s,generation,id);
  }
 }
 private async translateJob(job:Job,s:Session,generation:number,id:string){
  const timing:Timing={...job.timing,translationQueueMs:Math.round(performance.now()-job.time)};
  job.timing=timing;
  const isCurrent=()=>this.generation===generation&&this.session?.id===s.id&&!s.paused;
  try{
   const result=await this.translator.translate(id,{text:job.text,sourceLanguage:job.sourceLanguage,targetLanguage:s.targetLanguage,mode:s.mode,profile:s.profile,channelId:s.channelId,context:[],model:s.model},Math.max(1,10000-(performance.now()-job.time)),{
    live:s.latencyMode==='live',voicePhase:'final',voiceTiming:timing,
    onPreview:(text,previewTiming)=>{
     if(!isCurrent()||performance.now()-job.time>10000)return;
     if(previewTiming.firstTextMs!==undefined)timing.firstTextMs=previewTiming.firstTextMs;
     this.events.push({type:'caption',sessionId:s.id,utteranceId:job.utteranceId,text:job.text,translated:text,provisional:false,translationState:'streaming',mode:s.mode,sourceLanguage:job.sourceLanguage,...(job.languageDetection?{languageDetection:job.languageDetection}:{}),targetLanguage:s.targetLanguage,...(previewTiming.diagnosticId?{diagnosticId:previewTiming.diagnosticId}:{}),timing:{...timing,translationMs:previewTiming.translationMs,afterRecognitionMs:Math.round(performance.now()-job.time)}});
    }
   });
   if(!isCurrent())return;
   if(performance.now()-job.time>10000){this.failed(job,s,'CAPTION_SKIPPED','Translation arrived too late to display as current comms.');this.events.push({type:'skipped',sessionId:s.id,text:'A translation arrived too late to display as current comms.'});return;}
   this.events.push({type:'caption',sessionId:s.id,utteranceId:job.utteranceId,text:job.text,translated:result.text,provisional:false,translationState:'complete',mode:s.mode,sourceLanguage:job.sourceLanguage,...(job.languageDetection?{languageDetection:job.languageDetection}:{}),targetLanguage:s.targetLanguage,...(result.diagnosticId?{diagnosticId:result.diagnosticId}:{}),timing:{...timing,translationMs:result.elapsedMs,afterRecognitionMs:Math.round(performance.now()-job.time)}});
   if(job.uncertain)this.events.push({type:'status',text:'The speech model marked the last transcript as uncertain. Check the original.'});
  }catch(e){
   if(!isCurrent())return;
   await this.translationFailed(job,s,e,id);
  }finally{if(this.translating.get(id)===job)this.translating.delete(id);this.processQueue();}
 }
 private async translationFailed(job:Job,s:Session,e:unknown,id:string){
  const error=e as Error&{code?:string};
  if(error.code==='TRANSLATION_TIMEOUT'||error.name==='TimeoutError'){
   this.failed(job,s,'TRANSLATION_TIMEOUT','A slow translation was cancelled.');this.events.push({type:'skipped',sessionId:s.id,text:'A slow translation was cancelled to keep captions current.'});return;
  }
  const details={code:error.code??'TRANSLATION_FAILED',message:error.code==='PAIR_NOT_INSTALLED'?`No offline translation pack is installed for ${job.sourceLanguage} → ${s.targetLanguage}. The original caption is retained. Install this pair explicitly or select ChatGPT.`:error.code==='LOCAL_NEGATION_UNCONFIRMED'?'The local model may have lost a command negation. Check the original or select ChatGPT.':'Translation failed. Check the provider connection or model; no paid fallback was used.'};
  this.failed(job,s,details.code,details.message);this.events.push({type:'error',sessionId:s.id,error:details});
  // This job already has a failure row; pausing clears drafts of its peers.
  if(this.translating.get(id)===job)this.translating.delete(id);
  if(s.mode==='chatgpt')await this.pause(true);
 }
 close(){clearInterval(this.leaseTimer);void this.stop();}
}
