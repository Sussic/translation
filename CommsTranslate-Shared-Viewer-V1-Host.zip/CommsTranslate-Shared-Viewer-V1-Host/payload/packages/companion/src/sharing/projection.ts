import type {CaptionEvent} from '@comms/shared';
import {LIMITS,newId,type CaptionRow} from '@comms/sharing';

interface Entry {event:CaptionEvent;id:string;revision:number;primary:string;draft:boolean;expiresAt:number}
export interface ProjectionSnapshot {rows:CaptionRow[];unavailable:boolean;nextExpiry?:number}
function presentation(event:CaptionEvent){
 const failed=event.translationState==='failed'||Boolean(event.error);
 const translated=failed||typeof event.translated!=='string'||!event.translated.trim()?'':event.translated;
 const sameLanguageFinal=!failed&&event.provisional===false&&event.translationState==='complete'&&event.sourceLanguage&&event.sourceLanguage===event.targetLanguage&&(!event.languageDetection||event.languageDetection.uncertain!==true&&event.languageDetection.confidence>=.85);
 const primary=translated||(sameLanguageFinal?event.text||'':'');
 return {primary,draft:Boolean(primary.trim())&&(event.provisional===true||event.translationState==='streaming')};
}
function safeText(text:string){
 if(Buffer.byteLength(text,'utf8')>LIMITS.captionBytes||/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/u.test(text))return false;
 for(let i=0;i<text.length;i++){const c=text.charCodeAt(i);if(c>=0xd800&&c<=0xdbff){const d=text.charCodeAt(++i);if(!(d>=0xdc00&&d<=0xdfff))return false;}else if(c>=0xdc00&&c<=0xdfff)return false;}
 return true;
}

/** Port of CaptionTimeline/captionPresentation rules; only safe reading-language rows leave this class. */
export class CaptionProjection {
 private rows=new Map<string,Entry>();private seen=new Set<string>();private session:string|undefined;
 constructor(private now:()=>number=()=>performance.now(),private id:()=>string=newId){}
 clear(){this.rows.clear();this.seen.clear();this.session=undefined;}
 accept(event:CaptionEvent):boolean {
  if(event.type!=='caption'||!event.sessionId||!event.utteranceId)return false;
  if(this.session&&event.sessionId!==this.session)return false;
  this.session=event.sessionId;
  const key=event.utteranceId,previous=this.rows.get(key);
  if(!previous&&this.seen.has(key))return false;
  if(previous&&event.seq<=previous.event.seq)return false;
  if(previous&&['complete','failed'].includes(previous.event.translationState??''))return false;
  if(previous?.event.provisional===false&&event.provisional===true)return false;
  if(previous?.event.translationState&&!event.translationState)return false;
  const merged={...previous?.event,...event};
  if(event.translated===undefined&&previous)merged.translated=previous.event.translated;
  // Never retain a raw exception, correlation ID or timing in projected state.
  if(merged.translationState==='failed'||merged.error)merged.translated='';
  const {primary,draft}=presentation(merged);
  const changed=!previous||primary!==previous.primary||draft!==previous.draft;
  const expiresAt=primary.trim()&&(!previous||primary!==previous.primary)?this.now()+LIMITS.captionLifetimeMs:previous?.expiresAt??0;
  const stored:CaptionEvent={seq:merged.seq,timestamp:0,type:'caption',sessionId:event.sessionId,utteranceId:event.utteranceId,
   text:merged.text,translated:merged.translated,provisional:merged.provisional,translationState:merged.error?'failed':merged.translationState,
   sourceLanguage:merged.sourceLanguage,targetLanguage:merged.targetLanguage,languageDetection:merged.languageDetection};
  this.rows.set(key,{event:stored,id:previous?.id??this.id(),revision:(previous?.revision??0)+(changed?1:0),primary,draft,expiresAt});
  this.seen.add(key);
  if(this.rows.size>40){
   const retained=new Set([...this.rows].filter(([,row])=>row.primary.trim()).slice(-2).map(([key])=>key));
   for(const rowKey of this.rows.keys()){if(this.rows.size<=40)break;if(!retained.has(rowKey))this.rows.delete(rowKey);}
  }
  while(this.seen.size>1000)this.seen.delete(this.seen.values().next().value!);
  return true;
 }
 snapshot(now=this.now()):ProjectionSnapshot {
  // Expiry must not reveal an older row that was already displaced from the view.
  const selected=[...this.rows.values()].filter(row=>row.primary.trim()).slice(-LIMITS.rows).filter(row=>row.expiresAt>now);
  const nextExpiry=selected.length?Math.min(...selected.map(row=>row.expiresAt)):undefined;
  if(selected.some(row=>!safeText(row.primary)))return {rows:[],unavailable:true,...(nextExpiry!==undefined?{nextExpiry}:{})};
  return {rows:selected.map(row=>({id:row.id,revision:row.revision,text:row.primary,provisional:row.draft,remainingMs:Math.max(1,Math.ceil(row.expiresAt-now))})),unavailable:false,...(nextExpiry!==undefined?{nextExpiry}:{})};
 }
}
