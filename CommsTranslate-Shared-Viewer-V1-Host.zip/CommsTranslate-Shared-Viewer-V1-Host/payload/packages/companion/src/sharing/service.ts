import WebSocket, {type RawData} from 'ws';
import type {CredentialEncryption} from '@siwc/local';
import type {CaptionEvent} from '@comms/shared';
import {HostCipher,LIMITS,newId,newSecret,encodeFrame,parseJson,validateHostConfiguration,validatePairingFile,
 validateRelayMessage,validateViewerMessage,publisherWebSocketUrl,type PairingFile,type Payload,type ViewState,type UrlOptions,type HelloMessage} from '@comms/sharing';
import {SharingStore,HostSharingError,emptySharing,type SavedSharing,type SavedViewer} from './storage.js';
import {CaptionProjection} from './projection.js';
export {HostSharingError} from './storage.js';
export {parseHostConfiguration} from '@comms/sharing';

export interface CaptureBinding {sessionId:string;captureId?:string;channelId:string;sourceId:string;targetLanguage:string}
export interface SharingVoiceState {active:boolean;starting?:boolean;paused?:boolean;sessionId?:string;captureId?:string;channelId?:string;sourceId?:string;targetLanguage?:string}
export interface HostSharingOptions {storageDir:string;credentialEncryption:CredentialEncryption;onStatus?:()=>void;allowInsecureLoopback?:boolean;now?:()=>number}
interface Peer {connectionId:string;cipher?:HostCipher;lastProbe:number;lastSent:number;timer?:ReturnType<typeof setTimeout>;
 pendingHello?:HelloMessage;helloTimer?:ReturnType<typeof setTimeout>}
const wire=(data:RawData):Uint8Array=>Array.isArray(data)?Buffer.concat(data):data instanceof ArrayBuffer?new Uint8Array(data):data;
function fail(code:string,message:string):never{throw new HostSharingError(code,message);}
const validBinding=(b:CaptureBinding)=>[b.sessionId,b.channelId,b.sourceId].every(x=>typeof x==='string'&&x.length>0&&x.length<=256)
 &&(b.captureId===undefined||typeof b.captureId==='string'&&b.captureId.length>0&&b.captureId.length<=256)&&/^[a-z]{2,3}(?:-[A-Za-z0-9]{2,8})?$/.test(b.targetLanguage);
function fitsEncryptedView(view:ViewState):boolean{
 const token='A'.repeat(43),id='A'.repeat(22);
 const bytes=Buffer.byteLength(JSON.stringify({...view,viewRevision:Number.MAX_SAFE_INTEGER,kind:'view',probe:token}));
 const envelope={v:1,type:'sealed',hostId:id,viewerId:id,connectionId:id,challenge:token,salt:token,
  seq:'18446744073709551615',replyTo:token,ciphertext:'A'.repeat(Math.ceil(bytes/3)*4),tag:'A'.repeat(22)};
 return Buffer.byteLength(JSON.stringify(envelope))<=LIMITS.frameBytes;
}

/** A receive-only-viewer publisher. No provider, account or local RPC operation is exposed here. */
export class HostSharingService {
 private readonly store:SharingStore;private readonly urls:UrlOptions;private readonly now:()=>number;
 private readonly projection:CaptionProjection;private saved:SavedSharing=emptySharing();
 private initialized=false;private closed=false;private socket?:WebSocket;private connected=false;
 private epoch=0;private attempts=0;private terminal=false;private retry?:ReturnType<typeof setTimeout>;
 private readonly peers=new Map<string,Peer>();private readonly blocked=new Set<string>();
 // Per paired device, not per socket: reconnecting cannot reset the crypto-work budget.
 private readonly lastHelloByViewer=new Map<string,number>();
 private readonly requests=new Set<AbortController>();private queue:Promise<unknown>=Promise.resolve();
 private binding?:CaptureBinding;private paused=false;private broadcastId:string|null=null;
 private outputLanguage='en';private revision=0;private fingerprint='';private expiry?:ReturnType<typeof setTimeout>;
 private error?:{code:string;message:string};
 constructor(private options:HostSharingOptions){
  this.urls={allowInsecureLoopback:options.allowInsecureLoopback===true};this.now=options.now??(()=>performance.now());
  this.store=new SharingStore(options.storageDir,options.credentialEncryption,this.urls);this.projection=new CaptionProjection(this.now);
 }
 async initialize():Promise<void>{
  if(this.initialized||this.closed)return;
  const saved=await this.store.load();if(this.closed)return;
  this.saved=saved;this.initialized=true;this.notify();this.connect();
 }
 getStatus(){return {configured:Boolean(this.saved.configuration),enabled:Boolean(this.binding),connected:this.connected,
  targetLanguage:this.binding?.targetLanguage,hostName:this.saved.configuration?.hostName,relayUrl:this.saved.configuration?.relayUrl,
  viewers:this.listViewers(),...(this.error?{error:{...this.error}}:{})};}
 listViewers(){return this.saved.viewers.map(v=>({viewerId:v.pairing.viewerId,name:v.pairing.viewerName,
  connected:Boolean(this.peers.get(v.pairing.viewerId)?.cipher)&&!this.blocked.has(v.pairing.viewerId)}));}
 private notify(){try{this.options.onStatus?.();}catch{/* Presentation must not interrupt the publisher. */}}
 private ready(){if(this.closed||!this.initialized)fail('SHARING_NOT_READY','Caption sharing is not ready. Restart the companion if this continues.');}
 private serial<T>(action:()=>Promise<T>):Promise<T>{
  const result=this.queue.then(()=>{this.ready();return action();});this.queue=result.catch(()=>{});return result;
 }
 async importProvisioning(value:unknown){return this.serial(async()=>{
  if(this.binding)fail('SHARING_ACTIVE','Stop sharing before importing host setup.');
  let configuration:ReturnType<typeof validateHostConfiguration>;
  try{configuration=validateHostConfiguration(value,this.urls);}catch{fail('HOST_SETUP_INVALID','Choose a valid .commshost setup file created by the relay.');}
  const old=this.saved.configuration;
  if(old&&(old.hostId!==configuration.hostId||old.relayUrl!==configuration.relayUrl)&&(this.saved.viewers.length||this.saved.revocations.length))
   fail('SHARING_VIEWERS_EXIST','Remove existing viewers and finish pending revocations before changing to a different host.');
  const next:SavedSharing={...this.saved,configuration,viewers:this.saved.viewers.map(v=>({...v,pairing:{...v.pairing,hostName:configuration.hostName}}))};
  await this.store.save(next);if(this.closed)return;this.saved=next;this.error=undefined;this.reconnect();
 });}
 async addViewer(name:string):Promise<{viewerId:string}>{return this.serial(async()=>{
  const config=this.saved.configuration;if(!config)fail('SHARING_NOT_CONFIGURED','Import host setup before adding a viewer.');
  if(typeof name!=='string'||!name.trim()||name.length>64||/[\x00-\x1f\x7f]/.test(name))fail('VIEWER_NAME_INVALID','Enter a viewer name of 1–64 characters.');
  if(this.saved.viewers.length>=LIMITS.viewers)fail('VIEWER_LIMIT','Remove a viewer before adding another. The limit is 20.');
  const pairing=validatePairingFile({format:'CommsTranslateViewer',version:1,relayUrl:config.relayUrl,hostId:config.hostId,hostName:config.hostName,
   viewerId:newId(),viewerName:name.trim(),viewerToken:newSecret(),captionSecret:newSecret()},this.urls);
  const entry:SavedViewer={pairing,registered:false},next={...this.saved,viewers:[...this.saved.viewers,entry]};
  await this.store.save(next);if(this.closed)fail('SHARING_CLOSED','The companion is closing.');this.saved=next;this.notify();
  await this.register(entry);return {viewerId:pairing.viewerId};
 });}
 async exportViewer(viewerId:string):Promise<PairingFile>{return this.serial(async()=>{
  const entry=this.saved.viewers.find(v=>v.pairing.viewerId===viewerId);
  if(!entry||this.blocked.has(viewerId))fail('VIEWER_NOT_FOUND','That viewer is no longer available.');
  if(!entry.registered)await this.register(entry);
  return {...entry.pairing};
 });}
 async removeViewer(viewerId:string){return this.serial(async()=>{
  const entry=this.saved.viewers.find(v=>v.pairing.viewerId===viewerId);
  if(!entry)fail('VIEWER_NOT_FOUND','That viewer is no longer available.');
  if(this.saved.revocations.length>=128)fail('REVOCATION_PENDING','Reconnect to the relay to finish pending revocations before removing another viewer.');
  // Cut off encryption before any file or network operation can yield.
  this.blocked.add(viewerId);this.removePeer(viewerId);this.lastHelloByViewer.delete(viewerId);this.notify();
  const next={...this.saved,viewers:this.saved.viewers.filter(v=>v!==entry),revocations:[...this.saved.revocations,viewerId]};
  try{await this.store.save(next);}catch(error){this.stop();this.error={code:'REVOCATION_NOT_SAVED',message:'Sharing stopped because the removal could not be saved. Retry Remove before restarting the companion.'};this.notify();throw error;}
  this.saved=next;this.notify();
  try{await this.revoke(viewerId);}catch{this.error={code:'REVOCATION_PENDING',message:'Viewer removed locally. Relay revocation will finish when the connection returns.'};this.notify();}
 });}
 start(binding:CaptureBinding){
  this.ready();if(!this.saved.configuration)fail('SHARING_NOT_CONFIGURED','Import host setup before sharing.');
  if(!validBinding(binding))fail('CAPTURE_INVALID','Start captions with a supported reading language before sharing.');
  if(this.terminal)fail('RELAY_RECONNECT_REQUIRED','Reconnect to the relay before starting sharing.');
  if(this.binding)return;
  this.binding={...binding};this.outputLanguage=binding.targetLanguage;this.paused=false;this.broadcastId=newId();
  this.projection.clear();this.publish(true);this.notify();this.connect();
 }
 stop(){
  const changed=Boolean(this.binding)||this.broadcastId!==null;
  this.binding=undefined;this.broadcastId=null;this.paused=false;this.projection.clear();
  if(changed){this.publish(true);this.notify();}
 }
 pause(paused:boolean){if(!this.binding||this.paused===paused)return;this.paused=paused;this.projection.clear();this.publish(true);this.notify();}
 syncVoiceState(voice:SharingVoiceState){
  const b=this.binding;if(!b)return;
  if(!voice.active||!voice.sessionId||voice.channelId!==b.channelId||voice.sourceId!==b.sourceId||voice.targetLanguage!==b.targetLanguage
   ||(voice.captureId??voice.sessionId)!==(b.captureId??b.sessionId)){this.stop();return;}
  if(voice.sessionId!==b.sessionId){this.projection.clear();b.sessionId=voice.sessionId;this.publish(true);}
  this.pause(Boolean(voice.paused||voice.starting));
 }
 handleEvent(event:CaptionEvent){
  const b=this.binding;
  if(!b||this.paused||event.type!=='caption'||event.sessionId!==b.sessionId||event.targetLanguage!==b.targetLanguage)return;
  if(!this.projection.accept(event))return;
  const urgent=event.translationState==='complete'||event.translationState==='failed'||event.translated===''||Boolean(event.error);
  this.publish(urgent);
 }
 reconnect(){this.ready();this.terminal=false;this.attempts=0;this.error=undefined;this.disconnect();this.connect();this.notify();}
 async close(){
  if(this.closed)return;this.stop();this.closed=true;
  for(const request of this.requests)request.abort();this.disconnect();
  if(this.expiry)clearTimeout(this.expiry);this.expiry=undefined;
  await this.queue.catch(()=>{});
 }
 private current():ViewState{
  const snap=this.projection.snapshot();
  let status:ViewState['status']=!this.binding?'off':this.paused?'paused':snap.unavailable?'unavailable':'sharing';
  let rows=status==='sharing'?snap.rows:[];
  if(status==='sharing'&&!fitsEncryptedView({status,broadcastId:this.broadcastId,viewRevision:this.revision,outputLanguage:this.outputLanguage,rows})){
   status='unavailable';rows=[];
  }
  const signature=JSON.stringify([status,this.broadcastId,this.outputLanguage,rows.map(({remainingMs,...row})=>row)]);
  if(signature!==this.fingerprint){this.fingerprint=signature;this.revision++;}
  return {status,broadcastId:this.broadcastId,viewRevision:this.revision,outputLanguage:this.outputLanguage,rows};
 }
 private publish(urgent:boolean){
  this.current();this.armExpiry();
  for(const [id,peer] of this.peers){
   if(!peer.cipher)continue;
   if(peer.timer){clearTimeout(peer.timer);peer.timer=undefined;}
   const delay=urgent?0:Math.max(0,250-(this.now()-peer.lastSent));
   if(!delay)this.sendView(id,peer,null);
   else{peer.timer=setTimeout(()=>{peer.timer=undefined;if(this.peers.get(id)===peer)this.sendView(id,peer,null);},delay);peer.timer.unref();}
  }
 }
 private armExpiry(){
  if(this.expiry)clearTimeout(this.expiry);this.expiry=undefined;
  if(!this.binding||this.paused)return;
  const deadline=this.projection.snapshot().nextExpiry;if(deadline===undefined)return;
  this.expiry=setTimeout(()=>{this.expiry=undefined;this.publish(true);},Math.max(1,Math.ceil(deadline-this.now())));this.expiry.unref();
 }
 private sendView(id:string,peer:Peer,probe:string|null){this.send(id,peer,{kind:'view',probe,...this.current()});}
 private send(id:string,peer:Peer,payload:Payload){
  const socket=this.socket;if(!peer.cipher||this.blocked.has(id)||!socket||socket.readyState!==WebSocket.OPEN)return;
  try{
   const encoded=encodeFrame(peer.cipher.seal(payload));
   if(socket.bufferedAmount+Buffer.byteLength(encoded)+14>LIMITS.pendingBytes){this.transportFault();return;}
   socket.send(encoded,{compress:false},error=>{if(error&&this.socket===socket)this.transportFault();});
   peer.lastSent=this.now();
  }catch{this.transportFault();}
 }
 private acceptHello(id:string,peer:Peer){
  if(this.closed||this.peers.get(id)!==peer||this.blocked.has(id)||!peer.pendingHello)return;
  const wait=(this.lastHelloByViewer.get(id)??-Infinity)+LIMITS.handshakeIntervalMs-this.now();
  if(wait>0){
   if(!peer.helloTimer){
    peer.helloTimer=setTimeout(()=>{peer.helloTimer=undefined;try{this.acceptHello(id,peer);}catch{this.transportFault();}},Math.ceil(wait));
    peer.helloTimer.unref();
   }
   return;
  }
  const entry=this.saved.viewers.find(value=>value.pairing.viewerId===id);if(!entry)return;
  const hello=peer.pendingHello;peer.pendingHello=undefined;
  this.lastHelloByViewer.set(id,this.now());
  peer.cipher=new HostCipher(entry.pairing.captionSecret,hello);this.sendView(id,peer,null);this.notify();
 }
 private removePeer(id:string){
  const peer=this.peers.get(id);if(peer?.timer)clearTimeout(peer.timer);if(peer?.helloTimer)clearTimeout(peer.helloTimer);
  if(peer){peer.pendingHello=undefined;peer.cipher=undefined;}
  this.peers.delete(id);
 }
 private disconnect(){
  this.epoch++;if(this.retry)clearTimeout(this.retry);this.retry=undefined;
  const old=this.socket;this.socket=undefined;this.connected=false;
  for(const id of this.peers.keys())this.removePeer(id);
  this.lastHelloByViewer.clear();
  old?.terminate();
 }
 private transportFault(){this.disconnect();this.notify();this.schedule();}
 private schedule(){
  if(this.closed||this.terminal||this.retry||!this.saved.configuration)return;
  const seconds=[1,2,5,10,30][Math.min(this.attempts++,4)]!;
  this.retry=setTimeout(()=>{this.retry=undefined;this.connect();},Math.min(30000,seconds*1000*(.8+Math.random()*.4)));this.retry.unref();
 }
 private connect(){
  if(!this.initialized||this.closed||this.terminal||this.socket||!this.saved.configuration)return;
  const config=this.saved.configuration,epoch=++this.epoch;
  const socket=this.socket=new WebSocket(publisherWebSocketUrl(config.relayUrl,config.hostId,this.urls),{
   headers:{Authorization:`Bearer ${config.publisherToken}`},perMessageDeflate:false,maxPayload:LIMITS.frameBytes,handshakeTimeout:10000,followRedirects:false});
  const current=()=>!this.closed&&this.socket===socket&&this.epoch===epoch;
  socket.on('error',()=>{});
  socket.on('unexpected-response',(_request,response)=>{
   if(!current()){response.destroy();return;}
   if(response.statusCode===401||response.statusCode===403){this.terminal=true;this.stop();this.error={code:'RELAY_AUTH_FAILED',message:'Relay access was rejected. Check the host setup file, then reconnect.'};}
   response.destroy();this.transportFault();
  });
  socket.on('open',()=>{if(!current())return;this.connected=true;this.attempts=0;this.error=undefined;this.notify();
   void this.serial(()=>this.flushRegistry()).catch(()=>{if(current()){this.error={code:'VIEWER_SYNC_PENDING',message:'Some viewer changes are waiting for the relay. Reconnect to retry.'};this.notify();}});
  });
  socket.on('close',code=>{
   if(!current())return;
   if(code===4401||code===4403||code===4409){this.terminal=true;this.stop();this.error={code:'RELAY_ACCESS_STOPPED',message:code===4409?'Another host connected with this setup. Sharing stopped; reconnect here only if intended.':'Relay access was removed. Import valid host setup before reconnecting.'};}
   this.transportFault();
  });
  socket.on('message',(raw,binary)=>{
   if(!current())return;
   try{
    if(binary)throw Error();const value=parseJson(wire(raw));
    const type=(value as {type?:string})?.type;
    if(type==='hello'||type==='probe'){
     const message=validateViewerMessage(value);if(message.hostId!==config.hostId)throw Error();
     const entry=this.saved.viewers.find(v=>v.pairing.viewerId===message.viewerId);
     const peer=this.peers.get(message.viewerId);
     if(!entry||this.blocked.has(message.viewerId))return;
     if(!peer||peer.connectionId!==message.connectionId)throw Error();
     if(message.type==='hello'){
      if(peer.cipher?.route.challenge===message.challenge||peer.pendingHello?.challenge===message.challenge)throw Error();
      // Retire the old key immediately; keep only the latest hello while the device budget refills.
      peer.cipher=undefined;peer.pendingHello=message;peer.lastProbe=-Infinity;
      if(peer.timer)clearTimeout(peer.timer);peer.timer=undefined;
      this.acceptHello(message.viewerId,peer);this.notify();
     }else{
      // The first full view is the handshake response. Pre-view probes cannot use a retired key.
      if(!peer.cipher)return;
      if(this.now()-peer.lastProbe<LIMITS.minimumProbeIntervalMs)throw Error();peer.lastProbe=this.now();
      if(message.requestView)this.sendView(message.viewerId,peer,message.challenge);
      else{const {status,broadcastId,viewRevision}=this.current();this.send(message.viewerId,peer,{kind:'status',probe:message.challenge,status,broadcastId,viewRevision});}
     }
     return;
    }
    const message=validateRelayMessage(value);
    if(message.type==='connected')return;
    if(message.type==='viewer-connected'){
     if(!this.saved.viewers.some(v=>v.pairing.viewerId===message.viewerId)||this.blocked.has(message.viewerId))return;
     this.removePeer(message.viewerId);this.peers.set(message.viewerId,{connectionId:message.connectionId,lastProbe:-Infinity,lastSent:-Infinity});this.notify();return;
    }
    if(message.type==='viewer-disconnected'){if(this.peers.get(message.viewerId)?.connectionId===message.connectionId)this.removePeer(message.viewerId);this.notify();return;}
    if(message.type==='replaced'){this.terminal=true;this.stop();this.error={code:'RELAY_HOST_REPLACED',message:'Another host connected with this setup. Sharing stopped.'};this.transportFault();return;}
    throw Error();
   }catch{this.error={code:'RELAY_PROTOCOL_FAILED',message:'The relay sent an invalid message. Reconnecting without replaying caption history.'};this.transportFault();}
  });
 }
 private async request(method:'POST'|'DELETE',suffix:string,body?:unknown){
  const config=this.saved.configuration;if(!config)fail('SHARING_NOT_CONFIGURED','Import host setup first.');
  const controller=new AbortController();this.requests.add(controller);const timer=setTimeout(()=>controller.abort(),7000);timer.unref();
  try{
   const response=await fetch(`${config.relayUrl}/v1/hosts/${config.hostId}/viewers${suffix}`,{method,redirect:'error',signal:controller.signal,
    headers:{Authorization:`Bearer ${config.publisherToken}`,...(body?{'Content-Type':'application/json'}:{})},...(body?{body:JSON.stringify(body)}:{})});
   // Response content is unnecessary and is never reflected into diagnostics/UI.
   await response.body?.cancel();
   if(!response.ok)fail('RELAY_REQUEST_FAILED',response.status===401||response.status===403?'Relay access was rejected. Check the host setup.':'The relay could not apply the viewer change. Reconnect and retry.');
  }catch(error){if(error instanceof HostSharingError)throw error;fail('RELAY_UNAVAILABLE','The relay could not be reached. The viewer change is saved locally; reconnect and retry.');}
  finally{clearTimeout(timer);this.requests.delete(controller);}
 }
 private async register(entry:SavedViewer){
  await this.request('POST','',{viewerId:entry.pairing.viewerId,viewerToken:entry.pairing.viewerToken});if(this.closed)return;
  const next={...this.saved,viewers:this.saved.viewers.map(v=>v===entry?{...v,registered:true}:v)};await this.store.save(next);this.saved=next;this.notify();
 }
 private async revoke(id:string){
  await this.request('DELETE','/'+id);if(this.closed)return;
  const next={...this.saved,revocations:this.saved.revocations.filter(value=>value!==id)};await this.store.save(next);this.saved=next;this.blocked.delete(id);this.notify();
 }
 private async flushRegistry(){
  for(const id of [...this.saved.revocations]){if(this.closed)return;await this.revoke(id);}
  for(const entry of [...this.saved.viewers]){if(this.closed)return;if(!entry.registered&&!this.blocked.has(entry.pairing.viewerId))await this.register(entry);}
 }
}
