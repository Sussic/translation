import {lstat,mkdir,open,readFile,rename,unlink} from 'node:fs/promises';
import path from 'node:path';
import {randomUUID} from 'node:crypto';
import {LIMITS,validateHostConfiguration,validatePairingFile,validateId,type HostConfiguration,type PairingFile,type UrlOptions} from '@comms/sharing';
import type {CredentialEncryption} from '@siwc/local';

export class HostSharingError extends Error {
 constructor(public readonly code:string,message:string){super(message);this.name='HostSharingError';}
}
export interface SavedViewer {pairing:PairingFile;registered:boolean}
export interface SavedSharing {version:1;configuration?:HostConfiguration;viewers:SavedViewer[];revocations:string[]}
export const emptySharing=():SavedSharing=>({version:1,viewers:[],revocations:[]});
const MAX_STORAGE_BYTES=131072;
function validateSaved(value:unknown,options:UrlOptions):SavedSharing {
 if(!value||typeof value!=='object'||Array.isArray(value))throw new Error();
 const o=value as Record<string,unknown>;
 if(o.version!==1||Object.keys(o).some(k=>!['version','configuration','viewers','revocations'].includes(k))||!Array.isArray(o.viewers)||o.viewers.length>LIMITS.viewers||!Array.isArray(o.revocations)||o.revocations.length>128)throw new Error();
 const configuration=o.configuration===undefined?undefined:validateHostConfiguration(o.configuration,options);
 const ids=new Set<string>();
 const viewers=o.viewers.map(value=>{
  if(!value||typeof value!=='object'||Array.isArray(value))throw new Error();
  const row=value as Record<string,unknown>;
  if(Object.keys(row).length!==2||typeof row.registered!=='boolean')throw new Error();
  const pairing=validatePairingFile(row.pairing,options);
  if(!configuration||pairing.hostId!==configuration.hostId||pairing.relayUrl!==configuration.relayUrl||pairing.hostName!==configuration.hostName||ids.has(pairing.viewerId))throw new Error();
  ids.add(pairing.viewerId);return {pairing,registered:row.registered};
 });
 const revoked=new Set<string>();
 const revocations=o.revocations.map(value=>{const id=validateId(value);if(ids.has(id)||revoked.has(id))throw new Error();revoked.add(id);return id;});
 if(!configuration&&(viewers.length||revocations.length))throw new Error();
 return {version:1,...(configuration?{configuration}:{}),viewers,revocations};
}

/** Separate from ChatGPT storage. Every saved byte containing credentials is OS-encrypted. */
export class SharingStore {
 readonly filename:string;
 constructor(private directory:string,private encryption:CredentialEncryption,private urlOptions:UrlOptions={}){
  if(!path.isAbsolute(directory))throw new HostSharingError('SHARING_STORAGE_UNAVAILABLE','Sharing requires an absolute private storage directory.');
  this.filename=path.join(directory,'host-sharing.json');
 }
 private async requireEncryption(){if(!await this.encryption.isAvailable())throw new Error();}
 async load():Promise<SavedSharing>{
  try{
   await this.requireEncryption();
   let metadata;
   try{metadata=await lstat(this.filename);}catch(error){if((error as NodeJS.ErrnoException).code==='ENOENT')return emptySharing();throw error;}
   if(!metadata.isFile()||metadata.isSymbolicLink()||metadata.size>MAX_STORAGE_BYTES)throw new Error();
   const bytes=await readFile(this.filename);if(bytes.length>MAX_STORAGE_BYTES)throw new Error();
   const outer=JSON.parse(bytes.toString('utf8')) as Record<string,unknown>;
   if(!outer||Object.keys(outer).length!==3||outer.version!==1||outer.encryption!==this.encryption.id||typeof outer.ciphertext!=='string'||!outer.ciphertext.length)throw new Error();
   const ciphertext=Buffer.from(outer.ciphertext,'base64');if(ciphertext.toString('base64')!==outer.ciphertext||ciphertext.length>MAX_STORAGE_BYTES)throw new Error();
   const plaintext=await this.encryption.decrypt(ciphertext);if(Buffer.byteLength(plaintext)>MAX_STORAGE_BYTES)throw new Error();
   return validateSaved(JSON.parse(plaintext),this.urlOptions);
  }catch{throw new HostSharingError('SHARING_STORAGE_UNAVAILABLE','Saved sharing credentials could not be read with the operating system secret store. They were preserved.');}
 }
 async save(value:SavedSharing):Promise<void>{
  const temporary=path.join(this.directory,`.host-sharing-${randomUUID()}.tmp`);
  try{
   await this.requireEncryption();const valid=validateSaved(value,this.urlOptions);
   const encrypted=await this.encryption.encrypt(JSON.stringify(valid));
   if(!(encrypted instanceof Uint8Array)||!encrypted.byteLength)throw new Error();
   const ciphertext=Buffer.from(encrypted);
   const encoded=JSON.stringify({version:1,encryption:this.encryption.id,ciphertext:ciphertext.toString('base64')});
   if(Buffer.byteLength(encoded)>MAX_STORAGE_BYTES)throw new Error();
   await mkdir(this.directory,{recursive:true,mode:0o700});
   try{const info=await lstat(this.filename);if(!info.isFile()||info.isSymbolicLink())throw new Error();}catch(error){if((error as NodeJS.ErrnoException).code!=='ENOENT')throw error;}
   const file=await open(temporary,'wx',0o600);
   try{await file.writeFile(encoded,'utf8');await file.sync();}finally{await file.close();}
   await rename(temporary,this.filename);
  }catch{throw new HostSharingError('SHARING_STORAGE_UNAVAILABLE','Sharing credentials could not be saved with the operating system secret store.');}
  finally{await unlink(temporary).catch(()=>{});}
 }
}
