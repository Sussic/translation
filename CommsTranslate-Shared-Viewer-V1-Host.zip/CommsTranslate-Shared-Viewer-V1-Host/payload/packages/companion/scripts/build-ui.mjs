import { build } from 'esbuild';
await build({entryPoints:['src/preload.ts'],outfile:'dist/preload.cjs',bundle:true,platform:'node',format:'cjs',target:'node22',external:['electron']});
// Ship the sharing output as one module: host updates need no dependency reinstall.
await build({entryPoints:['src/sharing/service.ts'],outfile:'dist/sharing/service.js',bundle:true,platform:'node',format:'esm',target:'node22',external:['electron','bufferutil','utf-8-validate'],banner:{js:"import { createRequire as sharingCreateRequire } from 'node:module'; const require = sharingCreateRequire(import.meta.url);"}});
