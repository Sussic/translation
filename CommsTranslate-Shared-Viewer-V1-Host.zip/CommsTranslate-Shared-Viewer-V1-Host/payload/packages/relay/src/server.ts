import http, {type IncomingMessage, type ServerResponse} from 'node:http';
import {randomBytes} from 'node:crypto';
import {performance} from 'node:perf_hooks';
import {WebSocket, WebSocketServer, type RawData} from 'ws';
import {parseViewerMessage, parseSealedFrame, validateProvisionViewer, parseJson, LIMITS, CLOSE_CODES} from '@comms/sharing';
import {Registry, RegistryError} from './registry.js';

const FRAME_LIMIT = LIMITS.frameBytes, QUEUE_LIMIT = LIMITS.pendingBytes;
const idPattern = '[A-Za-z0-9_-]{22}';
const newId = (): string => randomBytes(16).toString('base64url');
const canonical = (value: string, bytes: number): boolean => value.length === Math.ceil(bytes * 4 / 3)
    && Buffer.from(value, 'base64url').length === bytes && Buffer.from(value, 'base64url').toString('base64url') === value;
type Viewer = {socket: WebSocket; hostId: string; viewerId: string; connectionId: string; hello: string | null;
    lastChallenge: string | null; lastHello: number; lastProbe: number; pendingProbe: {challenge: string; at: number} | null; pong: boolean};
type Publisher = {socket: WebSocket; pong: boolean; tokens: number; updated: number};
type Host = {publisher: Publisher | null; viewers: Map<string, Viewer>};

class Buckets {
    private readonly values = new Map<string, {tokens: number; updated: number}>();
    take(key: string, now: number): boolean {
        if (this.values.size >= 4096) for (const [name, entry] of this.values) if (now - entry.updated > 120000) this.values.delete(name);
        let entry = this.values.get(key);
        if (!entry) {
            if (this.values.size >= 4096) return false;
            entry = {tokens: 90, updated: now}; this.values.set(key, entry);
        }
        entry.tokens = Math.min(90, entry.tokens + Math.max(0, now - entry.updated) * 0.003);
        entry.updated = now;
        if (entry.tokens < 1) return false;
        entry.tokens--; return true;
    }
}

function bearer(request: IncomingMessage): string | null {
    let count = 0;
    for (let i = 0; i < request.rawHeaders.length; i += 2) if (request.rawHeaders[i]?.toLowerCase() === 'authorization') count++;
    if (count !== 1) return null;
    const token = /^Bearer ([A-Za-z0-9_-]{43})$/.exec(request.headers.authorization ?? '')?.[1];
    return token && canonical(token, 32) ? token : null;
}
function reply(response: ServerResponse, status: number, value?: object): void {
    response.writeHead(status, {'Cache-Control': 'no-store', 'Content-Type': 'application/json', 'X-Content-Type-Options': 'nosniff'});
    response.end(value ? JSON.stringify(value) : undefined);
}
function disconnect(socket: WebSocket, code: number, reason: string): void {
    if (socket.readyState === WebSocket.OPEN) socket.close(code, reason);
    const timeout = setTimeout(() => socket.terminate(), 1000); timeout.unref();
    socket.once('close', () => clearTimeout(timeout));
}
export function sendBounded(socket: WebSocket, message: object | string): boolean {
    if (socket.readyState !== WebSocket.OPEN) return false;
    const data = typeof message === 'string' ? message : JSON.stringify(message);
    const length = Buffer.byteLength(data);
    if (length > FRAME_LIMIT || socket.bufferedAmount + length + 14 > QUEUE_LIMIT) {
        disconnect(socket, CLOSE_CODES.slow, 'Slow receiver'); return false;
    }
    socket.send(data, {compress: false}, error => { if (error) socket.terminate(); });
    return true;
}
const send = sendBounded;
async function body(request: IncomingMessage): Promise<string> {
    let size = 0; const chunks: Buffer[] = [];
    for await (const chunk of request) {
        const data = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk);
        size += data.length;
        if (size > 4096) throw new Error('Body limit');
        chunks.push(data);
    }
    return Buffer.concat(chunks).toString('utf8');
}
const wire = (data: RawData): Uint8Array => Array.isArray(data) ? Buffer.concat(data) : data instanceof ArrayBuffer ? new Uint8Array(data) : data;

export interface RelayOptions {
    registry: Registry;
    /** Binding is explicit. Production runs behind the included TLS proxy. */
    bind: string;
    port: number;
    now?: () => number;
    heartbeatMs?: number;
}

export function createRelay(options: RelayOptions) {
    const hosts = new Map<string, Host>();
    const now = options.now ?? (() => performance.now());
    const buckets = new Buckets();
    const sockets = new WebSocketServer({noServer: true, maxPayload: FRAME_LIMIT, perMessageDeflate: false, clientTracking: true});
    const getHost = (hostId: string): Host => {
        let value = hosts.get(hostId);
        if (!value) { value = {publisher: null, viewers: new Map()}; hosts.set(hostId, value); }
        return value;
    };
    const cleanup = (hostId: string, host: Host) => { if (!host.publisher && !host.viewers.size) hosts.delete(hostId); };
    const admitted = (request: IncomingMessage) => buckets.take(request.socket.remoteAddress ?? 'unknown', now());
    const limitControlFrames = (socket: WebSocket) => {
        let since = now(), count = 0;
        const check = () => {
            const current = now(); if (current - since >= 1000) { since = current; count = 0; }
            if (++count > 8) disconnect(socket, CLOSE_CODES.invalid, 'Control frame limit');
        };
        socket.on('ping', check); socket.on('pong', check);
    };

    const server = http.createServer({maxHeaderSize: 8192, requestTimeout: 10000, headersTimeout: 10000}, (request, response) => {
        void (async () => {
            const url = request.url ?? '';
            if (url === '/health' && request.method === 'GET') { reply(response, 200, {status: 'ok', v: 1}); return; }
            if (!admitted(request)) { reply(response, 429, {error: 'rate-limit'}); return; }
            const route = new RegExp(`^/v1/hosts/(${idPattern})/viewers(?:/(${idPattern}))?$`).exec(url);
            if (!route) { reply(response, 404, {error: 'not-found'}); return; }
            const hostId = route[1]!; const viewerId = route[2]; const token = bearer(request);
            if (!canonical(hostId, 16) || !token || !options.registry.authenticatePublisher(hostId, token)) { reply(response, 401, {error: 'unauthorized'}); return; }
            if (request.method === 'POST' && !viewerId) {
                let registration: {viewerId: string; viewerToken: string};
                try { registration = validateProvisionViewer(parseJson(await body(request), LIMITS.pairingBytes)); }
                catch { reply(response, 400, {error: 'invalid-registration'}); return; }
                try {
                    options.registry.registerViewer(hostId, registration.viewerId, registration.viewerToken);
                    reply(response, 200, {v: 1, viewerId: registration.viewerId});
                } catch (error) {
                    if (error instanceof RegistryError) reply(response, error.code === 'limit' ? 409 : 409, {error: error.code});
                    else reply(response, 503, {error: 'registry-unavailable'});
                }
                return;
            }
            if (request.method === 'DELETE' && viewerId && canonical(viewerId, 16)) {
                options.registry.revokeViewer(hostId, viewerId);
                const viewer = hosts.get(hostId)?.viewers.get(viewerId);
                if (viewer) {
                    // Remove routing authority before the close handshake finishes.
                    const host = hosts.get(hostId)!; host.viewers.delete(viewerId);
                    if (host.publisher) send(host.publisher.socket, {v: 1, type: 'viewer-disconnected', viewerId, connectionId: viewer.connectionId});
                    disconnect(viewer.socket, 4403, 'Pairing revoked'); cleanup(hostId, host);
                }
                reply(response, 204); return;
            }
            reply(response, 405, {error: 'method-not-allowed'});
        })().catch(() => { if (!response.headersSent) reply(response, 503, {error: 'relay-unavailable'}); else response.destroy(); });
    });
    server.maxHeadersCount = 32;
    server.maxConnections = 256;
    server.maxRequestsPerSocket = 100;
    server.on('clientError', (_error, socket) => { if (socket.writable) socket.end('HTTP/1.1 400 Bad Request\r\nConnection: close\r\n\r\n'); });

    function attachPublisher(socket: WebSocket, hostId: string): void {
        limitControlFrames(socket);
        const host = getHost(hostId);
        if (host.publisher) disconnect(host.publisher.socket, 4409, 'Publisher replaced');
        const publisher: Publisher = {socket, pong: true, tokens: 200, updated: now()}; host.publisher = publisher;
        for (const viewer of host.viewers.values()) {
            viewer.hello = null; viewer.pendingProbe = null;
            // A new publisher requires a fresh hello even if the prior epoch ended
            // within the handshake interval. Keep the rate limit within this epoch.
            viewer.lastHello = -Infinity;
            send(socket, {v: 1, type: 'viewer-connected', viewerId: viewer.viewerId, connectionId: viewer.connectionId});
            send(viewer.socket, {v: 1, type: 'publisher-ready'});
        }
        socket.on('pong', () => { publisher.pong = true; });
        socket.on('error', () => {});
        socket.on('message', (raw, binary) => {
            if (host.publisher !== publisher) return;
            const current = now(); publisher.tokens = Math.min(200, publisher.tokens + Math.max(0, current - publisher.updated) * 0.1); publisher.updated = current;
            if (binary || publisher.tokens < 1) { disconnect(socket, CLOSE_CODES.invalid, 'Protocol limit'); return; }
            publisher.tokens--;
            let frame: ReturnType<typeof parseSealedFrame>;
            try { frame = parseSealedFrame(wire(raw)); } catch { disconnect(socket, CLOSE_CODES.invalid, 'Invalid frame'); return; }
            if (frame.hostId !== hostId) { disconnect(socket, CLOSE_CODES.invalid, 'Invalid route'); return; }
            const viewer = host.viewers.get(frame.viewerId);
            if (!viewer || frame.connectionId !== viewer.connectionId || !viewer.hello || frame.challenge !== viewer.hello) return;
            if (frame.replyTo !== null) {
                if (!viewer.pendingProbe || viewer.pendingProbe.challenge !== frame.replyTo || current - viewer.pendingProbe.at > LIMITS.leaseMs) return;
                viewer.pendingProbe = null;
            }
            send(viewer.socket, JSON.stringify(frame));
        });
        socket.once('close', () => {
            if (host.publisher !== publisher) return;
            host.publisher = null;
            for (const viewer of host.viewers.values()) { viewer.hello = null; viewer.pendingProbe = null; send(viewer.socket, {v: 1, type: 'host-offline'}); }
            cleanup(hostId, host);
        });
    }

    function attachViewer(socket: WebSocket, hostId: string, viewerId: string): void {
        limitControlFrames(socket);
        const host = getHost(hostId), previous = host.viewers.get(viewerId);
        if (previous) { send(previous.socket, {v: 1, type: 'replaced'}); disconnect(previous.socket, 4409, 'Connected elsewhere'); }
        const viewer: Viewer = {socket, hostId, viewerId, connectionId: newId(), hello: null, lastChallenge: null,
            lastHello: -Infinity, lastProbe: -Infinity, pendingProbe: null, pong: true};
        host.viewers.set(viewerId, viewer);
        send(socket, {v: 1, type: 'connected', connectionId: viewer.connectionId});
        if (host.publisher) {
            send(host.publisher.socket, {v: 1, type: 'viewer-connected', viewerId, connectionId: viewer.connectionId});
        } else send(socket, {v: 1, type: 'host-offline'});
        socket.on('pong', () => { viewer.pong = true; }); socket.on('error', () => {});
        socket.on('message', (raw, binary) => {
            if (host.viewers.get(viewerId) !== viewer) return;
            if (binary) { disconnect(socket, CLOSE_CODES.invalid, 'Text protocol required'); return; }
            let message: ReturnType<typeof parseViewerMessage>;
            try { message = parseViewerMessage(wire(raw)); } catch { disconnect(socket, CLOSE_CODES.invalid, 'Invalid frame'); return; }
            if (message.hostId !== hostId || message.viewerId !== viewerId || message.connectionId !== viewer.connectionId) { disconnect(socket, CLOSE_CODES.invalid, 'Invalid route'); return; }
            const current = now();
            if (message.type === 'hello') {
                if (current - viewer.lastHello < LIMITS.handshakeIntervalMs || message.challenge === viewer.lastChallenge) { disconnect(socket, CLOSE_CODES.invalid, 'Handshake limit'); return; }
                viewer.lastHello = current; viewer.lastChallenge = message.challenge; viewer.hello = message.challenge; viewer.pendingProbe = null;
            } else {
                if (!viewer.hello || current - viewer.lastProbe < LIMITS.minimumProbeIntervalMs || (viewer.pendingProbe && current - viewer.pendingProbe.at <= LIMITS.leaseMs)) { disconnect(socket, CLOSE_CODES.invalid, 'Liveness limit'); return; }
                viewer.lastProbe = current; viewer.pendingProbe = {challenge: message.challenge, at: current};
            }
            if (host.publisher) send(host.publisher.socket, JSON.stringify(message));
        });
        socket.once('close', () => {
            if (host.viewers.get(viewerId) !== viewer) return;
            host.viewers.delete(viewerId);
            if (host.publisher) send(host.publisher.socket, {v: 1, type: 'viewer-disconnected', viewerId, connectionId: viewer.connectionId});
            cleanup(hostId, host);
        });
    }

    server.on('upgrade', (request, socket, head) => {
        if (!admitted(request)) { socket.end('HTTP/1.1 429 Too Many Requests\r\nConnection: close\r\n\r\n'); return; }
        const route = new RegExp(`^/v1/hosts/(${idPattern})/(publisher|viewers/(${idPattern}))$`).exec(request.url ?? '');
        const token = bearer(request);
        let allowed = false;
        if (route && token && canonical(route[1]!, 16) && !request.headers.origin) {
            try { allowed = route[2] === 'publisher' ? options.registry.authenticatePublisher(route[1]!, token)
                : canonical(route[3]!, 16) && options.registry.authenticateViewer(route[1]!, route[3]!, token); } catch {}
        }
        if (!allowed || !route) { socket.end('HTTP/1.1 401 Unauthorized\r\nConnection: close\r\nCache-Control: no-store\r\n\r\n'); return; }
        sockets.handleUpgrade(request, socket, head, connected => {
            if (route[2] === 'publisher') attachPublisher(connected, route[1]!);
            else attachViewer(connected, route[1]!, route[3]!);
        });
    });

    const heartbeat = setInterval(() => {
        for (const host of hosts.values()) {
            const connections = [...host.viewers.values(), ...(host.publisher ? [host.publisher] : [])];
            for (const peer of connections) { if (!peer.pong) peer.socket.terminate(); else { peer.pong = false; peer.socket.ping(); } }
        }
    }, options.heartbeatMs ?? 30000); heartbeat.unref();

    return {
        server,
        async listen(): Promise<number> {
            await new Promise<void>((resolve, reject) => { server.once('error', reject); server.listen(options.port, options.bind, () => { server.off('error', reject); resolve(); }); });
            const address = server.address(); if (!address || typeof address === 'string') throw new Error('No listening port'); return address.port;
        },
        async close(): Promise<void> {
            clearInterval(heartbeat); for (const socket of sockets.clients) socket.terminate();
            await new Promise<void>(resolve => sockets.close(() => resolve()));
            server.closeAllConnections(); await new Promise<void>(resolve => server.close(() => resolve()));
        }
    };
}
