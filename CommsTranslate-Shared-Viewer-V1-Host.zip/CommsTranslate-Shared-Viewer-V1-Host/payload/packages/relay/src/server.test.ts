import test, {type TestContext} from 'node:test';
import assert from 'node:assert/strict';
import {once} from 'node:events';
import {WebSocket} from 'ws';
import {newId, newSecret, HostCipher, ViewerCipher, CLOSE_CODES} from '@comms/sharing';
import {Registry} from './registry.js';
import {createRelay, sendBounded} from './server.js';

type Message = Record<string, any>;
class Peer {
    readonly socket: WebSocket;
    private queue: Message[] = [];
    private listeners = new Set<() => void>();
    constructor(url: string, token: string) {
        this.socket = new WebSocket(url, {headers: {Authorization: 'Bearer ' + token}});
        this.socket.on('message', raw => { this.queue.push(JSON.parse(raw.toString())); for (const listener of this.listeners) listener(); });
        this.socket.on('error', () => {});
    }
    async open(): Promise<void> { await once(this.socket, 'open'); }
    send(value: unknown): void { this.socket.send(JSON.stringify(value)); }
    hasQueued(type: string): boolean { return this.queue.some(message => message.type === type); }
    take(type: string): Promise<Message> {
        return new Promise((resolve, reject) => {
            const timer = setTimeout(() => { this.listeners.delete(check); reject(new Error('Timed out waiting for ' + type)); }, 3000);
            const check = () => {
                const index = this.queue.findIndex(message => message.type === type);
                if (index < 0) return;
                clearTimeout(timer); this.listeners.delete(check); resolve(this.queue.splice(index, 1)[0]!);
            };
            this.listeners.add(check); check();
        });
    }
}

async function fixture(t: TestContext) {
    const registry = new Registry(':memory:'), hostId = newId(), publisherToken = newSecret();
    registry.provision(hostId, publisherToken);
    let tick = 10000;
    const relay = createRelay({registry, bind: '127.0.0.1', port: 0, now: () => tick});
    const port = await relay.listen();
    t.after(async () => { await relay.close(); registry.close(); });
    const http = 'http://127.0.0.1:' + port, ws = 'ws://127.0.0.1:' + port;
    const publisher = async () => { const peer = new Peer(ws + `/v1/hosts/${hostId}/publisher`, publisherToken); await peer.open(); return peer; };
    const viewer = async (id = newId(), token = newSecret()) => {
        registry.registerViewer(hostId, id, token);
        const peer = new Peer(ws + `/v1/hosts/${hostId}/viewers/${id}`, token); await peer.open();
        const ready = await peer.take('connected');
        return {peer, viewerId: id, token, connectionId: ready.connectionId as string};
    };
    return {registry, relay, hostId, publisherToken, publisher, viewer, http, ws, advance: (ms: number) => { tick += ms; }};
}

const hello = (hostId: string, viewer: {viewerId: string; connectionId: string}, challenge = newSecret()) => ({v: 1 as const, type: 'hello' as const, hostId, viewerId: viewer.viewerId, connectionId: viewer.connectionId, challenge});
async function unauthorized(url: string, token: string): Promise<number> {
    const socket = new WebSocket(url, {headers: {Authorization: 'Bearer ' + token}});
    socket.on('error', () => {});
    return await new Promise(resolve => {
        socket.once('unexpected-response', (_request, response) => { response.resume(); resolve(response.statusCode!); socket.terminate(); });
    });
}

test('real sockets enforce publisher/viewer separation and HTTP admin authorization', async t => {
    const f = await fixture(t); const v = await f.viewer();
    assert.equal(await unauthorized(f.ws + `/v1/hosts/${f.hostId}/publisher`, v.token), 401);
    assert.equal(await unauthorized(f.ws + `/v1/hosts/${f.hostId}/viewers/${v.viewerId}`, f.publisherToken), 401);
    const response = await fetch(f.http + `/v1/hosts/${f.hostId}/viewers`, {method: 'POST', headers: {Authorization: 'Bearer ' + v.token}, body: JSON.stringify({viewerId: newId(), viewerToken: newSecret()})});
    assert.equal(response.status, 401);
    const invalid = await fetch(f.http + `/v1/hosts/${f.hostId}/viewers`, {method: 'POST', headers: {Authorization: 'Bearer ' + f.publisherToken}, body: '{"viewerId":"x","viewerId":"y","viewerToken":"x"}'});
    assert.equal(invalid.status, 400);
    const valid = await fetch(f.http + `/v1/hosts/${f.hostId}/viewers`, {method: 'POST', headers: {Authorization: 'Bearer ' + f.publisherToken}, body: JSON.stringify({viewerId: newId(), viewerToken: newSecret()})});
    assert.equal(valid.status, 200);
});

test('real encrypted frames route only after hello; publisher reconnect requires fresh state without history', async t => {
    const f = await fixture(t), pub = await f.publisher(), v = await f.viewer();
    await pub.take('viewer-connected');
    const h = hello(f.hostId, v), secret = newSecret(); v.peer.send(h); assert.deepEqual(await pub.take('hello'), h);
    const cipher = new HostCipher(secret, h), receiver = new ViewerCipher(secret, h);
    pub.send(cipher.seal({kind: 'view', probe: null, status: 'sharing', broadcastId: newId(), viewRevision: 1, outputLanguage: 'en', rows: [{id: newId(), revision: 1, text: 'Test encrypted caption', remainingMs: 15000, provisional: false}]}));
    const received = receiver.open(JSON.stringify(await v.peer.take('sealed')));
    assert.equal(received.kind === 'view' && received.rows[0]?.text, 'Test encrypted caption');
    assert.equal(v.peer.hasQueued('publisher-ready'), false, 'initial connected notice must be the only hello trigger');
    const closed = once(pub.socket, 'close'); pub.socket.close(); await closed; await v.peer.take('host-offline');
    const next = await f.publisher(); await next.take('viewer-connected'); await v.peer.take('publisher-ready');
    next.send(cipher.seal({kind: 'view', probe: null, status: 'sharing', broadcastId: newId(), viewRevision: 2, outputLanguage: 'en', rows: []}));
    // No clock advance: a publisher epoch change authorizes an immediate fresh hello.
    const fresh = hello(f.hostId, v); v.peer.send(fresh); assert.deepEqual(await next.take('hello'), fresh);
    next.send(cipher.seal({kind: 'view', probe: null, status: 'sharing', broadcastId: newId(), viewRevision: 3, outputLanguage: 'en', rows: []}));
    const freshCipher = new HostCipher(secret, fresh);
    next.send(freshCipher.seal({kind: 'view', probe: null, status: 'off', broadcastId: null, viewRevision: 2, outputLanguage: 'en', rows: []}));
    const after = await v.peer.take('sealed'); assert.equal(after.challenge, fresh.challenge);
});

test('publisher arrival resets an offline hello limit but same-epoch hellos remain limited', async t => {
    const f = await fixture(t), v = await f.viewer();
    await v.peer.take('host-offline');
    v.peer.send(hello(f.hostId, v));
    // A pong on the same socket confirms the offline hello was processed first.
    const pong = once(v.peer.socket, 'pong'); v.peer.socket.ping(); await pong;
    const pub = await f.publisher(); await pub.take('viewer-connected'); await v.peer.take('publisher-ready');
    const fresh = hello(f.hostId, v); v.peer.send(fresh); assert.deepEqual(await pub.take('hello'), fresh);
    const closed = once(v.peer.socket, 'close'); v.peer.send(hello(f.hostId, v));
    assert.equal((await closed)[0], CLOSE_CODES.invalid);
});

test('duplicate viewer is displaced once and revoked credentials cannot reconnect', async t => {
    const f = await fixture(t), pub = await f.publisher(), first = await f.viewer(); await pub.take('viewer-connected');
    const close = once(first.peer.socket, 'close'); const second = await f.viewer(first.viewerId, first.token);
    await first.peer.take('replaced'); assert.equal((await close)[0], CLOSE_CODES.replaced);
    const event = await pub.take('viewer-connected'); assert.equal(event.connectionId, second.connectionId); assert.notEqual(first.connectionId, second.connectionId);
    const revoked = once(second.peer.socket, 'close');
    const response = await fetch(f.http + `/v1/hosts/${f.hostId}/viewers/${second.viewerId}`, {method: 'DELETE', headers: {Authorization: 'Bearer ' + f.publisherToken}});
    assert.equal(response.status, 204); assert.equal((await revoked)[0], CLOSE_CODES.revoked);
    assert.equal(await unauthorized(f.ws + `/v1/hosts/${f.hostId}/viewers/${second.viewerId}`, second.token), 401);
});

test('viewer RPC, spoofed connection identity and oversized frames are rejected without reaching publisher', async t => {
    const f = await fixture(t); await f.publisher();
    for (const kind of ['rpc', 'route', 'oversized']) {
        const v = await f.viewer(); const closed = once(v.peer.socket, 'close');
        if (kind === 'rpc') v.peer.send({v: 1, type: 'settings.patch', settings: {sourceLanguage: 'pl'}});
        else if (kind === 'route') v.peer.send({...hello(f.hostId, v), connectionId: newId()});
        else v.peer.socket.send('x'.repeat(8193));
        const [code] = await closed; assert.ok(code === CLOSE_CODES.invalid || code === 1009);
    }
});

test('one outstanding probe is enforced and an unrelated sealed reply cannot clear it', async t => {
    const f = await fixture(t), pub = await f.publisher(), v = await f.viewer(); await pub.take('viewer-connected');
    const h = hello(f.hostId, v); v.peer.send(h); await pub.take('hello');
    const probe = {...h, type: 'probe', challenge: newSecret(), requestView: false}; v.peer.send(probe); await pub.take('probe');
    const cipher = new HostCipher(newSecret(), h);
    pub.send(cipher.seal({kind: 'status', probe: newSecret(), status: 'off', broadcastId: null, viewRevision: 1}));
    f.advance(3001); const closed = once(v.peer.socket, 'close');
    v.peer.send({...probe, challenge: newSecret()}); assert.equal((await closed)[0], CLOSE_CODES.invalid);
});

test('valid probe reply releases the pending gate and twenty real viewers can connect', async t => {
    const f = await fixture(t), pub = await f.publisher(), viewers = [];
    for (let i = 0; i < 20; i++) viewers.push(await f.viewer());
    const v = viewers[0]!, h = hello(f.hostId, v); v.peer.send(h); await pub.take('hello');
    const probe = {...h, type: 'probe', challenge: newSecret(), requestView: false}; v.peer.send(probe); await pub.take('probe');
    const cipher = new HostCipher(newSecret(), h); pub.send(cipher.seal({kind: 'status', probe: probe.challenge, status: 'off', broadcastId: null, viewRevision: 1}));
    await v.peer.take('sealed'); f.advance(1001);
    v.peer.send({...probe, challenge: newSecret()}); await pub.take('probe');
    assert.equal(v.peer.socket.readyState, WebSocket.OPEN);
});

test('outbound queue bound disconnects a slow viewer before adding another frame', () => {
    let sent = false, code = 0;
    const socket = {readyState: WebSocket.OPEN, bufferedAmount: 32760,
        close: (value: number) => { code = value; }, terminate: () => {},
        once: (_event: string, callback: () => void) => { callback(); },
        send: () => { sent = true; }} as unknown as WebSocket;
    assert.equal(sendBounded(socket, {v: 1, type: 'host-offline'}), false);
    assert.equal(code, CLOSE_CODES.slow); assert.equal(sent, false);
});
