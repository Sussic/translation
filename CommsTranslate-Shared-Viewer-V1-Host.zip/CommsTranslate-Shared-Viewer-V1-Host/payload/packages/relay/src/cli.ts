import fs from 'node:fs/promises';
import path from 'node:path';
import {randomBytes} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {validateHostConfiguration} from '@comms/sharing';
import {Registry} from './registry.js';
import {createRelay} from './server.js';

export function relayOrigin(value: string, dev: boolean): string {
    const parsed = new URL(value);
    const loopback = ['127.0.0.1', '[::1]', 'localhost'].includes(parsed.hostname);
    if ((parsed.protocol !== 'https:' && !(dev && parsed.protocol === 'http:' && loopback))
        || parsed.username || parsed.password || parsed.search || parsed.hash || parsed.pathname !== '/') throw new Error('INVALID_RELAY_ORIGIN');
    return parsed.origin;
}

export async function provision(options: {db: string; output: string; relayUrl: string; hostName: string; dev?: boolean}): Promise<void> {
    const relayUrl = relayOrigin(options.relayUrl, options.dev === true);
    if (!options.hostName.trim() || options.hostName.length > 80 || /[\u0000-\u001f\u007f]/.test(options.hostName)) throw new Error('INVALID_HOST_NAME');
    const hostId = randomBytes(16).toString('base64url'), publisherToken = randomBytes(32).toString('base64url');
    const output = path.resolve(options.output);
    await fs.mkdir(path.dirname(path.resolve(options.db)), {recursive: true, mode: 0o700});
    const registry = new Registry(options.db);
    let created = false;
    try {
        // Exclusive creation preserves an existing private setup file.
        const config = validateHostConfiguration({format: 'CommsTranslateHost', version: 1, relayUrl, hostId,
            publisherToken, hostName: options.hostName.trim()}, {allowInsecureLoopback: options.dev === true});
        await fs.writeFile(output, JSON.stringify(config, null, 2) + '\n', {flag: 'wx', mode: 0o600});
        created = true;
        registry.provision(hostId, publisherToken);
    } catch (error) {
        if (created) await fs.rm(output, {force: true});
        throw error;
    } finally { registry.close(); }
}

export async function main(args = process.argv.slice(2)): Promise<void> {
    process.umask(0o077);
    if (Number(process.versions.node.split('.')[0]) < 24) throw new Error('NODE_24_REQUIRED');
    const command = args.shift(); const flags = new Map<string, string>();
    for (let i = 0; i < args.length; i++) {
        const name = args[i];
        if (name === '--dev-loopback') { flags.set(name, 'true'); continue; }
        if (!name?.startsWith('--') || !args[i + 1] || args[i + 1]!.startsWith('--') || flags.has(name)) throw new Error('INVALID_ARGUMENTS');
        flags.set(name, args[++i]!);
    }
    const allowed = command === 'serve' ? ['--db', '--mode', '--bind', '--port', '--public-url']
        : ['--db', '--out', '--relay-url', '--host-name', '--dev-loopback'];
    if ([...flags.keys()].some(flag => !allowed.includes(flag))) throw new Error('INVALID_ARGUMENTS');
    const db = flags.get('--db') ?? process.env.RELAY_DB;
    if (!db) throw new Error('DATABASE_PATH_REQUIRED');
    if (command === 'provision') {
        const output = flags.get('--out'), relayUrl = flags.get('--relay-url'), hostName = flags.get('--host-name');
        if (!output || !relayUrl || !hostName) throw new Error('PROVISION_ARGUMENTS_REQUIRED');
        await provision({db, output, relayUrl, hostName, dev: flags.has('--dev-loopback')});
        console.log('Private host setup file created. Transfer it only to the host; never send it to viewers.');
        return;
    }
    if (command !== 'serve') throw new Error('Use serve or provision. See packages/relay/README.md.');
    const mode = flags.get('--mode') ?? process.env.RELAY_MODE;
    const bind = flags.get('--bind') ?? process.env.RELAY_BIND ?? '127.0.0.1';
    const port = Number(flags.get('--port') ?? process.env.RELAY_PORT ?? '8787');
    if (!Number.isInteger(port) || port < 1 || port > 65535) throw new Error('INVALID_PORT');
    if (mode !== 'tls-proxy' && mode !== 'loopback-development') throw new Error('EXPLICIT_RELAY_MODE_REQUIRED');
    if (mode === 'loopback-development' && !['127.0.0.1', '::1'].includes(bind)) throw new Error('DEVELOPMENT_REQUIRES_LOOPBACK_BIND');
    if (mode === 'tls-proxy') relayOrigin(flags.get('--public-url') ?? process.env.RELAY_PUBLIC_URL ?? '', false);
    await fs.mkdir(path.dirname(path.resolve(db)), {recursive: true, mode: 0o700});
    const registry = new Registry(db), relay = createRelay({registry, bind, port});
    try { await relay.listen(); } catch (error) { registry.close(); throw error; }
    console.log('CommsTranslate relay listening. Caption bodies, credentials and request URLs are not logged.');
    let closing = false;
    const close = () => {
        if (closing) return; closing = true;
        void relay.close().finally(() => registry.close());
    };
    process.once('SIGINT', close); process.once('SIGTERM', close);
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
    main().catch(error => {
        const code = error instanceof Error && /^[A-Z_0-9]+$/.test(error.message) ? error.message
            : ['EACCES', 'EEXIST', 'ENOENT', 'EADDRINUSE'].includes(error?.code) ? error.code : 'RELAY_COMMAND_FAILED';
        console.error(code + ': Check packages/relay/README.md, arguments, database access and configured port. No secrets were printed.');
        process.exitCode = 1;
    });
}
