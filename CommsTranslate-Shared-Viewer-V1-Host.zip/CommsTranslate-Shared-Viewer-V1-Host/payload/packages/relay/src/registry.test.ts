import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import {newId, newSecret, parseHostConfiguration} from '@comms/sharing';
import {Registry, RegistryError} from './registry.js';
import {provision, relayOrigin} from './cli.js';

test('registry persists only hashes, separates roles/hosts, and keeps revocation after restart', async t => {
    const root = await fs.mkdtemp(path.join(os.tmpdir(), 'relay-registry-'));
    t.after(() => fs.rm(root, {recursive: true, force: true}));
    const db = path.join(root, 'registry.sqlite'); let registry = new Registry(db);
    const host = newId(), other = newId(), publisher = newSecret(), viewer = newId(), token = newSecret();
    registry.provision(host, publisher); registry.provision(other, newSecret());
    registry.registerViewer(host, viewer, token);
    assert.equal(registry.authenticatePublisher(host, token), false);
    assert.equal(registry.authenticateViewer(host, viewer, publisher), false);
    assert.equal(registry.authenticateViewer(other, viewer, token), false);
    assert.equal(registry.authenticateViewer(host, viewer, token), true);
    registry.close(); registry = new Registry(db);
    assert.equal(registry.authenticatePublisher(host, publisher), true);
    registry.revokeViewer(host, viewer); registry.close(); registry = new Registry(db);
    assert.equal(registry.authenticateViewer(host, viewer, token), false);
    assert.throws(() => registry.registerViewer(host, viewer, token), RegistryError);
    registry.close();
    const bytes = await fs.readFile(db);
    assert.equal(bytes.includes(publisher), false); assert.equal(bytes.includes(token), false);
});

test('twenty active viewers are enforced atomically and idempotent registration does not consume a slot', () => {
    const registry = new Registry(':memory:');
    try {
        const host = newId(), first = newId(), token = newSecret(); registry.provision(host, newSecret());
        assert.equal(registry.registerViewer(host, first, token), 'created');
        assert.equal(registry.registerViewer(host, first, token), 'existing');
        for (let i = 1; i < 20; i++) registry.registerViewer(host, newId(), newSecret());
        assert.throws(() => registry.registerViewer(host, newId(), newSecret()), (error: unknown) => error instanceof RegistryError && error.code === 'limit');
        registry.revokeViewer(host, first);
        assert.equal(registry.registerViewer(host, newId(), newSecret()), 'created');
    } finally { registry.close(); }
});

test('provisioning writes an exclusive private host config and requires HTTPS outside explicit loopback development', async t => {
    const root = await fs.mkdtemp(path.join(os.tmpdir(), 'relay-provision-'));
    t.after(() => fs.rm(root, {recursive: true, force: true}));
    const db = path.join(root, 'registry.sqlite'), output = path.join(root, 'host.commshost');
    await provision({db, output, relayUrl: 'https://captions.example', hostName: 'Test host'});
    const config = parseHostConfiguration(await fs.readFile(output));
    const registry = new Registry(db);
    assert.equal(registry.authenticatePublisher(config.hostId, config.publisherToken), true); registry.close();
    const prior = await fs.readFile(output);
    await assert.rejects(provision({db, output, relayUrl: 'https://captions.example', hostName: 'Another host'}));
    assert.deepEqual(await fs.readFile(output), prior);
    if (process.platform !== 'win32') assert.equal((await fs.stat(output)).mode & 0o777, 0o600);
    assert.throws(() => relayOrigin('http://example.com', false));
    assert.throws(() => relayOrigin('https://example.com/path', false));
    assert.throws(() => relayOrigin('https://user:secret@example.com', false));
    assert.equal(relayOrigin('http://127.0.0.1:8787', true), 'http://127.0.0.1:8787');
});
