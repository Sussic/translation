import {createHash, timingSafeEqual} from 'node:crypto';
import {DatabaseSync} from 'node:sqlite';

export class RegistryError extends Error {
    constructor(readonly code: 'limit' | 'conflict' | 'unknown-host') { super(code); }
}

const credentialHash = (value: string): Buffer => createHash('sha256').update(value, 'utf8').digest();
const matches = (value: string, stored: unknown): boolean => stored instanceof Uint8Array
    && stored.length === 32 && timingSafeEqual(credentialHash(value), stored);

/** Contains opaque identifiers and credential hashes only; no caption material is accepted. */
export class Registry {
    private readonly db: DatabaseSync;
    constructor(filename: string, readonly maxViewers = 20) {
        this.db = new DatabaseSync(filename);
        this.db.exec(`PRAGMA foreign_keys=ON; PRAGMA journal_mode=WAL; PRAGMA busy_timeout=5000;
            CREATE TABLE IF NOT EXISTS hosts (
                host_id TEXT PRIMARY KEY, publisher_hash BLOB NOT NULL CHECK(length(publisher_hash)=32)
            );
            CREATE TABLE IF NOT EXISTS viewers (
                host_id TEXT NOT NULL REFERENCES hosts(host_id), viewer_id TEXT NOT NULL,
                credential_hash BLOB NOT NULL CHECK(length(credential_hash)=32), revoked INTEGER NOT NULL DEFAULT 0,
                PRIMARY KEY(host_id, viewer_id)
            );`);
    }
    provision(hostId: string, publisherToken: string): void {
        this.db.prepare('INSERT INTO hosts(host_id,publisher_hash) VALUES (?,?)').run(hostId, credentialHash(publisherToken));
    }
    authenticatePublisher(hostId: string, token: string): boolean {
        const row = this.db.prepare('SELECT publisher_hash FROM hosts WHERE host_id=?').get(hostId);
        return matches(token, row?.publisher_hash);
    }
    authenticateViewer(hostId: string, viewerId: string, token: string): boolean {
        const row = this.db.prepare('SELECT credential_hash,revoked FROM viewers WHERE host_id=? AND viewer_id=?').get(hostId, viewerId);
        return row?.revoked === 0 && matches(token, row.credential_hash);
    }
    registerViewer(hostId: string, viewerId: string, token: string): 'created' | 'existing' {
        this.db.exec('BEGIN IMMEDIATE');
        try {
            if (!this.db.prepare('SELECT 1 FROM hosts WHERE host_id=?').get(hostId)) throw new RegistryError('unknown-host');
            const old = this.db.prepare('SELECT credential_hash,revoked FROM viewers WHERE host_id=? AND viewer_id=?').get(hostId, viewerId);
            if (old) {
                if (old.revoked !== 0 || !matches(token, old.credential_hash)) throw new RegistryError('conflict');
                this.db.exec('COMMIT'); return 'existing';
            }
            const count = this.db.prepare('SELECT COUNT(*) AS count FROM viewers WHERE host_id=? AND revoked=0').get(hostId)?.count;
            if (typeof count !== 'number' || count >= this.maxViewers) throw new RegistryError('limit');
            this.db.prepare('INSERT INTO viewers(host_id,viewer_id,credential_hash) VALUES (?,?,?)').run(hostId, viewerId, credentialHash(token));
            this.db.exec('COMMIT'); return 'created';
        } catch (error) { this.db.exec('ROLLBACK'); throw error; }
    }
    revokeViewer(hostId: string, viewerId: string): void {
        this.db.prepare('UPDATE viewers SET revoked=1 WHERE host_id=? AND viewer_id=?').run(hostId, viewerId);
    }
    close(): void { this.db.close(); }
}
