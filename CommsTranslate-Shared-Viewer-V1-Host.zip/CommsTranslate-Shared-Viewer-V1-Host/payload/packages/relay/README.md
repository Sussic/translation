# CommsTranslate relay V1

This relay forwards encrypted caption frames between one publisher and up to 20 paired viewers per host. It does not run speech/translation models, hold OpenAI credentials, receive caption-encryption secrets, or store caption history. The only persistent records are opaque host/viewer IDs, SHA-256 hashes of separate relay credentials, and revocation flags.

The relay is a new service. These files do not deploy it or choose a hosting provider. A reachable server and TLS hostname must be selected before remote use.

## Local development

Node.js 24 is required because the registry uses built-in `node:sqlite`. From the source repository, after its normal dependency setup:

```sh
npm run build --workspace @comms/sharing
npm run build --workspace @comms/relay
npm run test --workspace @comms/relay
node packages/relay/dist/cli.js serve --db ./relay-development.sqlite --mode loopback-development --bind 127.0.0.1 --port 8787
```

Development mode refuses a non-loopback bind. Production host/viewer imports require HTTPS; development tests can explicitly enable insecure loopback origins. There is no public signup or remote host-provisioning endpoint.

In another terminal, create a **private host configuration**, not a viewer pairing:

```sh
node packages/relay/dist/cli.js provision --db ./relay-development.sqlite --relay-url http://127.0.0.1:8787 --dev-loopback --host-name "Local test" --out ./local-host.commshost
```

The CLI generates a random 16-byte host ID and an independent 32-byte publisher token. It writes the publisher token only into the explicitly requested private `.commshost` file; the database receives its hash. The output file is created exclusively, never overwritten, with mode 0600 where supported. The CLI does not print its contents. Import this file only into the host companion. The host creates separate receiver-only `.commsviewer` files for friends.

## Deployment example

The supplied Compose example runs one relay instance behind Caddy. Caddy is the only service with published ports; the Node HTTP port is confined to an internal Docker network. The database volume must persist across restarts. Do not run multiple relay replicas against it: connected-session state intentionally belongs to one process.

The Docker image/build and Internet TLS setup still require validation on the selected server. The repository's automated relay tests use real loopback sockets; they do not establish cross-network latency or production capacity.

After installing Docker/Compose on that server and pointing the chosen hostname to it, run from `packages/relay/deploy`:

```sh
export RELAY_DOMAIN='captions.example.com'
docker compose up -d --build
docker compose exec relay node packages/relay/dist/cli.js provision --db /data/registry.sqlite --relay-url "https://${RELAY_DOMAIN}" --host-name "Fleet captions" --out /data/host.commshost
docker compose cp relay:/data/host.commshost ./host.commshost
chmod 600 ./host.commshost
```

Transfer `host.commshost` privately to the host PC and import it. Delete surplus transfer copies after successful import. **Never send this publisher configuration to viewers or put it on a public web server.** Back up the database volume and host's protected configuration separately. Without the registry, existing viewer tokens will no longer authenticate.

Keep port 8787 unpublished. Production mode requires an explicit HTTPS `RELAY_PUBLIC_URL`. No access-log directive is enabled in the Caddy example, and the relay does not log requests, headers, message bodies, or full URLs. Avoid enabling proxy debug/header logging. Pin updates deliberately and retest before replacing the example's Node/Caddy images.

## HTTP and WebSocket contract

All credentials use an `Authorization: Bearer …` request header. Query-string credentials, additional path components and browser-origin WebSocket requests are rejected. No encryption secret is accepted by the registration schema.

| Operation | Route / result |
| --- | --- |
| Register viewer | Publisher-authenticated `POST /v1/hosts/{hostId}/viewers` with exactly `{viewerId, viewerToken}`. Returns `{v:1, viewerId}`. Repeating the same active pair is idempotent. |
| Revoke viewer | Publisher-authenticated `DELETE /v1/hosts/{hostId}/viewers/{viewerId}`. Returns 204. Routing is removed before closing the socket. |
| Publisher connection | `WSS /v1/hosts/{hostId}/publisher`, publisher credential only. |
| Viewer connection | `WSS /v1/hosts/{hostId}/viewers/{viewerId}`, that viewer's credential only. |
| Health | `GET /health` returns service health without counts or credential details. |

The versioned wire format and cryptography live in `@comms/sharing`. IDs are canonical 16-byte base64url values; credentials and challenges are independent 32-byte values. The relay never decrypts sealed messages. Viewer messages are limited to validated `hello` and `probe` messages; publisher messages are limited to validated `sealed` frames. No local companion RPC or account/settings operation can be forwarded.

A new viewer socket receives a fresh connection ID. Only its current socket can send messages. Replacing a viewer emits `replaced` and closes the old socket with **4409**; that viewer must stop automatic retries. Revocation closes with **4403**. Authentication failures reject the HTTP upgrade with **401**. Protocol violations use **4400**, slow receivers **4413**, and the WebSocket library rejects oversized frames with **1009**.

Publisher reconnection or replacement invalidates every existing hello. Each viewer receives `publisher-ready` and must supply a fresh challenge before any new sealed frame can reach it. Host disappearance sends `host-offline`; no caption snapshot is retained for later delivery. Old socket IDs and old hello challenges cannot route new frames.

## Bounds and failure behaviour

- At most 20 active registry pairings per host and one active connection per identity.
- Maximum 8 KiB encoded frame, 1 KiB viewer-control message and 32 KiB pending transport output. Compression is disabled. A slow receiver is disconnected before exceeding the output bound; it cannot delay another viewer.
- At most one outstanding liveness probe per viewer, expiring after nine seconds. Only a publisher reply naming that exact `replyTo` releases it. Probes normally run about every three seconds; resynchronization still obeys the protocol's minimum interval.
- Hello attempts are limited to one per second. Publisher throughput, HTTP/upgrade attempts, native ping/pong traffic, headers, request-body sizes and request duration are bounded.
- WebSocket ping/pong keeps idle sockets tidy. It does **not** renew a viewer's authenticated caption lease; only the cryptographic protocol can do that.
- Credentials and pairing records persist. Captions, outstanding probes and socket state do not survive a relay restart. Viewers reconnect blank and obtain fresh authenticated state from the host.

The host stops encrypting for a removed viewer immediately, independently of relay acknowledgment. Relay revocation prevents future routing/authentication; it cannot erase text already seen or ciphertext already sent.

## Verification

`npm run test --workspace @comms/relay` exercises persistent hash-only credentials, revocation, the 20-pairing limit, exclusive private provisioning, real WebSocket role separation and encrypted delivery, fresh publisher reconnects, duplicate-viewer replacement, forbidden RPC/oversized frames, liveness routing, and the pending-output bound.

These tests do not replace a Windows host plus two-viewer end-to-end test, production TLS validation, slow-network testing or resource measurements on the chosen server.
