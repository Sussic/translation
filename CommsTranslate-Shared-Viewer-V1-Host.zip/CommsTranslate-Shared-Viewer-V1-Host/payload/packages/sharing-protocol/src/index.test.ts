import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {createCipheriv} from 'node:crypto';
import {test} from 'node:test';
import {HostCipher,ViewerCipher,SharingProtocolError,LIMITS,MAX_SEQUENCE,decodeBase64Url,deriveConnectionKey,keyInfo,frameAssociatedData,sequenceNonce,encodeFrame,parseJson,parsePairingFile,parseHostConfiguration,validateRelayUrl,viewerWebSocketUrl,publisherWebSocketUrl,parseViewerMessage,parseRelayMessage,parseSealedFrame,validateViewState,validatePayload,validateProvisionViewer,newId,newSecret,type Payload,type ViewPayload,type SealedFrame} from './index.js';

const vectors=JSON.parse(readFileSync(new URL('../fixtures/v1-vectors.json',import.meta.url),'utf8'));
const session=vectors.sessions[0],route=session.route,secret=session.secret,salt=session.salt;
const initial=session.frames[0].payload as ViewPayload;
const safeReject=(run:()=>unknown,code?:string)=>assert.throws(run,(error:unknown)=>error instanceof SharingProtocolError&&(!code||error.code===code));

test('Frozen Node/.NET vectors preserve exact HKDF info, AES key, AAD, nonce and ciphertext',()=>{
 assert.equal(keyInfo(route).length,86);assert.equal(keyInfo(route).toString('hex'),session.infoHex);
 assert.equal(deriveConnectionKey(secret,route,salt).toString('hex'),session.keyHex);
 const sender=new HostCipher(secret,route,salt),receiver=new ViewerCipher(secret,route);
 for(const expected of session.frames){
  const frame=sender.seal(expected.payload);
  assert.deepEqual(frame,expected.frame);assert.equal(frameAssociatedData(frame).length,159);
  assert.equal(frameAssociatedData(frame).toString('hex'),expected.aadHex);
  assert.equal(sequenceNonce(frame.seq).toString('hex'),expected.nonceHex);
  assert.equal(Buffer.from(encodeFrame(expected.payload)).toString('hex'),expected.plaintextUtf8Hex);
  assert.deepEqual(receiver.open(encodeFrame(frame)),expected.payload);
 }
 assert.equal(sender.lastSequence,4n);assert.equal(receiver.lastSequence,4n);
});

test('Unsigned connection counters retain all 64 bits and are not reset by broadcast changes',()=>{
 for(const vector of vectors.nonceVectors)assert.equal(sequenceNonce(vector.seq).toString('hex'),vector.nonceHex);
 for(const bad of ['0','01','-1','1.0','1e3','18446744073709551616',' 1'])safeReject(()=>sequenceNonce(bad),'INVALID_SEQUENCE');
 const sender=new HostCipher(secret,route,salt);
 assert.equal(sender.seal(initial).seq,'1');assert.equal(sender.seal(session.frames[2].payload).seq,'2');assert.equal(sender.seal(session.frames[3].payload).seq,'3');
 (sender as unknown as {sequence:bigint}).sequence=MAX_SEQUENCE;
 safeReject(()=>sender.seal(initial),'SEQUENCE_EXHAUSTED');
});

test('A replay, lower sequence or old connection cannot replace current plaintext',()=>{
 const sender=new HostCipher(secret,route,salt),receiver=new ViewerCipher(secret,route);
 const first=sender.seal(initial),second=sender.seal(session.frames[1].payload);
 receiver.open(first);receiver.open(second);
 safeReject(()=>receiver.open(first),'REPLAYED_SEQUENCE');safeReject(()=>receiver.open(second),'REPLAYED_SEQUENCE');
 for(const key of ['hostId','viewerId','connectionId','challenge'] as const){
  const other={...route,[key]:key==='challenge'?newSecret():newId()};
  safeReject(()=>new ViewerCipher(secret,other).open(first),'WRONG_CONNECTION');
 }
 safeReject(()=>new ViewerCipher(newSecret(),route).open(first),'AUTHENTICATION_FAILED');
});

test('All mutable AAD fields, ciphertext and tag are authenticated without consuming a valid sequence',()=>{
 const sender=new HostCipher(secret,route,salt),first=sender.seal(initial);
 const receiver=new ViewerCipher(secret,route);
 const changed=(value:string)=>{const b=Buffer.from(value,'base64url');b[0]=b[0]!^1;return b.toString('base64url');};
 const mutations:SealedFrame[]=[{...first,salt:changed(first.salt)},{...first,seq:'2'},{...first,replyTo:newSecret()},{...first,ciphertext:changed(first.ciphertext)},{...first,tag:changed(first.tag)}];
 for(const frame of mutations){safeReject(()=>receiver.open(frame),'AUTHENTICATION_FAILED');assert.equal(receiver.lastSequence,0n);}
 assert.deepEqual(receiver.open(first),initial);
 const otherSalt=new HostCipher(secret,route,newSecret());otherSalt.seal(initial);
 safeReject(()=>receiver.open(otherSalt.seal(session.frames[1].payload)),'WRONG_CONNECTION');
});

test('Fresh random salt produces a different connection key even for the same hello',()=>{
 const first=new HostCipher(secret,route),second=new HostCipher(secret,route);
 assert.notEqual(first.salt,second.salt);
 assert.notEqual(deriveConnectionKey(secret,route,first.salt).toString('hex'),deriveConnectionKey(secret,route,second.salt).toString('hex'));
 assert.notDeepEqual(first.seal(initial),second.seal(initial));
});

test('First accepted message must be a complete unsolicited view',()=>{
 const sender=new HostCipher(secret,route,salt),receiver=new ViewerCipher(secret,route);
 safeReject(()=>receiver.open(sender.seal(session.frames[1].payload)),'INITIAL_VIEW_REQUIRED');
 assert.equal(receiver.lastSequence,0n);
 safeReject(()=>receiver.open(sender.seal({...initial,probe:newSecret()})),'INITIAL_VIEW_REQUIRED');
 receiver.open(sender.seal(initial));assert.equal(receiver.lastSequence,3n);
});

test('Authenticated but malformed plaintext or a mismatched probe cannot commit receiver state',()=>{
 const key=deriveConnectionKey(secret,route,salt);
 function rawFrame(payload:unknown,replyTo:string|null):SealedFrame {
  const frame:SealedFrame={v:1,type:'sealed',...route,salt,seq:'1',replyTo,ciphertext:'',tag:''};
  const cipher=createCipheriv('aes-256-gcm',key,sequenceNonce('1'));cipher.setAAD(frameAssociatedData(frame));
  frame.ciphertext=Buffer.concat([cipher.update(encodeFrame(payload),'utf8'),cipher.final()]).toString('base64url');frame.tag=cipher.getAuthTag().toString('base64url');return frame;
 }
 const receiver=new ViewerCipher(secret,route);
 safeReject(()=>receiver.open(rawFrame({...initial,sourceText:'must never be a payload field'},null)),'INVALID_FIELDS');
 safeReject(()=>receiver.open(rawFrame({...initial,probe:newSecret()},null)),'WRONG_PROBE');
 assert.equal(receiver.lastSequence,0n);
 assert.deepEqual(receiver.open(new HostCipher(secret,route,salt).seal(initial)),initial);
});

test('Setup files separate receiver secrets from publisher configuration and reject extra fields',()=>{
 assert.deepEqual(parsePairingFile(encodeFrame(vectors.pairing)),vectors.pairing);
 assert.deepEqual(parseHostConfiguration(encodeFrame(vectors.hostConfiguration)),vectors.hostConfiguration);
 safeReject(()=>parsePairingFile(encodeFrame({...vectors.pairing,publisherToken:newSecret()})),'INVALID_FIELDS');
 safeReject(()=>parseHostConfiguration(encodeFrame({...vectors.hostConfiguration,captionSecret:newSecret()})),'INVALID_FIELDS');
 safeReject(()=>parsePairingFile(encodeFrame({...vectors.pairing,hostName:'x'.repeat(81)})),'INVALID_NAME');
 safeReject(()=>parsePairingFile(encodeFrame({...vectors.pairing,hostName:'Header\nforged'})),'INVALID_NAME');
 assert.deepEqual(validateProvisionViewer({viewerId:route.viewerId,viewerToken:vectors.pairing.viewerToken}),{viewerId:route.viewerId,viewerToken:vectors.pairing.viewerToken});
 safeReject(()=>validateProvisionViewer({viewerId:route.viewerId,viewerToken:vectors.pairing.viewerToken,captionSecret:secret}));
});

test('URLs remain secure origins and test-only HTTP is limited to exact loopback hosts',()=>{
 assert.equal(validateRelayUrl('https://captions.example.test/'),'https://captions.example.test');
 assert.equal(viewerWebSocketUrl(vectors.pairing.relayUrl,route.hostId,route.viewerId),`wss://captions.example.test/v1/hosts/${route.hostId}/viewers/${route.viewerId}`);
 assert.equal(publisherWebSocketUrl(vectors.pairing.relayUrl,route.hostId),`wss://captions.example.test/v1/hosts/${route.hostId}/publisher`);
 for(const url of ['http://captions.example.test','https://name:secret@captions.example.test','https://captions.example.test/path','https://captions.example.test?token=secret','https://captions.example.test/#x','file:///tmp/secret','wss://captions.example.test',' https://captions.example.test'])safeReject(()=>validateRelayUrl(url),'INVALID_RELAY_URL');
 for(const url of ['http://localhost:8080','http://127.0.0.1:8080','http://[::1]:8080']){safeReject(()=>validateRelayUrl(url));assert.ok(validateRelayUrl(url,{allowInsecureLoopback:true}).startsWith('http:'));}
 for(const url of ['http://127.0.0.2','http://localhost.example.test','http://192.168.1.1','http://example.test'])safeReject(()=>validateRelayUrl(url,{allowInsecureLoopback:true}));
});

test('Viewer control surface allows hello/probe only and rejects account or settings methods',()=>{
 const hello={v:1,type:'hello',...route};assert.deepEqual(parseViewerMessage(encodeFrame(hello)),hello);
 const probe={...hello,type:'probe',requestView:true};assert.deepEqual(parseViewerMessage(encodeFrame(probe)),probe);
 for(const type of ['translate','settings.update','voice.start','auth.signIn','publish','sealed'])safeReject(()=>parseViewerMessage(encodeFrame({...hello,type})),'VIEWER_METHOD_FORBIDDEN');
 safeReject(()=>parseViewerMessage(encodeFrame({...hello,context:[]})),'INVALID_FIELDS');
 safeReject(()=>parseViewerMessage(encodeFrame({...probe,requestView:'yes'})),'INVALID_BOOLEAN');
 assert.deepEqual(parseRelayMessage('{"v":1,"type":"publisher-ready"}'),{v:1,type:'publisher-ready'});
 safeReject(()=>parseRelayMessage('{"v":1,"type":"publisher-ready","captionSecret":"never"}'));
});

test('Malformed UTF-8, duplicate or escaped duplicate fields, and excessive nesting are rejected',()=>{
 safeReject(()=>parseJson(Uint8Array.from([0xff,0x7b,0x7d])),'INVALID_UTF8');
 safeReject(()=>parseJson('{"v":1,"v":2}'),'DUPLICATE_FIELD');
 safeReject(()=>parseJson('{"v":1,"\\u0076":2}'),'DUPLICATE_FIELD');
 safeReject(()=>parseJson('{"nested":{"x":1,"x":2}}'),'DUPLICATE_FIELD');
 safeReject(()=>parseJson('['.repeat(18)+'0'+']'.repeat(18)),'JSON_TOO_DEEP');
 safeReject(()=>parseJson('{invalid}'),'INVALID_JSON');
 assert.deepEqual(parseJson('{"quote":"a\\\"b","values":[true,null,2]}'),{quote:'a"b',values:[true,null,2]});
});

test('Canonical base64url rejects padding, alternate unused bits and wrong key sizes',()=>{
 assert.equal(decodeBase64Url(route.hostId,16).length,16);
 for(const value of [route.hostId+'=',route.hostId.slice(0,-1)+'B','+/','a',newSecret()])safeReject(()=>decodeBase64Url(value,16),'INVALID_BASE64URL');
});

test('Payload schema caps rows, text bytes and lifetimes while preserving multilingual plain text',()=>{
 const {kind,probe,...state}=initial;assert.deepEqual(validateViewState(state),state);
 safeReject(()=>validatePayload({...initial,rows:[...initial.rows,...initial.rows]}),'DUPLICATE_CAPTION');
 safeReject(()=>validatePayload({...initial,rows:Array.from({length:3},()=>initial.rows[0])}),'INVALID_ROWS');
 for(const remainingMs of [0,-1,15001,1.5])safeReject(()=>validatePayload({...initial,rows:[{...initial.rows[0],remainingMs}]}),'INVALID_NUMBER');
 for(const text of ['x'.repeat(2049),'漢'.repeat(683),'\ud800','\u0000hidden','   '])safeReject(()=>validatePayload({...initial,rows:[{...initial.rows[0],text}]}),'INVALID_TEXT');
 safeReject(()=>validatePayload({...initial,status:'off'}),'INVALID_BROADCAST');
 safeReject(()=>validatePayload({...initial,status:'paused'}),'INVALID_ROWS');
 safeReject(()=>validatePayload({...initial,viewRevision:Number.MAX_SAFE_INTEGER+1}),'INVALID_NUMBER');
 safeReject(()=>validatePayload({...initial,sourceText:'private'}),'INVALID_FIELDS');
});

test('Output language preserves existing regional and script codes without accepting arbitrary labels',()=>{
 for(const outputLanguage of ['en','pol','en-US','zh-CN','zh-Hant','es-419','en-abcdefgh']){
  const payload={...initial,outputLanguage};
  const sender=new HostCipher(secret,route,salt),receiver=new ViewerCipher(secret,route);
  assert.deepEqual(receiver.open(sender.seal(payload)),payload);
 }
 for(const outputLanguage of ['EN','e','english','en-','en-U','en-US-extra','en_Us','en-abcdefghi','en-US\n',' en','en-ÅÅ'])
  safeReject(()=>validatePayload({...initial,outputLanguage}),'INVALID_LANGUAGE');
});

test('Encoded-frame cap includes escaping expansion and ciphertext envelope overhead',()=>{
 const sender=new HostCipher(secret,route,salt);
 const inflated={...initial,rows:[{...initial.rows[0]!,text:'x'+'\n'.repeat(2047)},{...initial.rows[0]!,id:newId(),text:'y'+'\n'.repeat(2047)}]};
 safeReject(()=>sender.seal(inflated),'FRAME_TOO_LARGE');assert.equal(sender.lastSequence,1n);
 assert.equal(sender.seal(initial).seq,'2');
 safeReject(()=>parseSealedFrame(' '.repeat(LIMITS.frameBytes+1)),'FRAME_TOO_LARGE');
 safeReject(()=>parseViewerMessage(' '.repeat(LIMITS.controlBytes+1)),'FRAME_TOO_LARGE');
});

test('Schema and crypto errors contain no rejected credential or caption material',()=>{
 const privateValue='private-caller-material';
 for(const run of [()=>parsePairingFile(encodeFrame({...vectors.pairing,viewerToken:privateValue})),()=>parseViewerMessage(encodeFrame({v:1,type:privateValue})),()=>validatePayload({...initial,rows:[{...initial.rows[0],text:'\u0000'+privateValue}]})]){
  try{run();assert.fail('must reject');}catch(error){assert.ok(error instanceof SharingProtocolError);assert.ok(!String(error).includes(privateValue));}
 }
});
