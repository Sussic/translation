import {createCipheriv,createDecipheriv,hkdfSync,randomBytes} from 'node:crypto';

export const PROTOCOL_VERSION=1 as const;
export const LIMITS=Object.freeze({frameBytes:8192,controlBytes:1024,pairingBytes:4096,pendingBytes:32768,viewers:20,rows:2,captionBytes:2048,captionLifetimeMs:15000,handshakeIntervalMs:1000,minimumProbeIntervalMs:1000,probeIntervalMs:3000,leaseMs:9000,idleProbeIntervalMs:30000,maxRetiredBroadcasts:256});
export const MAX_SEQUENCE=(1n<<64n)-1n;
export const CLOSE_CODES=Object.freeze({invalid:4400,unauthorized:4401,revoked:4403,replaced:4409,slow:4413});
export class SharingProtocolError extends Error {constructor(public readonly code:string){super(`Sharing protocol rejected input (${code}).`);this.name='SharingProtocolError';}}
export {SharingProtocolError as ProtocolError};
function reject(code:string):never {throw new SharingProtocolError(code);}
function object(value:unknown):Record<string,unknown>{if(!value||typeof value!=='object'||Array.isArray(value))reject('INVALID_OBJECT');return value as Record<string,unknown>;}
function keys(value:Record<string,unknown>,required:readonly string[]){const got=Object.keys(value);if(got.length!==required.length||required.some(key=>!Object.hasOwn(value,key)))reject('INVALID_FIELDS');}
function wellFormed(text:string){for(let i=0;i<text.length;i++){const c=text.charCodeAt(i);if(c>=0xd800&&c<=0xdbff){const d=text.charCodeAt(++i);if(!(d>=0xdc00&&d<=0xdfff))return false;}else if(c>=0xdc00&&c<=0xdfff)return false;}return true;}
function plainText(value:unknown,maxBytes:number,allowWhitespace=false):string {if(typeof value!=='string'||!wellFormed(value)||Buffer.byteLength(value,'utf8')>maxBytes||(!allowWhitespace&&!value.trim())||/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/u.test(value))reject('INVALID_TEXT');return value;}
function integer(value:unknown,min=0,max=Number.MAX_SAFE_INTEGER):number{if(typeof value!=='number'||!Number.isSafeInteger(value)||value<min||value>max)reject('INVALID_NUMBER');return value;}
function boolean(value:unknown):boolean{if(typeof value!=='boolean')reject('INVALID_BOOLEAN');return value;}
export function decodeBase64Url(value:unknown,length?:number):Buffer {if(typeof value!=='string'||!value.length||value.length>LIMITS.frameBytes||(length!==undefined&&value.length!==Math.ceil(length*8/6))||!/^[-_A-Za-z0-9]+$/.test(value))reject('INVALID_BASE64URL');const bytes=Buffer.from(value,'base64url');if(bytes.toString('base64url')!==value||(length!==undefined&&bytes.length!==length))reject('INVALID_BASE64URL');return bytes;}
function encoded(value:unknown,length:number):string{decodeBase64Url(value,length);return value as string;}
export function newId():string{return randomBytes(16).toString('base64url');}
export function newSecret():string{return randomBytes(32).toString('base64url');}
export function validateId(value:unknown):string{return encoded(value,16);}
export function validateSecret(value:unknown):string{return encoded(value,32);}

/** Reject duplicate object members before parsing, so implementations cannot disagree on routing. */
function rejectDuplicateMembers(text:string){
 let at=0;const space=()=>{while(/[\x20\t\r\n]/.test(text[at]??'!'))at++;};
 const string=():string=>{const start=at++;while(at<text.length){const c=text[at++]!;if(c==='"')return JSON.parse(text.slice(start,at)) as string;if(c==='\\')at++;}reject('INVALID_JSON');};
 const value=(depth:number):void=>{if(depth>16)reject('JSON_TOO_DEEP');space();const c=text[at];if(c==='{'){at++;space();const names=new Set<string>();if(text[at]==='}'){at++;return;}while(at<text.length){space();if(text[at]!=='"')reject('INVALID_JSON');const name=string();if(names.has(name))reject('DUPLICATE_FIELD');names.add(name);space();if(text[at++]!==':')reject('INVALID_JSON');value(depth+1);space();const end=text[at++];if(end==='}')return;if(end!==',')reject('INVALID_JSON');}reject('INVALID_JSON');}else if(c==='['){at++;space();if(text[at]===']'){at++;return;}while(at<text.length){value(depth+1);space();const end=text[at++];if(end===']')return;if(end!==',')reject('INVALID_JSON');}reject('INVALID_JSON');}else if(c==='"'){string();}else{const start=at;while(at<text.length&&!/[\x20\t\r\n,}\]]/.test(text[at]!))at++;if(at===start)reject('INVALID_JSON');}};
 try{value(0);space();if(at!==text.length)reject('INVALID_JSON');}catch(error){if(error instanceof SharingProtocolError)throw error;reject('INVALID_JSON');}
}
export function parseJson(input:string|Uint8Array,maxBytes:number=LIMITS.frameBytes):unknown {
 let text:string;
 if(typeof input==='string'){if(!wellFormed(input)||Buffer.byteLength(input,'utf8')>maxBytes)reject('FRAME_TOO_LARGE');text=input;}
 else {if(input.byteLength>maxBytes)reject('FRAME_TOO_LARGE');try{text=new TextDecoder('utf-8',{fatal:true}).decode(input);}catch{reject('INVALID_UTF8');}}
 rejectDuplicateMembers(text);
 try{return JSON.parse(text);}catch{reject('INVALID_JSON');}
}
export function encodeFrame(value:unknown,maxBytes:number=LIMITS.frameBytes):string {let text:string;try{text=JSON.stringify(value);}catch{reject('INVALID_JSON');}if(typeof text!=='string'||!wellFormed(text)||Buffer.byteLength(text,'utf8')>maxBytes)reject('FRAME_TOO_LARGE');return text;}

export interface UrlOptions {allowInsecureLoopback?:boolean}
export function validateRelayUrl(value:unknown,options:UrlOptions={}):string {
 if(typeof value!=='string'||value.length>2048||value.trim()!==value)reject('INVALID_RELAY_URL');let url:URL;try{url=new URL(value);}catch{reject('INVALID_RELAY_URL');}
 const loopback=url.hostname==='localhost'||url.hostname==='127.0.0.1'||url.hostname==='[::1]';
 if((url.protocol!=='https:'&&!(options.allowInsecureLoopback===true&&loopback&&url.protocol==='http:'))||url.username||url.password||url.search||url.hash||(url.pathname!==''&&url.pathname!=='/')||!url.hostname)reject('INVALID_RELAY_URL');
 return url.origin;
}
export function viewerWebSocketUrl(relayUrl:string,hostId:string,viewerId:string,options:UrlOptions={}):string{return validateRelayUrl(relayUrl,options).replace(/^http/,'ws')+`/v1/hosts/${validateId(hostId)}/viewers/${validateId(viewerId)}`;}
export function publisherWebSocketUrl(relayUrl:string,hostId:string,options:UrlOptions={}):string{return validateRelayUrl(relayUrl,options).replace(/^http/,'ws')+`/v1/hosts/${validateId(hostId)}/publisher`;}
export interface PairingFile {format:'CommsTranslateViewer';version:1;relayUrl:string;hostId:string;viewerId:string;hostName:string;viewerName:string;viewerToken:string;captionSecret:string}
export function validatePairingFile(value:unknown,options:UrlOptions={}):PairingFile {const o=object(value);keys(o,['format','version','relayUrl','hostId','viewerId','hostName','viewerName','viewerToken','captionSecret']);if(o.format!=='CommsTranslateViewer'||o.version!==1)reject('UNSUPPORTED_PAIRING');const hostName=plainText(o.hostName,320),viewerName=plainText(o.viewerName,320);if([...hostName].length>80||[...viewerName].length>80||/[\r\n\t]/.test(hostName+viewerName))reject('INVALID_NAME');return {format:'CommsTranslateViewer',version:1,relayUrl:validateRelayUrl(o.relayUrl,options),hostId:validateId(o.hostId),viewerId:validateId(o.viewerId),hostName,viewerName,viewerToken:validateSecret(o.viewerToken),captionSecret:validateSecret(o.captionSecret)};}
export function parsePairingFile(input:string|Uint8Array,options:UrlOptions={}):PairingFile{return validatePairingFile(parseJson(input,LIMITS.pairingBytes),options);}
export interface HostConfiguration {format:'CommsTranslateHost';version:1;relayUrl:string;hostId:string;hostName:string;publisherToken:string}
export function validateHostConfiguration(value:unknown,options:UrlOptions={}):HostConfiguration {const o=object(value);keys(o,['format','version','relayUrl','hostId','hostName','publisherToken']);if(o.format!=='CommsTranslateHost'||o.version!==1)reject('UNSUPPORTED_PAIRING');const hostName=plainText(o.hostName,320);if([...hostName].length>80||/[\r\n\t]/.test(hostName))reject('INVALID_NAME');return {format:'CommsTranslateHost',version:1,relayUrl:validateRelayUrl(o.relayUrl,options),hostId:validateId(o.hostId),hostName,publisherToken:validateSecret(o.publisherToken)};}
export function parseHostConfiguration(input:string|Uint8Array,options:UrlOptions={}):HostConfiguration{return validateHostConfiguration(parseJson(input,LIMITS.pairingBytes),options);}
export interface ProvisionViewer {viewerId:string;viewerToken:string}
export function validateProvisionViewer(value:unknown):ProvisionViewer {const o=object(value);keys(o,['viewerId','viewerToken']);return {viewerId:validateId(o.viewerId),viewerToken:validateSecret(o.viewerToken)};}

export interface Routing {hostId:string;viewerId:string;connectionId:string;challenge:string}
function routing(o:Record<string,unknown>):Routing{return {hostId:validateId(o.hostId),viewerId:validateId(o.viewerId),connectionId:validateId(o.connectionId),challenge:validateSecret(o.challenge)};}
export interface HelloMessage extends Routing {v:1;type:'hello'}
export interface ProbeMessage extends Routing {v:1;type:'probe';requestView:boolean}
export type ViewerMessage=HelloMessage|ProbeMessage;
export function validateViewerMessage(value:unknown):ViewerMessage {const o=object(value);if(o.v!==1)reject('UNSUPPORTED_VERSION');if(o.type==='hello'){keys(o,['v','type','hostId','viewerId','connectionId','challenge']);return {v:1,type:'hello',...routing(o)};}if(o.type==='probe'){keys(o,['v','type','hostId','viewerId','connectionId','challenge','requestView']);return {v:1,type:'probe',...routing(o),requestView:boolean(o.requestView)};}reject('VIEWER_METHOD_FORBIDDEN');}
export function parseViewerMessage(input:string|Uint8Array):ViewerMessage{return validateViewerMessage(parseJson(input,LIMITS.controlBytes));}
export type RelayMessage={v:1;type:'connected';connectionId:string}|{v:1;type:'viewer-connected'|'viewer-disconnected';viewerId:string;connectionId:string}|{v:1;type:'publisher-ready'|'host-offline'|'replaced'};
export function validateRelayMessage(value:unknown):RelayMessage {const o=object(value);if(o.v!==1)reject('UNSUPPORTED_VERSION');if(o.type==='connected'){keys(o,['v','type','connectionId']);return {v:1,type:o.type,connectionId:validateId(o.connectionId)};}if(o.type==='viewer-connected'||o.type==='viewer-disconnected'){keys(o,['v','type','viewerId','connectionId']);return {v:1,type:o.type,viewerId:validateId(o.viewerId),connectionId:validateId(o.connectionId)};}if(o.type==='publisher-ready'||o.type==='host-offline'||o.type==='replaced'){keys(o,['v','type']);return {v:1,type:o.type};}reject('INVALID_RELAY_MESSAGE');}
export function parseRelayMessage(input:string|Uint8Array):RelayMessage{return validateRelayMessage(parseJson(input,LIMITS.controlBytes));}

export type SharingStatus='off'|'sharing'|'paused'|'unavailable';
export interface CaptionRow {id:string;revision:number;text:string;remainingMs:number;provisional:boolean}
export interface StateIdentity {status:SharingStatus;broadcastId:string|null;viewRevision:number}
export interface ViewState extends StateIdentity {outputLanguage:string;rows:CaptionRow[]}
export interface ViewPayload extends ViewState {kind:'view';probe:string|null}
export interface StatusPayload extends StateIdentity {kind:'status';probe:string}
export type Payload=ViewPayload|StatusPayload;
function identity(o:Record<string,unknown>):StateIdentity {if(!['off','sharing','paused','unavailable'].includes(String(o.status)))reject('INVALID_STATUS');const status=o.status as SharingStatus;const broadcastId=o.broadcastId===null?null:validateId(o.broadcastId);if((status==='off')!==(broadcastId===null))reject('INVALID_BROADCAST');return {status,broadcastId,viewRevision:integer(o.viewRevision)};}
function rows(value:unknown,status:SharingStatus):CaptionRow[] {if(!Array.isArray(value)||value.length>LIMITS.rows||(status!=='sharing'&&value.length))reject('INVALID_ROWS');const ids=new Set<string>();return value.map(value=>{const o=object(value);keys(o,['id','revision','text','remainingMs','provisional']);const id=validateId(o.id);if(ids.has(id))reject('DUPLICATE_CAPTION');ids.add(id);return {id,revision:integer(o.revision),text:plainText(o.text,LIMITS.captionBytes),remainingMs:integer(o.remainingMs,1,LIMITS.captionLifetimeMs),provisional:boolean(o.provisional)};});}
export function validateViewState(value:unknown):ViewState {const o=object(value);keys(o,['status','broadcastId','viewRevision','outputLanguage','rows']);const state=identity(o);if(typeof o.outputLanguage!=='string'||!(/^[a-z]{2,3}(?:-[A-Za-z0-9]{2,8})?$/).test(o.outputLanguage))reject('INVALID_LANGUAGE');return {...state,outputLanguage:o.outputLanguage,rows:rows(o.rows,state.status)};}
export function validatePayload(value:unknown):Payload {const o=object(value);if(o.kind==='status'){keys(o,['kind','probe','status','broadcastId','viewRevision']);return {kind:'status',probe:validateSecret(o.probe),...identity(o)};}if(o.kind==='view'){keys(o,['kind','probe','status','broadcastId','viewRevision','outputLanguage','rows']);const {kind,probe,...rest}=o;return {kind:'view',probe:probe===null?null:validateSecret(probe),...validateViewState(rest)};}reject('INVALID_PAYLOAD');}
export interface SealedFrame extends Routing {v:1;type:'sealed';salt:string;seq:string;replyTo:string|null;ciphertext:string;tag:string}
export function sequenceNumber(value:unknown):bigint{if(typeof value!=='string'||!(/^[1-9][0-9]{0,19}$/).test(value))reject('INVALID_SEQUENCE');const n=BigInt(value);if(n>MAX_SEQUENCE)reject('INVALID_SEQUENCE');return n;}
export function validateSealedFrame(value:unknown):SealedFrame {const o=object(value);keys(o,['v','type','hostId','viewerId','connectionId','challenge','salt','seq','replyTo','ciphertext','tag']);if(o.v!==1||o.type!=='sealed')reject('UNSUPPORTED_VERSION');sequenceNumber(o.seq);decodeBase64Url(o.ciphertext);return {v:1,type:'sealed',...routing(o),salt:validateSecret(o.salt),seq:o.seq as string,replyTo:o.replyTo===null?null:validateSecret(o.replyTo),ciphertext:o.ciphertext as string,tag:encoded(o.tag,16)};}
export function parseSealedFrame(input:string|Uint8Array):SealedFrame{return validateSealedFrame(parseJson(input));}
export function keyInfo(route:Routing):Buffer {const r=routing(object(route));return Buffer.concat([Buffer.from([0x43,0x54,0x53,0x56,1,1]),decodeBase64Url(r.hostId,16),decodeBase64Url(r.viewerId,16),decodeBase64Url(r.connectionId,16),decodeBase64Url(r.challenge,32)]);}
export function deriveConnectionKey(secret:string,route:Routing,salt:string):Buffer{return Buffer.from(hkdfSync('sha256',decodeBase64Url(secret,32),decodeBase64Url(salt,32),keyInfo(route),32));}
export function sequenceNonce(sequence:string|bigint):Buffer {const n=sequenceNumber(String(sequence));const nonce=Buffer.alloc(12);nonce.writeBigUInt64BE(n,4);return nonce;}
export function frameAssociatedData(frame:Pick<SealedFrame,keyof Routing|'salt'|'seq'|'replyTo'>):Buffer {const seq=sequenceNumber(frame.seq),suffix=Buffer.alloc(41);suffix.writeBigUInt64BE(seq,0);if(frame.replyTo!==null){suffix[8]=1;decodeBase64Url(frame.replyTo,32).copy(suffix,9);}return Buffer.concat([keyInfo(frame),decodeBase64Url(frame.salt,32),suffix]);}
export class HostCipher {
 private sequence=0n;private readonly key:Buffer;readonly salt:string;readonly route:Routing;
 constructor(secret:string,route:Routing,salt=newSecret()){this.route=routing(object(route));this.salt=validateSecret(salt);this.key=deriveConnectionKey(secret,this.route,this.salt);}
 seal(value:Payload):SealedFrame {const payload=validatePayload(value);if(this.sequence===MAX_SEQUENCE)reject('SEQUENCE_EXHAUSTED');const frame:SealedFrame={v:1,type:'sealed',...this.route,salt:this.salt,seq:String(++this.sequence),replyTo:payload.probe,ciphertext:'',tag:''};const cipher=createCipheriv('aes-256-gcm',this.key,sequenceNonce(frame.seq));cipher.setAAD(frameAssociatedData(frame));const ciphertext=Buffer.concat([cipher.update(encodeFrame(payload),'utf8'),cipher.final()]);frame.ciphertext=ciphertext.toString('base64url');frame.tag=cipher.getAuthTag().toString('base64url');encodeFrame(frame);return frame;}
 get lastSequence():bigint{return this.sequence;}
}
export class ViewerCipher {
 private sequence=0n;private salt:string|undefined;private key:Buffer|undefined;readonly route:Routing;
 constructor(private readonly secret:string,route:Routing){validateSecret(secret);this.route=routing(object(route));}
 open(input:SealedFrame|string|Uint8Array):Payload {const frame=typeof input==='string'||input instanceof Uint8Array?parseSealedFrame(input):validateSealedFrame(parseJson(encodeFrame(input)));for(const key of ['hostId','viewerId','connectionId','challenge'] as const)if(frame[key]!==this.route[key])reject('WRONG_CONNECTION');const seq=sequenceNumber(frame.seq);if(seq<=this.sequence)reject('REPLAYED_SEQUENCE');if(this.salt!==undefined&&frame.salt!==this.salt)reject('WRONG_CONNECTION');const key=this.key??deriveConnectionKey(this.secret,this.route,frame.salt);let plaintext:Buffer;try{const cipher=createDecipheriv('aes-256-gcm',key,sequenceNonce(frame.seq));cipher.setAAD(frameAssociatedData(frame));cipher.setAuthTag(decodeBase64Url(frame.tag,16));plaintext=Buffer.concat([cipher.update(decodeBase64Url(frame.ciphertext)),cipher.final()]);}catch{reject('AUTHENTICATION_FAILED');}const payload=validatePayload(parseJson(plaintext));if(payload.probe!==frame.replyTo)reject('WRONG_PROBE');if(this.sequence===0n&&(payload.kind!=='view'||payload.probe!==null))reject('INITIAL_VIEW_REQUIRED');this.key=key;this.salt=frame.salt;this.sequence=seq;return payload;}
 get lastSequence():bigint{return this.sequence;}
}
