@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
set "NODE_OPTIONS="
set "NODE_PATH="
set "ELECTRON_RUN_AS_NODE="
set "COMMS_NODE_EXE="
if exist "%ProgramFiles%\nodejs\node.exe" set "COMMS_NODE_EXE=%ProgramFiles%\nodejs\node.exe"
if not defined COMMS_NODE_EXE for /f "delims=" %%N in ('where.exe node.exe 2^>nul') do if not defined COMMS_NODE_EXE set "COMMS_NODE_EXE=%%N"
if not defined COMMS_NODE_EXE goto no_node
if not exist "%SystemRoot%\System32\wscript.exe" goto debug_fallback
if not exist "%SystemRoot%\System32\cscript.exe" goto debug_fallback
if not exist "%~dp0scripts\start-hidden.js" goto debug_fallback
"%SystemRoot%\System32\cscript.exe" //nologo //E:JScript "%~dp0scripts\start-hidden.js" --check "%COMMS_NODE_EXE%" >nul 2>&1
if errorlevel 1 goto debug_fallback
start "" "%SystemRoot%\System32\wscript.exe" //nologo //E:JScript "%~dp0scripts\start-hidden.js" "%COMMS_NODE_EXE%"
if errorlevel 1 goto debug_fallback
exit /b 0
:debug_fallback
echo Quiet launch is unavailable on this Windows setup or project path.
echo Continuing with the visible diagnostic launcher; no policy settings were changed.
"%COMMS_NODE_EXE%" "%~dp0scripts\start.mjs"
set "COMMS_START_CODE=%ERRORLEVEL%"
if not "%COMMS_START_CODE%"=="0" pause
exit /b %COMMS_START_CODE%
:no_node
echo Existing Node.js x64 version 22.18 or newer is required. No dependency was installed.
pause
exit /b 2
