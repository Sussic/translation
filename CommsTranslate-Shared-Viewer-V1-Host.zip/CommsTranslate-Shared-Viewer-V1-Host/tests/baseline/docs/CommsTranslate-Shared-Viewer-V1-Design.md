# CommsTranslate shared viewer — V1 design

Status: proposed design, not implemented or benchmarked. 8 October 2026.

## Intended experience

Friends pair with your CommsTranslate installation once. Their viewer remembers you and waits quietly in the Windows tray. Whenever you enable **Share captions**, their overlays show the same reading-language captions. There are no recurring invitations or session links.

The viewer is a movable, resizable window with a locked, click-through reading mode. Each friend controls their own position, size, font and background. They cannot start translation, change your settings or use your ChatGPT account.

Initial scope: one host, up to 20 paired Windows 11 x64 viewers, one shared output language, and one overlay per viewer. This is a design limit to validate, not a measured capacity claim.

## Decisions and reasons

| Decision | Reason |
| --- | --- |
| Separate C#/.NET 10 WPF viewer | Native Windows text layout, multilingual fonts and DPI support without distributing the companion's browser engine, Python or models. |
| Self-contained, prebuilt ZIP | Friends extract and run an EXE. They install no SDK, Node, Python, GPU components or separate .NET runtime. |
| Persistent pairing | Meets the requirement to work automatically whenever sharing is enabled. |
| One outbound WSS connection per viewer | Server-pushed captions without polling, router configuration or a VPN requirement. |
| Small hosted relay | Provides an address that remains available while your PC is off and works across different home networks. |
| Per-viewer encrypted delivery | Independent revocation without shared group-key rotation or host-signature infrastructure. The host repeats a small encryption operation, never a translation request. |
| Complete current-view updates | Missing or coalesced messages cannot corrupt a chain of text fragments. Viewers keep only the current display state. |
| Event-driven rendering | Repaint when captions, status or geometry change; no animation or continuous refresh loop. |

WPF is the practical low-overhead choice, not a claim to the absolute smallest executable. A raw Win32 viewer could reduce footprint further but adds custom text, layout and accessibility work. Reconsider it only if measured WPF resource use fails the acceptance targets.

## Host controls

Add one **Share captions** toggle beside the main caption controls. Show a compact status such as `Sharing English · 3 viewers`. Put **Manage viewers** beside it, with names, connection status, add and remove actions.

Sharing starts off. Enabling it applies to the currently running capture session. Pairings persist across restarts; permission to publish a particular conversation does not.

Stopping captions, changing voice channel or capture source, signing out of Discord, or closing the companion ends sharing. A pause clears the shared display and can resume within the same capture session. Changing output language clears the display before publishing captions in the new language. A new channel requires turning sharing on again, but friends do nothing.

A brief relay interruption may reconnect automatically while the same locally authorised capture session remains active. If that session ended while disconnected, reconnect must report sharing off.

Sharing failures never stop the host's local captions. Removing all viewers or leaving them offline must not change the number of transcription or translation calls.

## One-time pairing

Use a private setup file rather than a recurring link:

1. You choose **Add viewer**, name the device and export its `.commsviewer` setup file.
2. Send that file privately to the friend using your normal method.
3. They run the viewer, choose **Connect to a host**, and import it once.
4. The viewer shows the host name and saves the connection. Future launches reconnect automatically.

The file contains the relay address, an opaque host/device identifier, a receiver-only relay credential and a unique caption-encryption secret. It contains no OpenAI credential, companion bridge token or publisher credential. Treat it as a private viewing credential; it is not a public download.

V1 does not pretend this bearer credential is hardware-bound or single-use. Someone given a copy could use that viewer identity until it is revoked. Each friend gets a separate credential, with one active connection per identity. The newest authenticated connection wins; the displaced viewer shows **Connected elsewhere** and stops automatic retries until the user chooses Reconnect. This also lets a legitimate reconnect replace a stale socket. A new PC can be paired as a new device and the old one removed.

Removing a viewer immediately stops host encryption/delivery for that identity, revokes its relay credential and disconnects it. Other viewers do not re-pair. The remote display clears when the stop/disconnect arrives or its liveness lease expires; a broken network cannot provide an instantaneous remote-clear guarantee. Removal prevents new host output for that viewer; it cannot recall previously sent ciphertext or erase text already seen. Re-adding a person generates new identifiers and secrets.

Store saved viewer secrets with Windows CurrentUser data protection. Store host sharing secrets separately from ChatGPT credentials using the companion's existing OS-backed secret storage. Do not fall back to plaintext storage. Plaintext exported setup files are transfer artifacts, not the saved credential store; the import screen can remind the friend to delete their copy afterwards.

## Overlay behaviour

### Normal use

Default size: **700 × 200 DIPs**, bottom-centre of the primary monitor. Default font: 24 DIPs, white text on an approximately 85% opaque dark background. Text remains opaque when background opacity changes.

Display the newest one or two readable caption blocks, using the same content-selection rules as the host overlay. Show a discreet draft indicator where applicable. Corrections replace the same caption; they do not append duplicate lines. Keep the previous useful caption while a new translation is pending. Failed or retracted drafts must disappear.

No untranslated foreign text, technical timings, original/details controls, audio meter or second dashboard in this viewer. Same-language captions remain supported when that is the host's selected output.

Text wraps to the viewer's width. When space is limited, remove the older block first. Never cut through a line or silently imply a truncated sentence is complete. If the newest block still does not fit, show a visible clipping indicator; **Adjust overlay** allows enlargement. Do not shrink the font below the viewer's choice to squeeze in more content.

Sharing off hides the reading overlay after clearing it. The tray remains available. While sharing is active but nobody speaks, retain the last caption briefly, then clear it after 15 seconds without new readable content. This is separate from connection health: silence is not a disconnect. The sharing projection tracks that expiry independently of the host's local overlay and omits expired rows from reconnect snapshots. Each delivered row includes its remaining lifetime; unchanged snapshots and heartbeats never extend an existing row's expiry.

### Move, resize and click-through

| Action | Behaviour |
| --- | --- |
| First launch | Open in **Adjust overlay** mode with sample text, drag handle and resize edges. |
| Drag / resize | Move by the header; resize from edges and corners. Save when adjustment ends. |
| **Lock / click-through** | Hide editing controls and pass mouse input through the whole overlay to EVE or other apps. |
| **Ctrl+Shift+F8** | Configurable global shortcut toggles Adjust and locked viewing. It must work while EVE is focused. |
| Escape while Adjust has focus | Return to locked viewing only if the recovery shortcut registered successfully. Do not install a global Escape hook. |
| Tray → **Adjust overlay** | Show and unlock the overlay, including when the host is offline. |
| Tray → **Recover overlay** | Show, unlock and move it into the current monitor's work area. |
| Launch EXE a second time | Ask the existing instance to recover its overlay; do not start a second viewer. |
| Tray → **Hide captions** | Suppress automatic showing until explicitly re-enabled. Connection can remain ready. |
| Tray → **Exit** | Close the connection and the application. |

Register and verify the recovery shortcut before enabling or restoring click-through. If it conflicts, leave the overlay interactive and offer another shortcut. Tray recovery must remain available independently. Explicit Adjust/Recover mode overrides all automatic hide rules: sharing-off or disconnect clears real captions but leaves the editing controls and sample text visible. Use the native layered-window click-through style; disabling WPF hit testing alone is insufficient.

Caption arrivals and reconnects must never steal keyboard focus. Explicit Adjust/Recover actions may focus the editing window. Normal viewing is topmost and non-activating. Test EVE windowed and borderless modes; exclusive fullscreen is outside V1's guarantee.

Keep settings small: font size, background opacity, shortcut, show/hide, reset position, host connection, and **Start with Windows**. Offer startup once; enable it only when chosen. Without it, the viewer must be running in the tray to receive captions.

Save monitor identity and monitor-relative bounds in DIPs. Support mixed DPI and negative desktop coordinates. On display removal, reconnect or invalid saved bounds, clamp to a remaining work area. Never restore a hidden/off-screen adjustment handle. A crash during adjustment should recover interactively.

## Components and boundaries

| Component | Responsibilities | Deliberately excluded |
| --- | --- | --- |
| Existing companion | Capture, recognition, translation and local controls | Changes to the current audio/model pipeline |
| New host sharing module | Project safe caption state, pair viewers, encrypt and publish | Accepting viewer text/audio or translation requests |
| Relay | Authenticate roles, route bounded messages, persist credential records | Models, OpenAI access, caption decryption or transcript storage |
| New viewer | Decrypt, validate, maintain display state and draw the overlay | Discord integration, capture, translation or remote control |

The existing Windows named-pipe broker exposes account/settings operations and stays strictly local. Sharing gets a separate narrow protocol. Do not forward its RPC requests, raw event buffer, diagnostics or error objects.

Use a TypeScript/Node relay compatible with the host project's supported runtime, pinned at implementation. Deploy behind HTTPS/WSS on port 443, with one persistent store for host/device credential hashes and revocation. A single-instance service with a small SQLite database is sufficient for V1; horizontal scaling, accounts/billing and public registration are excluded.

Only the host provisioning credential can register/remove viewers or publish. Viewer endpoints accept connection setup and bounded liveness messages. All connections are outbound from users' PCs. Hosting needs an agreed reachable server and TLS hostname before remote deployment; no provider or paid service is selected by this design.

## Caption protocol and delivery

Version the protocol independently of CommsTranslate. Each authenticated display state contains a fresh broadcast ID, display revision, connection sequence number, output language, status, and at most two caption objects. Caption objects carry an opaque ID, revision, plain text, remaining display lifetime and draft/final state. The connection sequence counts every encrypted message; the display revision changes only when the actual display state changes. Compute remaining lifetime when sending, without scheduling repeated redraws; expire the row with a one-shot deadline. Network identifiers must not expose Discord channel IDs or account details.

The host performs caption selection before transmission. It sends only material appropriate for the reading-language display. Viewers use plain text controls, never HTML or Markdown rendering. The original source text, prompts, timings, login state and raw exceptions are absent.

Updates are complete current-view snapshots, not token-by-token appends. A newer sequence replaces the older state atomically. Stable caption IDs preserve each row during corrections. Retraction, sharing-off and language/session transitions clear or replace state explicitly.

Coalesce streaming changes to at most **four updates per second**. Flush final results, retractions and stop state promptly, replacing any queued obsolete preview. No heartbeat or duplicate state triggers a layout pass. No changes means no caption traffic. Do not compress these small messages in V1.

Set an 8 KiB encoded frame limit, bounded caption lengths, a maximum 32 KiB pending queue per viewer and a 20-viewer limit. Oversized legitimate content must produce an explicit unavailable/clipped state, never unsafe byte truncation. A slow viewer gets the latest complete view or disconnects; it must never accumulate a transcript backlog or delay other viewers. The relay retains no caption history for offline viewers.

### Encryption and authorisation

Use built-in AES-256-GCM and HKDF-SHA256 through Node and .NET APIs, with shared interoperability test vectors. TLS remains required. Each viewer has its own 256-bit random pairing secret, distinct from its relay authentication token.

A new connection uses a fresh viewer challenge and host-generated random connection salt. Derive a connection-specific host-to-viewer key with protocol, host ID, viewer ID and challenge bound into the derivation. Use a 96-bit nonce constructed from the connection-wide message counter under that derived key, with a 128-bit authentication tag. Never reset that counter on pause, sharing-off or a new broadcast. Reconnect or process restart establishes a new key before resetting it. Authenticate routing/version/connection/sequence fields as associated data, using an explicitly specified byte encoding rather than ad-hoc JSON canonicalisation.

The first encrypted state must match the viewer's fresh challenge. Old-connection frames are rejected. Sequence checks reject duplicate or out-of-order delivery. A stop retires its broadcast ID; only an authenticated new-state transition can activate a new broadcast. Freeze exact field encodings and size checks before implementing either endpoint. Apply authenticated per-viewer rate limits before key derivation/encryption: one handshake attempt per second and one outstanding liveness challenge, with tightly bounded message sizes. Both relay and host enforce limits, so relaying a request does not make it trusted.

The host encrypts once per connected viewer. For this small text-only group, that avoids group-key rotation and lets removal affect only one pairing. It does not repeat inference. A viewer knows its own decryption secret but no other viewer's secret or the publishing credential; it cannot forge captions for other viewers. This design does not protect a person's own screen from modifications they make to their own app, or prevent recipients from copying captions they receive.

The relay can observe connections, sizes and timing but should not receive the caption keys or plaintext. Relay unavailability can stop sharing. Host and viewer logs must not record message bodies, pairing material, request headers or full URLs with credentials. Credentials never go in URL query strings.

## Connection and failure states

| State | Viewer behaviour |
| --- | --- |
| Unpaired | Small setup window, no network retry loop. |
| Connected, sharing off | Overlay hidden; tray says **Waiting for host**. |
| Sharing active | Show captions without activating the window, unless manually hidden. |
| Host paused | Clear captions; show a brief paused status, then wait. |
| Connection lost / lease expired | Immediately clear readable content, briefly show **Disconnected**, then hide and retry. |
| Pairing revoked or invalid | Clear; stop automatic authentication retries; show an actionable tray status. |

Reconnect with jittered backoff around 1, 2, 5, 10 and 30 seconds, capped at 30 seconds. A network-change or resume event allows one prompt retry, not a burst. Never retry authentication errors as network failures.

A reconnect starts blank and obtains fresh host-authenticated state. It receives only the current display, not missed speech. Receipt of host sharing-off or explicit socket closure clears immediately. For silent failures during active sharing, use a small liveness challenge about every three seconds and clear within nine seconds without a valid timely host response. Only a response bound to a fresh outstanding challenge renews that lease; replayed caption traffic cannot keep a dead session looking live. The response must authenticate current sharing status, broadcast ID and display revision, not merely echo the challenge. A mismatch clears the display and requests current state; sharing-off clears without waiting for another snapshot. This prevents a withheld stop/update from being masked by fresh heartbeat replies. Use monotonic timers so normal wall-clock adjustments do not extend a lease.

When sharing is off, ordinary connection keepalive can be much less frequent, about 30 seconds. A late caption must never revive an ended broadcast. Pause, stop, reconnect and channel changes cancel pending presentation work before a replacement session becomes visible.

## Resource targets and verification

These are provisional acceptance targets, not current measurements or promises. Measure a Release build on an ordinary Windows laptop with multilingual captions, both idle and while EVE is running.

| Metric | Initial target / measurement |
| --- | --- |
| Viewer processes | One; no browser, worker, audio or model process |
| Idle CPU | Below 0.1% of total machine CPU averaged over 5 minutes |
| Typical active CPU | Below 1% of total machine CPU averaged over 5 minutes; record logical processor count and CPU time as well |
| Memory | Aim below 100 MiB steady working set; investigate sustained use above 150 MiB or growth during a 2-hour run; report private bytes too |
| Idle network | Below 2 KiB/minute in a healthy sharing-off connection, excluding setup/reconnect |
| Active network | Aim below 5 MiB/hour per viewer on a representative speech replay; separately report long-caption/continuous-draft worst cases |
| Local viewer delay | Socket receipt to UI update p95 below 50 ms; distinguish UI handling from actual screen presentation |
| Added host coalescing | At most 250 ms for previews; final/stop updates do not wait for that interval |
| Distribution | Self-contained ZIP target below 100 MiB; report measured size rather than stripping required runtime files |

Define the representative network fixture before benchmarking: speech in approximately 4–8-second phrases, typical translated lengths of 60–200 characters, and approximately two seconds of streamed text per phrase. Also test continuous speech, long multilingual captions and sustained four-update-per-second delivery. The 5 MiB/hour target is not a worst-case ceiling: 1 KiB at four updates per second is already about 14 MiB/hour before transport overhead.

Test cross-network delivery separately; do not promise a fixed Internet latency. Friends inherit the existing transcription/translation delay plus delivery and drawing time, with no additional AI stage.

Avoid timers that redraw the window, animations, blur effects, polling Discord/processes, frequent settings writes and unbounded observable collections. Render only changed rows. Save preferences atomically after changes, not on every streamed caption. Suspend rendering while hidden but retain only the latest bounded state.

## Implementation order

1. **Viewer shell and resource spike.** Build the native overlay against a local synthetic caption source. Verify multilingual layout, dragging, resizing, click-through, focus, tray recovery, DPI and resource use before connecting real comms.
2. **Protocol and relay.** Freeze the wire format, limits, connection lifecycle and crypto vectors. Implement role separation, pairing records, revocation, fresh-state handshake and bounded routing. Verify with synthetic text and disconnected/slow clients.
3. **Host publisher.** Add the narrow safe-caption projection and Share toggle. Reuse current presentation semantics through shared pure logic or golden fixtures. Keep original local broker and pipeline behaviour intact. Add viewer management and configuration export.
4. **End-to-end Windows acceptance and packaging.** Test host plus two viewers across different networks, then simulate 20. Publish the viewer ZIP, small host patch, relay deployment instructions and rollback notes. Preserve existing models, settings, login and unrelated Vencord plugins.

No live deployment or executable is produced by this design task. Avoid rebuilding or replacing functioning caption components until their specific integration step.

## Required acceptance cases

- A paired friend closes/reopens the viewer and restarts Windows: it still follows the host without another invitation. Startup behaviour matches the option they selected.
- Host sharing on shows the current English feed to two viewers; changing one viewer's geometry affects neither the other viewer nor the host.
- One, ten and twenty viewers produce exactly the same model call count as no viewers for the same host session. Viewer-originated frames cannot invoke account, caption-start, translation or settings methods.
- Sharing off, capture stop and channel change clear all viewers. Reconnect cannot revive previous-channel captions. Silence does not produce a false disconnection.
- Partial corrections, final replacements, failed drafts, out-of-order updates and retries produce no duplicate or resurrected captions.
- Slow/dead viewers and relay failures preserve host captions, bounded memory and responsiveness. Revocation excludes future text even if relay revocation acknowledgement is delayed, because the host stops encrypting for that identity.
- Replayed/tampered frames, wrong viewer IDs, invalid tags, oversized input, expired liveness challenges and unsupported versions fail closed without crashing.
- Click-through really delivers clicks to the underlying application. Global shortcut conflicts, second launch, hidden tray icons, monitor removal and mixed DPI always leave a recovery route.
- Ordinary delivery does not steal EVE focus. Native tests cover windowed/borderless EVE and a standard Windows desktop.
- A clean Windows test machine can extract and launch the viewer without installing dependencies or administrator elevation. Treat any signing/reputation prompt as a distribution issue to resolve/document, not a reason to disable Windows protection.

## Evidence and remaining deployment choices

Current source inspected: `packages/shared/src/index.ts`, `packages/companion/src/core/events.ts`, `voice.ts`, `broker.ts`, `packages/companion/src/main.ts`, and `packages/companion/ui/live-state.js` / `overlay.js`. Caption IDs, revisions and source/presentation separation already exist. The current overlay is Electron-specific; reuse its behaviour and fixtures, not its runtime in the friend app.

Before deployment, decide where the relay and TLS hostname will live. Existing suitable hosting can be reused; otherwise agree the hosting choice and any recurring cost. Windows 11 x64 is the initial supported viewer platform. No ongoing session links, per-viewer language selection, browser viewer, audio streaming, recording, chat history or auto-updater in V1.

Primary references, checked 8 October 2026:

- [Microsoft: self-contained deployment](https://learn.microsoft.com/en-us/dotnet/core/deploying/) — bundling the runtime removes a separate runtime installation requirement.
- [Microsoft: WPF window transparency](https://learn.microsoft.com/en-us/dotnet/api/system.windows.window.allowstransparency?view=windowsdesktop-10.0) — transparent WPF windows require a borderless window style.
- [Microsoft: layered windows and click-through](https://learn.microsoft.com/en-us/windows/win32/winmsg/window-features) — native layered-window input behaviour.
- [Microsoft: RegisterHotKey](https://learn.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-registerhotkey) — registration failure and non-repeating shortcuts.
- [Microsoft: Windows data protection](https://learn.microsoft.com/en-us/dotnet/standard/security/how-to-use-data-protection) — protecting saved secrets for the Windows user.
- [Microsoft: AES-GCM](https://learn.microsoft.com/en-us/dotnet/api/system.security.cryptography.aesgcm.encrypt?view=net-10.0) and [HKDF](https://learn.microsoft.com/en-us/dotnet/api/system.security.cryptography.hkdf?view=net-10.0) — standard encryption APIs; nonce uniqueness is required.
- [WebRTC: peer connections](https://webrtc.org/getting-started/peer-connections) — direct peer connectivity still requires signalling and can need relay infrastructure, supporting the simpler WSS relay choice for V1.
