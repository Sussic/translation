import {app,BrowserWindow,ipcMain,safeStorage,shell,globalShortcut,dialog} from 'electron';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import {randomUUID} from 'node:crypto';
import {existsSync} from 'node:fs';
import {writeFile} from 'node:fs/promises';
import {validateRequest,ProtocolError,errorResponse,type AppSettings,type CaptionEvent} from '@comms/shared';
import {publishBridgeHelper} from '@comms/shared/bridge-protection';
import {createCredentialEncryption} from './auth/encryption.js';
import {createChatGPTProvider} from './providers/chatgpt.js';
import {SettingsStore} from './core/settings.js';
import {EventBuffer} from './core/events.js';
import {LocalRuntime} from './core/local.js';
import {TranslationService} from './core/translation.js';
import {TranslationDiagnostics,validateDiagnosticsCall} from './core/translationDiagnostics.js';
import {VoicePipeline} from './core/voice.js';
import {SecureBroker} from './core/broker.js';
import {CompanionService} from './core/service.js';
import {ModelManager} from './core/models.js';
import {resolveWorkerPaths} from './core/paths.js';
import {showDashboard} from './core/windowVisibility.js';
import {StartupReporter,StartupFailure,StartupSettingsGuard,startupFailureMessage,type StartupCode} from './core/startup.js';

const here=path.dirname(fileURLToPath(import.meta.url));
const projectRoot=path.resolve(here,'../../..');
const startup=new StartupReporter(process.env.COMMS_STARTUP_RUN_ID);
const diagnostics=new TranslationDiagnostics();
let exportingAnalysis=false;
let dashboard:BrowserWindow|undefined,overlay:BrowserWindow|undefined;
let service:CompanionService|undefined,broker:SecureBroker|undefined;
let voice:VoicePipeline|undefined,local:LocalRuntime|undefined;
let startupSettings:StartupSettingsGuard|undefined,models:ModelManager|undefined;
let saveBoundsTimer:NodeJS.Timeout|undefined;
let closing=false,failureShown=false,bridgeStartupSettled=false;

function ensureStarting(){if(closing)throw new StartupFailure('STARTUP_INTERRUPTED');}
function configureWindow(win:BrowserWindow){
    win.webContents.setWindowOpenHandler(()=>({action:'deny'}));
    win.webContents.on('will-navigate',(event,url)=>{if(url!==win.webContents.getURL())event.preventDefault();});
}
function sendEvent(event:CaptionEvent){
    diagnostics.observe(event.type);
    for(const win of [dashboard,overlay])if(win&&!win.isDestroyed())win.webContents.send('comms:event',event);
}
function bridgeUnavailable(code:StartupCode,events:EventBuffer){
    startup.unavailableBridge(code);
    events.push({type:'error',error:{code,message:startupFailureMessage(code)}});
    events.push({type:'status'});
}
function setOverlaySettings(settings:AppSettings){
    if(!overlay||overlay.isDestroyed())return;
    const s=settings.overlay;
    overlay.setOpacity(s.opacity);overlay.setAlwaysOnTop(s.alwaysOnTop,'screen-saver');
    overlay.setIgnoreMouseEvents(s.clickThrough,{forward:true});overlay.setFocusable(!s.clickThrough);
    const old=overlay.getBounds();
    overlay.setBounds({x:s.x??old.x,y:s.y??old.y,width:s.width,height:s.height});
    overlay.webContents.send('comms:event',{type:'settings',settings});
}
function settingsChanged(settings:AppSettings){
    setOverlaySettings(settings);globalShortcut.unregisterAll();
    try{
        const stop=globalShortcut.register(settings.stopHotkey,()=>{void voice?.stop();});
        const show=globalShortcut.register(settings.overlayHotkey,()=>{if(overlay?.isVisible())overlay.hide();else overlay?.showInactive();});
        if(!stop||!show)sendEvent({seq:0,type:'error',timestamp:Date.now(),error:{code:'HOTKEY_UNAVAILABLE',message:'A configured hotkey could not be registered. Choose another combination.'}});
    }catch{sendEvent({seq:0,type:'error',timestamp:Date.now(),error:{code:'HOTKEY_INVALID',message:'A configured hotkey is invalid.'}});}
}

async function start(){
    const userDir=process.env.LOCALAPPDATA?path.join(process.env.LOCALAPPDATA,'CommsTranslate'):path.join(app.getPath('userData'),'CommsTranslate');
    const store=new SettingsStore(userDir);
    startupSettings=new StartupSettingsGuard(store);
    try{await startupSettings.load();}catch{throw new StartupFailure('SETTINGS_LOAD_FAILED');}
    ensureStarting();startup.settingsReady();
    const workerPaths=resolveWorkerPaths(app.isPackaged,projectRoot,process.resourcesPath);
    const python=app.isPackaged?path.join(userDir,'worker-env','Scripts','python.exe'):path.join(projectRoot,'.venv',process.platform==='win32'?'Scripts/python.exe':'bin/python');
    local=new LocalRuntime(python,path.join(workerPaths.workersDir,'local','worker.py'),path.join(userDir,'models'),()=>store.settings);
    let auth:ReturnType<typeof createChatGPTProvider>;
    try{
        auth=createChatGPTProvider({
            storageDir:path.join(userDir,'chatgpt'),credentialEncryption:createCredentialEncryption(safeStorage),
            openExternal:async url=>{
                const parsed=new URL(url);
                if(parsed.protocol!=='https:'||parsed.hostname!=='auth.openai.com')throw new ProtocolError('AUTH_URL_REJECTED','Unexpected sign-in URL.');
                await shell.openExternal(url);
            }
        });
    }catch{throw new StartupFailure('AUTH_INIT_FAILED');}
    const events=new EventBuffer(100,sendEvent),translator=new TranslationService(store,local,auth,diagnostics);
    voice=new VoicePipeline(workerPaths.captureExecutable,local,translator,events,()=>store.settings,async()=>{
        const account=await auth.getStatus();return account.status==='connected'&&account.sharing;
    });
    const preferences={preload:path.join(here,'preload.cjs'),contextIsolation:true,nodeIntegration:false,sandbox:true};
    try{
        dashboard=new BrowserWindow({width:1120,height:850,minWidth:780,minHeight:600,show:false,backgroundColor:'#111722',title:'CommsTranslate',webPreferences:preferences});
        configureWindow(dashboard);dashboard.setMenuBarVisibility(false);
        // Record fixed categories only; raw exceptions can contain local paths or private data.
        dashboard.webContents.on('preload-error',()=>startup.diagnostic('PRELOAD_ERROR'));
        dashboard.webContents.on('render-process-gone',()=>startup.diagnostic('RENDERER_STOPPED'));
        overlay=new BrowserWindow({width:store.settings.overlay.width,height:store.settings.overlay.height,frame:false,transparent:true,show:false,skipTaskbar:true,resizable:true,focusable:false,webPreferences:preferences});
        configureWindow(overlay);setOverlaySettings(store.settings);
    }catch{throw new StartupFailure('UI_LOAD_FAILED');}
    const allowed=new Set([dashboard.webContents.id,overlay.webContents.id]);
    ipcMain.on('comms:startup',(event,stage:unknown)=>{
        if(event.sender.id!==dashboard?.webContents.id||event.senderFrame!==event.sender.mainFrame)return;
        if(stage==='RENDERER_BOOT'||stage==='DASHBOARD_SCRIPT_READY'||stage==='RENDERER_SCRIPT_ERROR')startup.diagnostic(stage);
    });
    ipcMain.handle('comms:invoke',async(event,method:unknown,params:unknown)=>{
        const id=randomUUID();let trustedDashboardStatus=false;
        try{
            if(!allowed.has(event.sender.id)||event.senderFrame!==event.sender.mainFrame)throw new ProtocolError('UNAUTHORIZED','Untrusted UI request.');
            if(typeof method==='string'&&method.startsWith('diagnostics.')){
                let call:ReturnType<typeof validateDiagnosticsCall>;
                try{call=validateDiagnosticsCall(method,params);}catch{throw new ProtocolError('INVALID_REQUEST','Invalid translation analysis operation.');}
                const isDashboard=event.sender.id===dashboard?.webContents.id;
                if(call.method!=='diagnostics.render'&&!isDashboard)throw new ProtocolError('UNAUTHORIZED','Open translation analysis in the companion dashboard.');
                let result:unknown;
                switch(call.method){
                    case 'diagnostics.start':result=diagnostics.start();break;
                    case 'diagnostics.stop':result=diagnostics.stop();break;
                    case 'diagnostics.clear':result=diagnostics.clear();break;
                    case 'diagnostics.status':result=diagnostics.status();break;
                    case 'diagnostics.render':diagnostics.rendered(call.params.traceId as string,isDashboard?'dashboard':'overlay',call.params.stage as 'preview'|'complete');result={accepted:true};break;
                    case 'diagnostics.export':{
                        if(exportingAnalysis)throw new ProtocolError('EXPORT_BUSY','Finish the current save dialog first.');
                        exportingAnalysis=true;
                        try{
                            const name=`CommsTranslate-analysis-T4-${new Date().toISOString().replace(/[:.]/g,'-')}.txt`;
                            const chosen=await dialog.showSaveDialog(dashboard!,{title:'Save translation analysis',defaultPath:path.join(app.getPath('downloads'),name),filters:[{name:'Text report',extensions:['txt']}],properties:['showOverwriteConfirmation']});
                            if(chosen.canceled||!chosen.filePath){result={saved:false};break;}
                            try{await writeFile(chosen.filePath,diagnostics.report(),{encoding:'utf8',mode:0o600});}
                            catch{throw new ProtocolError('EXPORT_FAILED','The report could not be saved. Choose a writable folder and try again.');}
                            result={saved:true,fileName:path.basename(chosen.filePath)};
                        }finally{exportingAnalysis=false;}
                        break;
                    }
                }
                return {v:1,id,ok:true,result};
            }
            const request=validateRequest({v:1,id,method,params});
            trustedDashboardStatus=event.sender.id===dashboard?.webContents.id&&request.method==='status';
            if(trustedDashboardStatus)startup.diagnostic('UI_STATUS_REQUESTED');
            if(!service)throw new ProtocolError('NOT_READY','The companion is still initializing.');
            const result=await service.handle(request);
            if(trustedDashboardStatus){startup.diagnostic('UI_STATUS_RETURNED');startup.verifyDashboardStatus();}
            return {v:1,id,ok:true,result};
        }catch(error){if(trustedDashboardStatus){startup.diagnostic('UI_STATUS_REJECTED');startup.noteDashboardStatusFailure();}return errorResponse(id,error);}
    });
    dashboard.webContents.session.setPermissionRequestHandler((contents,permission,callback)=>callback(contents===dashboard?.webContents&&permission==='clipboard-sanitized-write'));
    dashboard.webContents.session.on('will-download',(event,item,contents)=>{
        if(contents!==dashboard?.webContents||!item.getURL().startsWith('blob:')){event.preventDefault();return;}
        item.setSaveDialogOptions({title:'Export glossary',defaultPath:path.join(app.getPath('downloads'),'comms-translate-glossary.json')});
    });
    models=new ModelManager(python,path.join(workerPaths.workersDir,'local','setup_models.py'),path.join(userDir,'models'),()=>{
        if(voice?.status().active)throw new ProtocolError('STOP_CAPTURE_FIRST','Stop captions before installing or removing models.');
    },()=>{translator.clear();local!.stop();},()=>local!.ensure(false),()=>store.settings.asrProfile);
    service=new CompanionService(store,local,voice,translator,auth,events,settingsChanged,visible=>{
        visible?overlay?.showInactive():overlay?.hide();setOverlaySettings(store.settings);
    },models,()=>startup.bridgeStatus(),()=>{if(!showDashboard(dashboard))throw new ProtocolError('UI_UNAVAILABLE','The companion window could not be shown. Restart the companion.');},stage=>startup.diagnostic(stage));
    dashboard.on('closed',()=>{dashboard=undefined;app.quit();});
    const uiRoot=path.join(here,'../ui');
    try{await Promise.all([dashboard.loadFile(path.join(uiRoot,'index.html')),overlay.loadFile(path.join(uiRoot,'overlay.html'))]);}
    catch{throw new StartupFailure('UI_LOAD_FAILED');}
    ensureStarting();if(!showDashboard(dashboard))throw new StartupFailure('UI_LOAD_FAILED');
    startup.uiReady();settingsChanged(store.settings);
    const saveBounds=()=>{
        if(!overlay||overlay.isDestroyed())return;
        const bounds=overlay.getBounds();store.settings.overlay={...store.settings.overlay,x:bounds.x,y:bounds.y,width:bounds.width,height:bounds.height};
        if(saveBoundsTimer)clearTimeout(saveBoundsTimer);
        saveBoundsTimer=setTimeout(()=>{void store.saveCurrent().catch(()=>{});},500);
    };
    overlay.on('move',saveBounds);overlay.on('resize',saveBounds);

    if(process.platform!=='win32'){
        bridgeStartupSettled=true;bridgeUnavailable('BRIDGE_PLATFORM_UNSUPPORTED',events);
    }else if(!existsSync(workerPaths.bridgeExecutable)){
        bridgeStartupSettled=true;bridgeUnavailable('BRIDGE_HELPER_MISSING',events);
    }else{
        let canStartBridge=true;
        if(app.isPackaged){
            try{await publishBridgeHelper({sourceExecutable:workerPaths.bridgeExecutable,localAppData:process.env.LOCALAPPDATA});}
            catch{canStartBridge=false;bridgeStartupSettled=true;bridgeUnavailable('BRIDGE_HELPER_PUBLICATION_FAILED',events);}
        }
        ensureStarting();
        if(canStartBridge){
            broker=new SecureBroker(workerPaths.bridgeExecutable,userDir,safeStorage,async request=>{
                const result=await service!.handle(request);
                if(request.method==='translate'&&result&&typeof result==='object'){
                    const {diagnosticId:_diagnosticId,...publicResult}=result as Record<string,unknown>;return publicResult;
                }
                return result;
            },()=>{
                if(bridgeStartupSettled&&!closing)bridgeUnavailable('BRIDGE_STOPPED',events);
            });
            try{
                await broker.start();ensureStarting();bridgeStartupSettled=true;startup.readyBridge();events.push({type:'status'});
            }catch(error){
                if(error instanceof StartupFailure)throw error;
                bridgeStartupSettled=true;
                const code=error instanceof ProtocolError&&error.code==='BRIDGE_PROTECTION_FAILED'?'BRIDGE_PROTECTION_FAILED':'BRIDGE_START_FAILED';
                bridgeUnavailable(code,events);
            }
        }
    }
    await startup.waitForDashboardStatus();ensureStarting();
    void local.ensure(false).catch(()=>{});
}

async function failStartup(code:StartupCode){
    if(closing||failureShown)return;failureShown=true;startup.fail(code);
    try{
        const options={type:'error' as const,title:'CommsTranslate startup',message:startupFailureMessage(code)};
        if(app.isReady())await dialog.showMessageBox(options);else dialog.showErrorBox(options.title,options.message);
    }catch{/* Launcher still receives the sanitized failure code. */}
    app.quit();
}

app.setName('CommsTranslate');startup.start();
const ownsInstance=app.requestSingleInstanceLock();
if(!ownsInstance){startup.existingInstance();app.quit();}
else{
    app.on('second-instance',()=>{showDashboard(dashboard);});
    process.on('uncaughtException',()=>{void failStartup('RUNTIME_FATAL');});
    process.on('unhandledRejection',()=>{void failStartup('RUNTIME_FATAL');});
    app.whenReady().then(async()=>{
        startup.appReady();
        try{await start();}catch(error){await failStartup(error instanceof StartupFailure?error.code:'UNEXPECTED_STARTUP_ERROR');}
    }).catch(()=>{void failStartup('APP_READY_FAILED');});
    app.on('window-all-closed',()=>app.quit());
    app.on('before-quit',event=>{
        if(closing)return;event.preventDefault();closing=true;globalShortcut.unregisterAll();
        if(saveBoundsTimer)clearTimeout(saveBoundsTimer);models?.close();
        void (async()=>{
            try{await voice?.stop();}
            finally{
                voice?.close();local?.stop();await startupSettings?.saveOnClose().catch(()=>{});
                await broker?.stop().catch(()=>{});startup.close();app.quit();
            }
        })();
    });
}
