import { contextBridge, ipcRenderer } from "electron";

// Keep this boundary small. The main process also checks the sender and all
// method-specific parameters; this list is not the security authority.
const ALLOWED_METHODS = new Set([
    "status", "capabilities", "translate", "cancel", "auth.signIn", "auth.signOut", "auth.models",
    "settings.get", "settings.update", "glossary.get", "glossary.set", "voice.sources", "voice.start",
    "voice.stop", "voice.pause", "voice.heartbeat", "events.poll", "overlay.show", "overlay.hide",
    "models.list", "models.plan", "models.install", "models.remove", "models.test", "ui.open",
    "diagnostics.start", "diagnostics.stop", "diagnostics.clear", "diagnostics.status", "diagnostics.export", "diagnostics.render"
]);

contextBridge.exposeInMainWorld("comms", Object.freeze({
    reportStartup(stage: unknown) {
        if (typeof stage === 'string' && ['RENDERER_BOOT','DASHBOARD_SCRIPT_READY','RENDERER_SCRIPT_ERROR'].includes(stage)) {
            ipcRenderer.send('comms:startup', stage);
        }
    },
    async invoke(method: string, params: Record<string, unknown> = {}) {
        if (!ALLOWED_METHODS.has(method) || !params || typeof params !== "object" || Array.isArray(params)) {
            throw new Error("Unsupported companion operation.");
        }
        const { token: _token, ...safeParams } = params;
        return ipcRenderer.invoke("comms:invoke", method, safeParams);
    },
    subscribe(callback: (event: unknown) => void) {
        if (typeof callback !== "function") throw new Error("An event callback is required.");
        const listener = (_event: Electron.IpcRendererEvent, value: unknown) => callback(value);
        ipcRenderer.on("comms:event", listener);
        return () => ipcRenderer.removeListener("comms:event", listener);
    }
}));
