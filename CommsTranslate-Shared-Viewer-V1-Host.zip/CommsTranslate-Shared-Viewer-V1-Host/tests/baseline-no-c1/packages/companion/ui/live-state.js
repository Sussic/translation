"use strict";
(() => {
/** Session-only UI state. No audio, captions or credentials are persisted. */
class CaptionTimeline {
    constructor(limit = 40, { retainReadable = 0 } = {}) { this.limit = limit; this.retainReadable = Math.min(limit, retainReadable); this.rows = new Map(); this.seen = new Set(); this.retired = new Set(); this.session = null; }
    clear(retire = true) {
        if (retire && this.session) this.retired.add(this.session);
        while (this.retired.size > 16) this.retired.delete(this.retired.values().next().value);
        this.rows.clear(); this.seen.clear(); this.session = null;
    }
    activate(session) {
        if (!session || this.retired.has(session)) return false;
        if (this.session !== session) { this.clear(); this.session = session; }
        return true;
    }
    accept(event) {
        if (event?.type !== 'caption' || !event.sessionId || !event.utteranceId || !this.activate(event.sessionId)) return false;
        const key = `${event.sessionId}:${event.utteranceId}`;
        const previous = this.rows.get(key);
        if (!previous && this.seen.has(key)) return false; // An evicted line must not reappear on a late translation.
        if (previous && Number.isFinite(event.seq) && Number.isFinite(previous.seq) && event.seq <= previous.seq) return false;
        const settled = previous && ['complete', 'failed'].includes(previous.translationState);
        if (settled) return false; // Completed or failed utterances cannot be revived by late work.
        if (previous?.provisional === false && event.provisional === true) return false; // Final source cannot regress to an ASR partial.
        if (previous?.translationState && !event.translationState) return false;
        const sourceChanged = previous && ((typeof event.text === 'string' && event.text !== previous.text)
            || (event.sourceLanguage !== undefined && event.sourceLanguage !== previous.sourceLanguage)
            || (event.targetLanguage !== undefined && event.targetLanguage !== previous.targetLanguage)
            || (event.provisional === false && previous.provisional === true));
        const draftCleared = previous?.translationState === 'streaming' && event.translationState === 'pending';
        const requestChanged = previous?.diagnosticId && event.diagnosticId && previous.diagnosticId !== event.diagnosticId;
        // ASR revisions and replacement requests provide fresh timing. Never combine their measurements with an older draft.
        const timing = sourceChanged || draftCleared || requestChanged ? { ...event.timing } : { ...previous?.timing, ...event.timing };
        const next = { ...previous, ...event, key, firstTimestamp: previous?.firstTimestamp ?? event.timestamp, timing };
        // Older producers can omit translated; only an explicit empty string clears a still-compatible prefix draft.
        if (event.translated === undefined && previous) next.translated = previous.translated;
        // A replacement made after analysis stops has no trace. It must not inherit the discarded draft's ID.
        if (event.diagnosticId === undefined && (sourceChanged || draftCleared || event.translated === '')) delete next.diagnosticId;
        if (next.translationState === 'failed' || next.error) next.translated = '';
        this.rows.set(key, next); this.seen.add(key);
        if (this.rows.size > this.limit) {
            const retained = new Set(this.retainReadable ? [...this.rows].filter(([, row]) => captionPresentation(row).readable).slice(-this.retainReadable).map(([rowKey]) => rowKey) : []);
            for (const rowKey of this.rows.keys()) { if (this.rows.size <= this.limit) break; if (!retained.has(rowKey)) this.rows.delete(rowKey); }
        }
        // Bound remembered evictions while retaining considerably more than the backend event buffer.
        while (this.seen.size > 1000) this.seen.delete(this.seen.values().next().value);
        return true;
    }
}
function captionPresentation(caption) {
    const failed = caption.translationState === 'failed' || Boolean(caption.error);
    const translated = failed || typeof caption.translated !== 'string' || !caption.translated.trim() ? '' : caption.translated;
    const sameLanguageFinal = !failed && caption.provisional === false && caption.translationState === 'complete' && caption.sourceLanguage && caption.sourceLanguage === caption.targetLanguage && (!caption.languageDetection || caption.languageDetection.uncertain !== true && caption.languageDetection.confidence >= .85);
    const primary = translated || (sameLanguageFinal ? caption.text || '' : '');
    const readable = Boolean(primary.trim());
    const original = caption.text || '';
    const draft = readable && (caption.provisional === true || caption.translationState === 'streaming');
    const label = failed ? 'Translation unavailable' : !readable ? 'Translating…' : draft ? 'Draft' : primary === caption.text ? 'Caption' : 'Translated';
    const uncertainLanguage = Boolean(caption.languageDetection?.uncertain);
    const source = caption.sourceLanguage ? languageName(caption.sourceLanguage) : '';
    const languageLabel = !caption.languageDetection ? '' : uncertainLanguage ? `Language uncertain${source ? ` (${source})` : ''}` : source ? `${source} detected` : 'Language detected';
    return { primary, original, label, languageLabel, uncertainLanguage, failed, draft, readable };
}
let languageNames;
try { languageNames = new Intl.DisplayNames(['en'], { type: 'language' }); } catch { /* Use the code if language display names are unavailable. */ }
function languageName(code) {
    if (!code) return '';
    try { return languageNames?.of(code) || code; } catch { return code; }
}
function parseExpectedLanguages(value) { return [...new Set(String(value).split(',').map(code => code.trim().toLowerCase()).filter(Boolean))]; }
function sameSettingsValue(left, right) {
    return Array.isArray(left) && Array.isArray(right) ? left.length === right.length && left.every((value, index) => value === right[index]) : left === right;
}
function voiceLanguageSummary(settings, voice = {}) {
    const active = voice.active ? voice : settings;
    return { source: active.sourceLanguage, target: active.targetLanguage, automatic: active.speechLanguageMode === 'auto' };
}
function timingLabel(timing = {}) {
    const fields = [['recognitionMs', 'Recognition'], ['recognitionQueueMs', 'Speech queue'], ['endpointWaitMs', 'Pause wait'], ['translationQueueMs', 'Translation queue'], ['firstTextMs', 'First text'], ['translationMs', 'Translation'], ['afterRecognitionMs', 'After recognition'], ['draftLeadMs', 'Early text lead']];
    return fields.filter(([key]) => typeof timing[key] === 'number' && Number.isFinite(timing[key]) && timing[key] >= 0).map(([key, title]) => `${title} ${(timing[key] / 1000).toFixed(1)}s`).join(' · ');
}
/** A form owns only explicitly edited fields, including individual overlay properties. */
function mergeSettingsEdits(latest, edits) {
    const merged = { ...latest, overlay: { ...latest.overlay } };
    for (const [key, value] of Object.entries(edits)) {
        if (key.startsWith('overlay.')) {
            const property = key.slice(8);
            if (value === undefined) delete merged.overlay[property]; else merged.overlay[property] = value;
        } else merged[key] = value;
    }
    return merged;
}

    globalThis.CommsLiveState = Object.freeze({ CaptionTimeline, captionPresentation, languageName, parseExpectedLanguages, sameSettingsValue, voiceLanguageSummary, timingLabel, mergeSettingsEdits });
})();
