"use strict";
(() => {
    const { CaptionTimeline, captionPresentation, languageName } = globalThis.CommsLiveState;
    const $ = id => document.getElementById(id);
    const feed = new CaptionTimeline(40, { retainReadable: 2 }), nodes = new Map();
    const diagnosticReceipts = new Set();
    let settings = null, active = false, paused = false, notice = '', refreshing = false, refreshQueued = false, eventVersion = 0, statusVersion = 0;
    async function rpc(method, params = {}) {
        const value = await window.comms.invoke(method, params);
        if (value?.ok === false) throw new Error(value.error?.message || 'Companion unavailable');
        return value?.ok === true ? value.result : value;
    }
    function applySettings(value) {
        settings = value;
        if (!value?.overlay) return;
        document.documentElement.style.setProperty('--caption-size', value.overlay.fontSize + 'px');
        document.documentElement.style.setProperty('--panel-opacity', String(value.overlay.opacity));
        $('overlay-mode').textContent = languageName(value.targetLanguage);
        render();
    }
    function acknowledge(caption, node) {
        if (document.hidden || !caption.translated?.trim() || !['streaming', 'complete'].includes(caption.translationState) || typeof caption.diagnosticId !== 'string' || !caption.diagnosticId) return;
        const area = $('overlay-captions').getBoundingClientRect(), text = node.querySelector('.translated').getBoundingClientRect();
        const clip = { top: Math.max(area.top, 0), bottom: Math.min(area.bottom, innerHeight), left: Math.max(area.left, 0), right: Math.min(area.right, innerWidth) };
        if (clip.bottom <= clip.top || clip.right <= clip.left || text.height <= 0 || text.width <= 0 || text.bottom <= clip.top || text.top >= clip.bottom || text.right <= clip.left || text.left >= clip.right) return;
        const stage = caption.translationState === 'complete' ? 'complete' : 'preview';
        const key = `${caption.diagnosticId}:${stage}`;
        if (diagnosticReceipts.has(key)) return;
        diagnosticReceipts.add(key);
        if (diagnosticReceipts.size > 1000) diagnosticReceipts.delete(diagnosticReceipts.values().next().value);
        // Only selected, fitted, visible translated rows receive DOM-handled acknowledgments.
        void rpc('diagnostics.render', { traceId: caption.diagnosticId, stage }).catch(() => {});
    }
    function render() {
        const container = $('overlay-captions');
        const rows = [...feed.rows], last = rows.at(-1)?.[1];
        const selected = rows.filter(([, caption]) => captionPresentation(caption).readable).slice(-2);
        const selectedKeys = new Set(selected.map(([key]) => key));
        for (const [key, node] of nodes) if (!selectedKeys.has(key)) { node.remove(); nodes.delete(key); }
        const pending = last && !captionPresentation(last).readable && !captionPresentation(last).failed;
        $('overlay-status').textContent = notice || (paused ? 'Paused' : last && captionPresentation(last).failed ? 'Translation unavailable · see Live feed' : pending ? 'Translating…' : active ? 'Listening' : 'Waiting for captions');
        $('overlay-dot').classList.toggle('active', active && !paused);
        $('overlay-draft').hidden = !selected.some(([, caption]) => captionPresentation(caption).draft);
        let idle = $('overlay-idle');
        if (!idle) { idle = document.createElement('p'); idle.id = 'overlay-idle'; container.append(idle); }
        idle.hidden = selected.length > 0;
        idle.textContent = pending ? 'Waiting for translation…' : active ? 'Your translations will appear here.' : 'Start captions from your Discord voice channel.';
        for (const [key, caption] of selected) {
            let item = nodes.get(key);
            if (!item) {
                item = document.createElement('div'); item.className = 'caption';
                const text = document.createElement('div'); text.className = 'translated'; item.append(text); nodes.set(key, item);
            }
            item.hidden = false; item.classList.toggle('provisional', captionPresentation(caption).draft);
            const text = item.querySelector('.translated'); text.textContent = captionPresentation(caption).primary;
            text.style.webkitLineClamp = ''; text.style.maxHeight = ''; item.removeAttribute('data-truncated'); item.removeAttribute('title');
            container.append(item);
        }
        // The header has its own fixed flex area; text is measured only inside the remaining space.
        const available = container.clientHeight;
        if (selected.length && available <= 0) {
            for (const [key] of selected) nodes.get(key).hidden = true;
            idle.hidden = false; idle.textContent = 'Enlarge overlay to read captions.';
        } else if (selected.length) {
            const gap = parseFloat(getComputedStyle(container).gap) || 0;
            const chosenNodes = selected.map(([key]) => nodes.get(key));
            if (chosenNodes.length === 2 && chosenNodes.reduce((height, node) => height + node.getBoundingClientRect().height, gap) > available) chosenNodes[0].hidden = true;
            const newest = chosenNodes.at(-1), text = newest.querySelector('.translated');
            const lineHeight = parseFloat(getComputedStyle(text).lineHeight);
            const lines = Math.floor(available / lineHeight);
            if (!Number.isFinite(lines) || lines < 1) {
                for (const item of chosenNodes) item.hidden = true;
                idle.hidden = false; idle.textContent = 'Enlarge overlay to read captions.';
            } else if (newest.getBoundingClientRect().height > available) {
                text.style.webkitLineClamp = String(lines); text.style.maxHeight = `${lines * lineHeight}px`;
                newest.dataset.truncated = 'true'; newest.title = 'Full translation in Live feed.';
            }
        }
        $('overlay-draft').hidden = !selected.some(([key, caption]) => !nodes.get(key).hidden && captionPresentation(caption).draft);
        for (const [key, caption] of selected) if (!nodes.get(key).hidden) acknowledge(caption, nodes.get(key));
    }
    async function refresh() {
        if (refreshing) { refreshQueued = true; return; } refreshing = true;
        const version = eventVersion, requestedStatus = statusVersion;
        try {
            const status = await rpc('status'); if (requestedStatus !== statusVersion) return;
            if (notice === 'Companion disconnected') notice = '';
            const voice = status.voice || {};
            active = Boolean(voice.active); paused = Boolean(voice.paused);
            if (version === eventVersion) {
                if (active && voice.sessionId) feed.activate(voice.sessionId);
                else if (!active) feed.clear();
            }
            if (status.settings) applySettings(status.settings);
            render();
        } catch {
            notice = 'Companion disconnected'; active = false; feed.clear(); render();
        } finally { refreshing = false; if (refreshQueued) { refreshQueued = false; void refresh(); } }
    }
    if (!window.comms) { $('overlay-status').textContent = 'Open through the companion'; return; }
    window.comms.subscribe(event => {
        if (!event || typeof event !== 'object') return;
        if (event.type === 'settings') { applySettings(event.settings); return; }
        if (event.type === 'status') { statusVersion++; refresh(); return; }
        if (event.type === 'error') { notice = 'Caption error · see Live feed'; render(); return; }
        if (event.type === 'skipped') { notice = 'Some speech skipped · see Live feed'; render(); return; }
        if (feed.accept(event)) { eventVersion++; active = true; notice = ''; render(); }
    });
    window.addEventListener('resize', render);
    document.addEventListener('visibilitychange', render);
    if (typeof ResizeObserver === 'function') new ResizeObserver(render).observe($('overlay-captions'));
    refresh(); setInterval(refresh, 5000);
})();
