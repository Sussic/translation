"""Conservative per-phrase language selection; scores are not calibrated odds."""
from __future__ import annotations

import math
from typing import Any, Iterable


def select_language(
    probabilities: Iterable[tuple[str, float]],
    supported: Iterable[str],
    duration_seconds: float,
    expected_languages: tuple[str, ...] = (),
    previous_language: str | None = None,
) -> tuple[str, dict[str, Any]]:
    """Prefer the global winner; hints may only resolve a genuinely close race.

    Confidence describes the selected language token score, not transcription
    correctness. Duration is the captured speech segment, including its short
    pre-roll/tail. It does not assert that a whole sentence uses one language.
    """
    supported_set = set(supported)
    scores: dict[str, float] = {}
    for language, score in probabilities:
        if language not in supported_set or isinstance(score, bool):
            continue
        try:
            score = float(score)
        except (ValueError, TypeError):
            continue
        if not math.isfinite(score) or not 0 <= score <= 1:
            continue
        scores[language] = max(scores.get(language, 0.0), score)
    if not scores:
        raise ValueError("Language detection did not return a supported language.")
    ranked = sorted(scores.items(), key=lambda item: (-item[1], item[0]))
    best, best_score = ranked[0]
    margin = best_score - (ranked[1][1] if len(ranked) > 1 else 0.0)
    clear = best_score >= 0.85 and margin >= 0.2
    selected = best
    expected = set(expected_languages) & supported_set
    # A hint cannot overrule a strong detection, even for a very short phrase.
    # It must also have meaningful model support and lie close to the winner.
    if not clear:
        nearby = {language for language, score in ranked if score >= 0.2 and best_score - score <= 0.15}
        if previous_language in nearby and (not expected or previous_language in expected):
            selected = previous_language
        elif expected and best not in expected:
            selected = next((language for language, _ in ranked if language in expected & nearby), best)
    reason = None
    if selected != best:
        reason = "hint"
    elif expected and selected not in expected:
        reason = "unexpected"
    elif duration_seconds < 1.0:
        reason = "short"
    elif not clear:
        reason = "low_confidence"
    detection: dict[str, Any] = {"confidence": scores[selected], "uncertain": reason is not None}
    if reason is not None:
        detection["reason"] = reason
    return selected, detection
