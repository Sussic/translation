"""Local inference adapters. Runtime loading does not download models."""
from __future__ import annotations

import contextlib
from dataclasses import dataclass
import json
import os
from pathlib import Path
import re
import sys
from typing import Any
from language_detection import select_language
from model_files import verify_model_manifest

# Do not inherit an unrelated Argos config selecting a cloud provider. Keep CPU
# usage bounded for multiboxing; GPU ASR remains an explicit profile choice.
os.environ["ARGOS_MODEL_PROVIDER"] = "OPENNMT"
os.environ["ARGOS_DEVICE_TYPE"] = "cpu"
os.environ["ARGOS_INTRA_THREADS"] = "2"
os.environ["ARGOS_INTER_THREADS"] = "1"
os.environ["HF_HUB_OFFLINE"] = "1"
os.environ["TRANSFORMERS_OFFLINE"] = "1"
os.environ["HF_HUB_DISABLE_TELEMETRY"] = "1"


class WorkerError(Exception):
    def __init__(self, code: str, message: str) -> None:
        super().__init__(message)
        self.code = code


class FasterWhisperBackend:
    def __init__(self, model_path: str, profile: str = "cpu-int8", cpu_threads: int = 2) -> None:
        path = Path(model_path).resolve()
        if not path.is_dir() or not (path / "model.bin").is_file():
            raise WorkerError("MODEL_MISSING", "Select a downloaded faster-whisper model folder containing model.bin.")
        try:
            verify_model_manifest(path, required_files=("model.bin", "config.json"))
        except (ValueError, OSError) as exc:
            raise WorkerError("MODEL_INTEGRITY_FAILED", str(exc)) from exc
        if profile not in {"cpu-int8", "cuda-int8-float16"}:
            raise WorkerError("INVALID_PROFILE", "ASR profile must be cpu-int8 or cuda-int8-float16.")
        if not 1 <= cpu_threads <= 4:
            raise WorkerError("INVALID_THREADS", "CPU threads must be between 1 and 4.")
        try:
            # Dependencies occasionally print initialization messages. stdout is
            # exclusively the worker protocol; stderr contains diagnostics only.
            with contextlib.redirect_stdout(sys.stderr):
                if profile == "cuda-int8-float16":
                    from cuda_runtime import configure_cuda_runtime
                    configure_cuda_runtime()
                from faster_whisper import WhisperModel
                self.model = WhisperModel(
                    str(path),
                    device="cpu" if profile == "cpu-int8" else "cuda",
                    compute_type="int8" if profile == "cpu-int8" else "int8_float16",
                    cpu_threads=cpu_threads,
                    num_workers=1,
                    local_files_only=True,
                )
        except ImportError as exc:
            raise WorkerError("DEPENDENCY_MISSING", "Install workers/local/requirements.txt in the worker virtual environment.") from exc
        except Exception as exc:
            raise WorkerError("MODEL_LOAD_FAILED", "ASR model could not be loaded; verify the selected folder and optional CUDA dependencies.") from exc
        self.languages = sorted(self.model.supported_languages)
        self.profile = profile

    def transcribe(self, pcm: bytes, source_language: str) -> tuple[str, bool]:
        if source_language not in self.languages:
            raise WorkerError("LANGUAGE_UNSUPPORTED", "The selected ASR model does not support that source language.")
        import numpy as np
        audio = np.frombuffer(pcm, dtype="<i2").astype(np.float32) / 32768.0
        return self._decode(audio, source_language)

    def transcribe_auto(
        self, pcm: bytes, expected_languages: tuple[str, ...] = (), previous_language: str | None = None,
    ) -> tuple[str, bool, str, dict[str, Any]]:
        if len(self.languages) < 2:
            raise WorkerError("AUTO_LANGUAGE_UNSUPPORTED", "Automatic language detection requires a multilingual speech model.")
        import numpy as np
        audio = np.frombuffer(pcm, dtype="<i2").astype(np.float32) / 32768.0
        # The outer segmenter already selected speech. Detect every phrase,
        # rather than locking the channel to the first speaker's language.
        with contextlib.redirect_stdout(sys.stderr):
            _, _, probabilities = self.model.detect_language(
                audio=audio, vad_filter=False, language_detection_segments=1,
            )
        try:
            source_language, detection = select_language(
                probabilities, self.languages, len(audio) / 16000.0,
                expected_languages, previous_language,
            )
        except ValueError as exc:
            raise WorkerError("LANGUAGE_DETECTION_FAILED", "The speech model did not return a usable language detection.") from exc
        text, uncertain = self._decode(audio, source_language)
        return text, uncertain or detection["uncertain"], source_language, detection

    def _decode(self, audio: Any, source_language: str) -> tuple[str, bool]:
        with contextlib.redirect_stdout(sys.stderr):
            segments, _ = self.model.transcribe(
                audio,
                language=source_language,
                task="transcribe",
                beam_size=1,
                vad_filter=True,
                vad_parameters={"min_silence_duration_ms": 300},
                condition_on_previous_text=False,
                temperature=0.0,
                no_speech_threshold=0.6,
                hallucination_silence_threshold=1.0,
            )
            result = list(segments)
        text = " ".join(segment.text.strip() for segment in result).strip()
        # These model scores are uncertainty signals, not calibrated probabilities.
        uncertain = any(segment.avg_logprob < -1.0 or segment.no_speech_prob > 0.5 for segment in result)
        return text, uncertain


def split_local_text(text: str, limit: int = 350) -> list[str]:
    """Small deterministic chunks avoid runtime SBD model downloads/truncation.

    Preserve paragraph boundaries. Long sentences split at spaces or script
    punctuation where possible, then at the size limit. This is a quality tradeoff
    documented by the local provider; context-aware translation uses ChatGPT.
    """
    chunks: list[str] = []
    for paragraph in text.split("\n"):
        if not paragraph:
            chunks.append("\n")
            continue
        # These direct models are sentence models: feeding several sentences can
        # omit earlier clauses entirely. Keep simple deterministic sentence
        # boundaries without downloading a sentence-boundary detector.
        for sentence in re.split(r"(?<=[。！？])|(?<=[.!?])(?=\s+|$)", paragraph):
            remaining = sentence
            while len(remaining) > limit:
                candidates = [match.end() for match in re.finditer(r"[。！？.!?\s]", remaining[:limit])]
                split = max(candidates) if candidates and max(candidates) >= limit // 2 else limit
                chunks.append(remaining[:split])
                remaining = remaining[split:]
            if remaining:
                chunks.append(remaining)
        chunks.append("\n")
    if chunks and chunks[-1] == "\n":
        chunks.pop()
    return chunks


class SentencePieceAdapter:
    def __init__(self, path: Path) -> None:
        import sentencepiece
        self.processor = sentencepiece.SentencePieceProcessor(model_file=str(path))

    def encode(self, text: str) -> list[str]:
        return self.processor.encode(text, out_type=str)

    def decode(self, tokens: list[str]) -> str:
        # Do not apply Argos' underscore-to-space postprocessing: it damages the
        # companion's formatting placeholders before the model can be assessed.
        return self.processor.decode_pieces(tokens)


@dataclass
class LocalPackage:
    package_path: Path
    from_code: str
    to_code: str
    package_version: str
    target_prefix: str = ""
    type: str = "translate"
    _tokenizer: Any = None

    @property
    def tokenizer(self) -> SentencePieceAdapter:
        if self._tokenizer is None:
            self._tokenizer = SentencePieceAdapter(self.package_path / "sentencepiece.model")
        return self._tokenizer


class InstalledPackages:
    def __init__(self, root: Path) -> None:
        self.root = root

    def get_installed_packages(self) -> list[LocalPackage]:
        if not self.root.is_dir():
            return []
        result = []
        for path in sorted(self.root.iterdir()):
            metadata_path = path / "metadata.json"
            if path.name.startswith(".") or path.name.endswith(".previous"):
                continue
            if not path.is_dir() or path.is_symlink() or not metadata_path.is_file() or metadata_path.is_symlink():
                continue
            if metadata_path.stat().st_size > 64 * 1024:
                continue
            try:
                metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
            except (ValueError, OSError):
                continue
            if not isinstance(metadata, dict) or not (path / "model-manifest.json").is_file():
                continue
            # First version supports the format proven by Japanese/English
            # models. BPE/multilingual formats are explicitly not advertised.
            if not (path / "sentencepiece.model").is_file() or not (path / "model" / "model.bin").is_file():
                continue
            if metadata.get("type", "translate") != "translate":
                continue
            source, target = metadata.get("from_code"), metadata.get("to_code")
            if not isinstance(source, str) or not isinstance(target, str) or not re.fullmatch(r"[a-z]{2,3}", source) or not re.fullmatch(r"[a-z]{2,3}", target):
                continue
            prefix = metadata.get("target_prefix", "")
            if not isinstance(prefix, str):
                continue
            result.append(LocalPackage(path, source, target, str(metadata.get("package_version", "")), prefix))
        return result


class ArgosBackend:
    """Direct official Argos-format packages, without the heavy Argos library.

    Avoid get_translation_from_codes(), which can silently pivot languages, and
    Argos' generic sentence splitter, which can download extra models at runtime.
    Neither speech/text nor a cloud key is sent anywhere by this adapter.
    """

    def __init__(self, packages_dir: str | None = None) -> None:
        default_root = Path(os.environ.get("LOCALAPPDATA", Path.home() / ".local" / "share")) / "CommsTranslate" / "models" / "argos"
        root = Path(packages_dir).resolve() if packages_dir else default_root
        try:
            with contextlib.redirect_stdout(sys.stderr):
                import ctranslate2
                import sentencepiece
        except ImportError as exc:
            raise WorkerError("DEPENDENCY_MISSING", "Install the local worker dependencies before using offline text translation.") from exc
        self.package = InstalledPackages(root)
        self.ctranslate2 = ctranslate2
        self._models: dict[tuple[str, str], tuple[Any, Any]] = {}

    def pairs(self) -> list[dict[str, str]]:
        with contextlib.redirect_stdout(sys.stderr):
            packages = self.package.get_installed_packages()
        return sorted(
            [
                {"sourceLanguage": pkg.from_code, "targetLanguage": pkg.to_code, "packageVersion": str(pkg.package_version)}
                for pkg in packages
                if getattr(pkg, "type", "translate") == "translate"
                and (pkg.package_path / "model" / "model.bin").is_file()
            ],
            key=lambda item: (item["sourceLanguage"], item["targetLanguage"]),
        )

    def translate(self, text: str, source_language: str, target_language: str) -> str:
        if source_language == target_language:
            return text
        pair = (source_language, target_language)
        if pair not in self._models:
            with contextlib.redirect_stdout(sys.stderr):
                packages = self.package.get_installed_packages()
            package = next(
                (
                    pkg for pkg in packages
                    if pkg.from_code == source_language and pkg.to_code == target_language
                    and getattr(pkg, "type", "translate") == "translate"
                ),
                None,
            )
            if package is None:
                raise WorkerError("PAIR_NOT_INSTALLED", "No direct offline model is installed for this language pair. Install it explicitly or select another provider.")
            try:
                verify_model_manifest(package.package_path, required_files=("model/model.bin", "sentencepiece.model", "metadata.json"))
            except (ValueError, OSError) as exc:
                raise WorkerError("MODEL_INTEGRITY_FAILED", str(exc)) from exc
            if len(self._models) >= 2:
                # Bound resident models when changing language pairs repeatedly.
                self._models.clear()
            with contextlib.redirect_stdout(sys.stderr):
                model = self.ctranslate2.Translator(
                    str(package.package_path / "model"), device="cpu", compute_type="int8",
                    inter_threads=1, intra_threads=2,
                )
            self._models[pair] = (package, model)
        package, model = self._models[pair]
        output: list[str] = []
        for chunk in split_local_text(text):
            if chunk == "\n" or not chunk.strip():
                output.append(chunk)
                continue
            tokens = package.tokenizer.encode(chunk)
            prefix = getattr(package, "target_prefix", "")
            with contextlib.redirect_stdout(sys.stderr):
                results = model.translate_batch(
                    [tokens], target_prefix=[[prefix]] if prefix else None,
                    replace_unknowns=True, beam_size=2, length_penalty=0.2,
                    max_input_length=0, max_decoding_length=1024,
                )
            if len(results[0].hypotheses[0]) >= 1024:
                raise WorkerError("MT_OUTPUT_TOO_LONG", "Local translation reached its output limit; no truncated result was returned.")
            result = package.tokenizer.decode(results[0].hypotheses[0])
            if prefix and result.startswith(prefix):
                result = result[len(prefix):]
            # Separation between split sentences is needed for English. Preserve
            # original line breaks while avoiding concatenated words.
            if output and output[-1] != "\n" and output[-1] and not output[-1][-1].isspace():
                output.append(" ")
            output.append(result.strip())
        return "".join(output)
