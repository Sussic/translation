#!/usr/bin/env python3
"""Private stdio worker for local ASR and offline translation.

The companion owns this child process. It is not an HTTP service and exposes no
ports. Only NDJSON protocol messages are written to stdout; no audio is saved.
"""
from __future__ import annotations

import base64
import binascii
from collections import deque
import contextlib
from dataclasses import dataclass, replace
import json
import os
import queue
import re
import sys
import threading
import time
from typing import Any, Callable

from audio import FRAME_MS, MAX_PACKET_BYTES, SAMPLE_RATE, SEGMENTATION_PROFILES, Segmenter, Utterance
from backends import ArgosBackend, FasterWhisperBackend, WorkerError

MAX_LINE_BYTES = 64 * 1024
MAX_TEXT_CHARS = 8000
MAX_JOB_AGE_SECONDS = 12.0
LANGUAGE_HINT_AGE_SECONDS = 30.0


class Emitter:
    def __init__(self, stream: Any = None) -> None:
        self.stream = stream if stream is not None else sys.stdout
        self.lock = threading.Lock()

    def __call__(self, message: dict[str, Any]) -> None:
        with self.lock:
            self.stream.write(json.dumps(message, ensure_ascii=False, separators=(",", ":")) + "\n")
            self.stream.flush()


@dataclass(frozen=True)
class RecognitionJob:
    generation: int
    session_id: str
    source_language: str
    utterance: Utterance
    enqueued_at: float
    speech_language_mode: str = "fixed"
    expected_languages: tuple[str, ...] = ()
    previous_language: str | None = None


class FreshQueue:
    """At most two waiting utterances; partial updates cannot evict a final.

    A new final replaces its queued partial. When overloaded, discard the oldest
    waiting work and surface an overload event rather than grow a stale backlog.
    """

    def __init__(self, size: int = 2) -> None:
        self.size = size
        self.items: deque[RecognitionJob] = deque()
        self.condition = threading.Condition()
        self.closed = False

    def put(self, job: RecognitionJob) -> int:
        with self.condition:
            if self.closed:
                return 1
            same = lambda old: old.session_id == job.session_id and old.utterance.utterance_id == job.utterance.utterance_id
            matching = [old for old in self.items if same(old)]
            if not job.utterance.final and any(old.utterance.final for old in matching):
                return 1
            self.items = deque(old for old in self.items if not same(old))
            dropped = 0
            if len(self.items) >= self.size:
                if not job.utterance.final:
                    return 1
                self.items.popleft()
                dropped = 1
            self.items.append(job)
            self.condition.notify()
            return dropped

    def get(self) -> RecognitionJob | None:
        with self.condition:
            self.condition.wait_for(lambda: self.items or self.closed)
            return self.items.popleft() if self.items else None

    def clear(self) -> None:
        with self.condition:
            self.items.clear()

    def close(self) -> None:
        with self.condition:
            self.closed = True
            self.items.clear()
            self.condition.notify_all()


def bounded_string(value: Any, field: str, maximum: int, *, nonempty: bool = True) -> str:
    if not isinstance(value, str) or len(value) > maximum or (nonempty and not value):
        raise WorkerError("INVALID_REQUEST", f"{field} must be a string of {'1' if nonempty else '0'}..{maximum} characters.")
    return value


class Worker:
    def __init__(
        self,
        emit: Callable[[dict[str, Any]], None],
        *,
        asr_factory: Callable[..., Any] = FasterWhisperBackend,
        mt_factory: Callable[..., Any] = ArgosBackend,
        vad_factory: Callable[..., Any] | None = None,
    ) -> None:
        self.emit = emit
        self.asr_factory = asr_factory
        self.mt_factory = mt_factory
        self.vad_factory = vad_factory
        self.asr: Any = None
        self.mt: Any = None
        self.session_id: str | None = None
        self.source_language: str | None = None
        self.speech_language_mode = "fixed"
        self.expected_languages: tuple[str, ...] = ()
        self._previous_language: str | None = None
        self._previous_language_at = 0.0
        self.segmenter: Segmenter | None = None
        self.generation = 0
        self.lock = threading.RLock()
        self.recognition_queue = FreshQueue()
        self.translation_queue: queue.Queue[dict[str, Any] | None] = queue.Queue(maxsize=4)
        self.closed = False
        self.translation_pending = 0
        self._last_audio_at = 0.0
        self._shutdown = threading.Event()
        self._finalized: set[tuple[int, int]] = set()
        self._asr_thread = threading.Thread(target=self._recognize_loop, daemon=True, name="local-asr")
        self._mt_thread = threading.Thread(target=self._translate_loop, daemon=True, name="local-mt")
        self._asr_thread.start()
        self._mt_thread.start()
        self._endpoint_thread = threading.Thread(target=self._endpoint_loop, daemon=True, name="local-endpoint")
        self._endpoint_thread.start()

    def reply(self, request_id: Any, result: Any = None, error: WorkerError | None = None) -> None:
        message: dict[str, Any] = {"id": request_id, "ok": error is None}
        if error:
            message["error"] = {"code": error.code, "message": str(error)}
        else:
            message["result"] = result
        self.emit(message)

    def capabilities(self) -> dict[str, Any]:
        return {
            "protocolVersion": 1,
            "asrReady": self.asr is not None,
            "asrLanguages": self.asr.languages if self.asr else [],
            "asrProfile": self.asr.profile if self.asr else None,
            "localPairs": self.mt.pairs() if self.mt else [],
            "captureFormat": {"sampleRate": SAMPLE_RATE, "channels": 1, "encoding": "pcm16le"},
            "sessionId": self.session_id,
            "runtimeDownloads": False,
        }

    def handle(self, request: Any) -> None:
        request_id = request.get("id") if isinstance(request, dict) else None
        try:
            if not isinstance(request, dict):
                raise WorkerError("INVALID_REQUEST", "Request must be a JSON object.")
            request_type = request.get("type")
            if request_type != "audio":
                bounded_string(request_id, "id", 128)
            if self.closed:
                raise WorkerError("WORKER_CLOSED", "Worker has been closed.")
            if request_type == "init":
                with self.lock:
                    if self.session_id:
                        raise WorkerError("SESSION_ACTIVE", "Stop voice capture before changing models.")
                    if self.translation_pending:
                        raise WorkerError("BUSY", "Wait for pending translations before changing models.")
                    model_path = request.get("modelPath")
                    asr = None
                    if model_path:
                        bounded_string(model_path, "modelPath", 4096)
                        profile = request.get("asrProfile", "cpu-int8")
                        threads = request.get("cpuThreads", 2)
                        if isinstance(threads, bool) or not isinstance(threads, int):
                            raise WorkerError("INVALID_THREADS", "cpuThreads must be an integer.")
                        asr = self.asr_factory(model_path, profile, threads)
                    packages_dir = request.get("packagesDir")
                    if packages_dir is not None:
                        bounded_string(packages_dir, "packagesDir", 4096)
                    self.mt = self.mt_factory(packages_dir)
                    self.asr = asr
                    self.reply(request_id, self.capabilities())
            elif request_type == "status":
                with self.lock:
                    self.reply(request_id, self.capabilities())
            elif request_type == "start":
                with self.lock:
                    if self.session_id:
                        raise WorkerError("SESSION_ACTIVE", "A voice session is already active.")
                    if not self.asr:
                        raise WorkerError("ASR_NOT_READY", "Initialize a downloaded ASR model before starting voice capture.")
                    session_id = bounded_string(request.get("sessionId"), "sessionId", 128)
                    source_language = bounded_string(request.get("sourceLanguage"), "sourceLanguage", 16)
                    speech_language_mode = request.get("speechLanguageMode", "fixed")
                    if speech_language_mode not in ("fixed", "auto"):
                        raise WorkerError("INVALID_REQUEST", "speechLanguageMode must be fixed or auto.")
                    expected_languages = request.get("expectedLanguages", [])
                    if (
                        not isinstance(expected_languages, list) or len(expected_languages) > 8
                        or any(not isinstance(language, str) or not re.fullmatch(r"[a-z]{2,3}", language) for language in expected_languages)
                        or len(set(expected_languages)) != len(expected_languages)
                    ):
                        raise WorkerError("INVALID_REQUEST", "expectedLanguages must contain at most 8 unique language codes.")
                    if speech_language_mode == "auto" and any(language not in self.asr.languages for language in expected_languages):
                        raise WorkerError("INVALID_REQUEST", "In automatic mode, expected languages must be supported by the speech model.")
                    if speech_language_mode == "fixed" and source_language not in self.asr.languages:
                        raise WorkerError("LANGUAGE_UNSUPPORTED", "The selected ASR model does not support that source language.")
                    if speech_language_mode == "auto" and len(self.asr.languages) < 2:
                        raise WorkerError("AUTO_LANGUAGE_UNSUPPORTED", "Automatic language detection requires a multilingual speech model.")
                    if self.vad_factory:
                        vad = self.vad_factory()
                    else:
                        with contextlib.redirect_stdout(sys.stderr):
                            import webrtcvad
                            vad = webrtcvad.Vad(2)
                    latency_mode = request.get("latencyMode", "live")
                    if not isinstance(latency_mode, str) or latency_mode not in SEGMENTATION_PROFILES:
                        raise WorkerError("INVALID_LATENCY_MODE", "Caption pace must be live or balanced.")
                    self.segmenter = Segmenter(vad.is_speech, **SEGMENTATION_PROFILES[latency_mode])
                    self.session_id = session_id
                    self.source_language = source_language
                    self.speech_language_mode = speech_language_mode
                    self.expected_languages = tuple(expected_languages)
                    self._previous_language = None
                    self._previous_language_at = 0.0
                    self.generation += 1
                    self._last_audio_at = time.monotonic()
                    self._finalized.clear()
                    self.reply(request_id, {"sessionId": session_id, "state": "listening"})
            elif request_type == "audio":
                self._audio(request)
            elif request_type == "stop":
                with self.lock:
                    self.generation += 1
                    self.session_id = self.source_language = None
                    self._previous_language = None
                    self._previous_language_at = 0.0
                    self.segmenter = None
                    self.recognition_queue.clear()
                    self._finalized.clear()
                    self.reply(request_id, {"state": "stopped"})
            elif request_type == "gap":
                with self.lock:
                    if request.get("sessionId") != self.session_id or not self.session_id:
                        raise WorkerError("SESSION_MISMATCH", "Audio gap belongs to a different or stopped session.")
                    self.generation += 1
                    self.recognition_queue.clear()
                    self._finalized.clear()
                    self._previous_language = None
                    self._previous_language_at = 0.0
                    if self.segmenter:
                        self.segmenter.reset_stream()
                    self.reply(request_id, {"sessionId": self.session_id, "state": "listening", "discardedUnfinishedSpeech": True})
            elif request_type == "translate":
                text = bounded_string(request.get("text"), "text", MAX_TEXT_CHARS)
                source = bounded_string(request.get("sourceLanguage"), "sourceLanguage", 16)
                target = bounded_string(request.get("targetLanguage"), "targetLanguage", 16)
                if not self.mt:
                    raise WorkerError("MT_NOT_READY", "Initialize the worker before requesting offline translation.")
                with self.lock:
                    try:
                        self.translation_queue.put_nowait({"id": request_id, "text": text, "source": source, "target": target})
                        self.translation_pending += 1
                    except queue.Full as exc:
                        raise WorkerError("BUSY", "The offline translation queue is full; retry after the current request finishes.") from exc
            else:
                raise WorkerError("UNKNOWN_COMMAND", "Unknown local worker command.")
        except WorkerError as error:
            self.reply(request_id, error=error)
        except (ValueError, binascii.Error) as error:
            self.reply(request_id, error=WorkerError("INVALID_REQUEST", str(error)))
        except ImportError:
            self.reply(request_id, error=WorkerError("DEPENDENCY_MISSING", "Install the local worker dependencies."))
        except Exception:
            # No request content, transcript, credentials, or stack dumps in logs.
            self.reply(request_id, error=WorkerError("WORKER_ERROR", "The local worker could not complete this command."))

    def _audio(self, request: dict[str, Any]) -> None:
        with self.lock:
            if not self.session_id or not self.segmenter:
                return  # late capture frames after stop are discarded
            if request.get("sessionId") != self.session_id:
                return
            if request.get("sampleRate") != SAMPLE_RATE or request.get("channels") != 1:
                raise WorkerError("INVALID_FORMAT", "Only 16000 Hz mono PCM16LE audio is accepted.")
            encoded = request.get("pcm16")
            if not isinstance(encoded, str) or len(encoded) > ((MAX_PACKET_BYTES + 2) // 3) * 4:
                raise WorkerError("INVALID_AUDIO", "Audio packet is too large or malformed.")
            pcm = base64.b64decode(encoded, validate=True)
            self._last_audio_at = time.monotonic()
            before = self.segmenter.discontinuities
            utterances = self.segmenter.push(pcm, request.get("sequence"))
            if self.segmenter.discontinuities != before:
                self.generation += 1
                self.recognition_queue.clear()
                self._finalized.clear()
                self._previous_language = None
                self._previous_language_at = 0.0
                self.emit({"type": "audioGap", "sessionId": self.session_id, "message": "Missing audio discarded; current utterance reset."})
            for utterance in utterances:
                self._enqueue_utterance(utterance)

    def _enqueue_utterance(self, utterance: Utterance) -> None:
        now = time.monotonic()
        previous_language = self._previous_language if now - self._previous_language_at <= LANGUAGE_HINT_AGE_SECONDS else None
        dropped = self.recognition_queue.put(RecognitionJob(
            self.generation, self.session_id or "", self.source_language or "ja", utterance, now,
            self.speech_language_mode, self.expected_languages, previous_language,
        ))
        if dropped:
            self.emit({"type": "overload", "sessionId": self.session_id, "dropped": dropped})

    def _finish_idle(self, now: float) -> None:
        with self.lock:
            if self.session_id and self.segmenter and now - self._last_audio_at >= self.segmenter.silence_frames * FRAME_MS / 1000:
                utterance = self.segmenter.finish_idle()
                if utterance:
                    self._enqueue_utterance(replace(utterance, endpoint_wait_ms=round((now - self._last_audio_at) * 1000)))

    def _endpoint_loop(self) -> None:
        # Process loopback may cease delivering buffers when a process has no
        # active rendering stream. Wall-clock silence still must finalize speech.
        while not self._shutdown.wait(0.05):
            self._finish_idle(time.monotonic())

    def _recognize_loop(self) -> None:
        while True:
            job = self.recognition_queue.get()
            if job is None:
                return
            with self.lock:
                if job.generation != self.generation or job.session_id != self.session_id:
                    continue
                asr = self.asr
                if not job.utterance.final and (job.generation, job.utterance.utterance_id) in self._finalized:
                    continue
            if time.monotonic() - job.enqueued_at > MAX_JOB_AGE_SECONDS:
                self.emit({"type": "overload", "sessionId": job.session_id, "dropped": 1})
                continue
            started = time.monotonic()
            try:
                source_language = job.source_language
                detection = None
                if job.speech_language_mode == "auto":
                    text, uncertain, source_language, detection = asr.transcribe_auto(
                        job.utterance.pcm, job.expected_languages, job.previous_language,
                    )
                else:
                    text, uncertain = asr.transcribe(job.utterance.pcm, source_language)
                with self.lock:
                    if job.generation != self.generation or job.session_id != self.session_id:
                        continue
                    if time.monotonic() - job.enqueued_at > MAX_JOB_AGE_SECONDS:
                        self.emit({"type": "overload", "sessionId": job.session_id, "dropped": 1})
                        continue
                    if not text:
                        continue
                    if len(text) > MAX_TEXT_CHARS:
                        self.emit({"type": "error", "sessionId": job.session_id, "error": {
                            "code": "TRANSCRIPT_TOO_LONG", "message": "Local transcription exceeded the caption limit; the utterance was discarded rather than truncated.",
                        }})
                        continue
                    if job.utterance.final:
                        self._finalized.add((job.generation, job.utterance.utterance_id))
                        if len(self._finalized) > 64:
                            self._finalized = set(sorted(self._finalized)[-32:])
                        if detection is not None and not detection["uncertain"] and not uncertain:
                            self._previous_language = source_language
                            self._previous_language_at = time.monotonic()
                    self.emit({
                        "type": "transcriptFinal" if job.utterance.final else "transcriptPartial",
                        "sessionId": job.session_id,
                        "utteranceId": str(job.utterance.utterance_id),
                        "sourceLanguage": source_language,
                        **({"languageDetection": detection} if detection is not None else {}),
                        "text": text,
                        "startMs": job.utterance.start_ms,
                        "endMs": job.utterance.end_ms,
                        "uncertain": uncertain,
                        "forcedSplit": job.utterance.forced_split,
                        "inferenceMs": round((time.monotonic() - started) * 1000),
                        "timing": {
                            "recognitionMs": round((time.monotonic() - started) * 1000),
                            "recognitionQueueMs": round((started - job.enqueued_at) * 1000),
                            "speechMs": job.utterance.end_ms - job.utterance.start_ms,
                            "endpointWaitMs": job.utterance.endpoint_wait_ms,
                        },
                    })
            except Exception as error:
                with self.lock:
                    if job.generation != self.generation:
                        continue
                    # Only app-authored codes get specific advice. Never echo a
                    # model/dependency exception, path, or recognizer input.
                    safe_errors = {
                        "LANGUAGE_DETECTION_FAILED": "The speech model did not return a usable language detection. Try selecting the spoken language manually.",
                        "AUTO_LANGUAGE_UNSUPPORTED": "Automatic language detection requires a multilingual speech model. Select one or use a fixed language.",
                    }
                    code = error.code if isinstance(error, WorkerError) and error.code in safe_errors else "ASR_FAILED"
                    self.emit({"type": "error", "sessionId": job.session_id, "error": {
                        "code": code, "message": safe_errors.get(code, "Local transcription failed; select a lighter model or verify the model installation."),
                    }})

    def _translate_loop(self) -> None:
        while True:
            request = self.translation_queue.get()
            if request is None:
                return
            started = time.monotonic()
            try:
                with self.lock:
                    mt = self.mt
                output = mt.translate(request["text"], request["source"], request["target"])
                if not self.closed:
                    self.reply(request["id"], {
                        "text": output, "sourceLanguage": request["source"], "targetLanguage": request["target"],
                        "provider": "local", "elapsedMs": round((time.monotonic() - started) * 1000),
                    })
            except WorkerError as error:
                if not self.closed:
                    self.reply(request["id"], error=error)
            except Exception:
                if not self.closed:
                    self.reply(request["id"], error=WorkerError("MT_FAILED", "The installed offline translation model could not translate this request."))
            finally:
                with self.lock:
                    self.translation_pending -= 1
                self.translation_queue.task_done()

    def close(self) -> None:
        with self.lock:
            self.closed = True
            self._shutdown.set()
            self.generation += 1
            self.session_id = self.source_language = None
            self._previous_language = None
            self._previous_language_at = 0.0
            self.segmenter = None
            self.recognition_queue.close()
        # Shutdown never waits for a large inference to finish; the companion can
        # terminate this isolated process after its normal graceful timeout.
        try:
            while True:
                self.translation_queue.get_nowait()
                self.translation_queue.task_done()
                with self.lock:
                    self.translation_pending -= 1
        except queue.Empty:
            pass
        self.translation_queue.put_nowait(None)


def main() -> int:
    # UTF-8 is mandatory even under older Windows console code pages.
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="strict", line_buffering=True)
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    emit = Emitter()
    worker = Worker(emit)
    emit({"type": "ready", "protocolVersion": 1})
    try:
        while True:
            line = sys.stdin.buffer.readline(MAX_LINE_BYTES + 1)
            if not line:
                break
            if len(line) > MAX_LINE_BYTES:
                emit({"id": None, "ok": False, "error": {"code": "MESSAGE_TOO_LARGE", "message": "Worker input exceeded 64 KiB; connection closed."}})
                return 2
            try:
                request = json.loads(line)
            except (json.JSONDecodeError, UnicodeDecodeError):
                emit({"id": None, "ok": False, "error": {"code": "INVALID_JSON", "message": "Malformed worker JSON."}})
                continue
            worker.handle(request)
    finally:
        worker.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
