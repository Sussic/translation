"""Locate CommsTranslate's optional, private Windows CUDA runtime.

Call configure_cuda_runtime() only for a CUDA speech profile, before importing
faster_whisper. No packages are imported, downloaded, installed, or changed.
"""
from __future__ import annotations

import json
import ntpath
import os
from pathlib import Path
import sys
import threading
from typing import Any, Callable, MutableMapping


_PACKAGES = ("cublas", "cudnn", "cuda_runtime", "cuda_nvrtc")
_REQUIRED = {
    "cublas": ("cublas64_12.dll", "cublasLt64_12.dll"),
    "cudnn": ("cudnn64_9.dll",),
    "cuda_runtime": ("cudart64_12.dll",),
    "cuda_nvrtc": ("nvrtc64_120_0.dll",),
}
_DLL_HANDLES: dict[str, Any] = {}
_LOCK = threading.Lock()


def _key(directory: str) -> str:
    # ntpath also gives deterministic Windows case/slash semantics in unit tests.
    return ntpath.normcase(ntpath.normpath(directory))


def _installed_directories(runtime_root: Path) -> tuple[Path, ...]:
    if not runtime_root.exists():
        return ()  # Existing system CUDA installations remain supported.
    marker = runtime_root / "runtime-manifest.json"
    try:
        if not marker.is_file() or marker.stat().st_size > 65536:
            raise ValueError("Missing or invalid installation marker")
        data = json.loads(marker.read_text(encoding="utf-8"))
        if not isinstance(data, dict) or data.get("revision") != "G2" or data.get("status") != "installed":
            raise ValueError("Invalid installation marker")
        for package, names in _REQUIRED.items():
            for name in names:
                choices = [runtime_root / "nvidia" / package / leaf / name for leaf in ("bin", "lib")]
                if not any(candidate.is_file() and candidate.stat().st_size > 0 for candidate in choices):
                    raise ValueError("Missing required library: " + name)
        return tuple(
            directory
            for package in _PACKAGES
            for leaf in ("bin", "lib")
            if (directory := runtime_root / "nvidia" / package / leaf).is_dir()
        )
    except (OSError, ValueError, UnicodeError) as error:
        raise RuntimeError(
            "CUDA_RUNTIME_INCOMPLETE: The private G2 CUDA runtime is incomplete or unreadable. "
            "Rerun the G2 repair. " + str(error)
        ) from error


def _configure(
    runtime_root: Path,
    environment: MutableMapping[str, str],
    add_directory: Callable[[str], Any],
) -> tuple[str, ...]:
    with _LOCK:
        directories = tuple(str(directory.resolve()) for directory in _installed_directories(runtime_root))
        if not directories:
            return ()
        added: dict[str, Any] = {}
        try:
            for directory in directories:
                key = _key(directory)
                if key not in _DLL_HANDLES and key not in added:
                    added[key] = add_directory(directory)
            keys = {_key(directory) for directory in directories}
            previous = environment.get("PATH", "")
            existing = previous.split(";") if previous else []
            # Registering DLL directories covers CPython extension loading.
            # Process PATH also covers native libraries' own LoadLibrary calls.
            environment["PATH"] = ";".join(
                [*directories, *(entry for entry in existing if _key(entry) not in keys)]
            )
            # CTranslate2's cuBLAS loader explicitly consults CUDA_PATH and
            # prepends its bin directory via SetDllDirectory. Override a stale
            # system CUDA_PATH only inside this worker process. For a lib-only
            # layout omit the hint and use the private DLL directories/PATH.
            cublas_root = runtime_root / "nvidia" / "cublas"
            if (cublas_root / "bin" / "cublas64_12.dll").is_file():
                environment["CUDA_PATH"] = str(cublas_root.resolve())
            else:
                environment.pop("CUDA_PATH", None)
        except Exception as error:
            for handle in added.values():
                handle.close()
            raise RuntimeError(
                "CUDA_RUNTIME_LOAD_FAILED: The private G2 CUDA directories could not be registered."
            ) from error
        # Keep registration handles alive for the entire worker process.
        _DLL_HANDLES.update(added)
        return directories


def configure_cuda_runtime() -> tuple[str, ...]:
    """Activate an installed G2 runtime for this process; otherwise do nothing."""
    if sys.platform != "win32":
        return ()
    local_app_data = os.environ.get("LOCALAPPDATA")
    if not local_app_data:
        return ()
    runtime_root = Path(local_app_data) / "CommsTranslate" / "cuda-runtime" / "G2"
    return _configure(runtime_root, os.environ, os.add_dll_directory)
