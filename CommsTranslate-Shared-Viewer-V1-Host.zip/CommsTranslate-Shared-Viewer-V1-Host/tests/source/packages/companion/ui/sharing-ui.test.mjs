import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import vm from 'node:vm';

const source=readFileSync(new URL('./sharing-ui.js',import.meta.url),'utf8');
const tick=()=>new Promise(resolve=>setImmediate(resolve));
function deferred(){let resolve;const promise=new Promise(done=>resolve=done);return {promise,resolve};}
function setup(invoke){
    class Element {
        textContent='';value='';hidden=false;disabled=false;children=[];listeners=new Map();attributes={};
        classList={toggle(){}};
        set innerHTML(_value){throw Error('HTML injection');}
        setAttribute(key,value){this.attributes[key]=value;}
        addEventListener(name,callback){this.listeners.set(name,callback);}
        append(...elements){for(const element of elements){element.parent=this;this.children.push(element);}}
        remove(){this.parent.children=this.parent.children.filter(element=>element!==this);}
        scrollIntoView(){}
        async fire(name){return this.listeners.get(name)?.({preventDefault(){}});}
    }
    const ids=['sharing-toggle','sharing-result','sharing-status','sharing-relay','sharing-import','sharing-refresh','sharing-add','sharing-viewer-name','sharing-viewers','sharing-empty','sharing-details','sharing-manage','sharing-add-form'];
    const elements=Object.fromEntries(ids.map(id=>[id,new Element()]));
    let receive;
    vm.runInNewContext(source,{document:{getElementById:id=>elements[id],createElement:()=>new Element()},window:{comms:{invoke,subscribe(callback){receive=callback;}},addEventListener(){}}});
    return {elements,emit:status=>receive({type:'sharing',status})};
}
const status=(extra={})=>({configured:true,canStart:true,enabled:false,connected:true,viewers:[],...extra});
test('a late status response cannot overwrite a newer sharing event',async()=>{
    const old=deferred();const ui=setup(()=>old.promise);
    ui.emit(status({enabled:true}));old.resolve({ok:true,result:status()});await tick();
    assert.equal(ui.elements['sharing-toggle'].textContent,'Stop sharing');
    assert.equal(ui.elements['sharing-toggle'].attributes['aria-pressed'],'true');
});
test('viewer labels use plain text and viewer removals update the keyed list',async()=>{
    const ui=setup(async()=>({ok:true,result:status()}));await tick();
    ui.emit(status({viewers:[{viewerId:'id',name:'<img src=x onerror=alert(1)>',connected:true}]}));
    assert.equal(ui.elements['sharing-viewers'].children[0].children[0].textContent,'<img src=x onerror=alert(1)> · connected');
    ui.emit(status());assert.equal(ui.elements['sharing-viewers'].children.length,0);
});
test('stop sharing remains usable during a pending setup-file export',async()=>{
    const pending=deferred(),calls=[];
    const current=status({enabled:true,viewers:[{viewerId:'id',name:'Friend'}]});
    const ui=setup(async(method)=>{
        calls.push(method);
        if(method==='sharing.viewer.export')return pending.promise;
        return {ok:true,result:current};
    });await tick();
    const save=ui.elements['sharing-viewers'].children[0].children[1].children[0];
    const saving=save.fire('click');await tick();
    assert.equal(ui.elements['sharing-toggle'].disabled,false);
    await ui.elements['sharing-toggle'].fire('click');
    assert.ok(calls.includes('sharing.stop'));
    pending.resolve({ok:true,result:{saved:true}});await saving;await tick();
});
