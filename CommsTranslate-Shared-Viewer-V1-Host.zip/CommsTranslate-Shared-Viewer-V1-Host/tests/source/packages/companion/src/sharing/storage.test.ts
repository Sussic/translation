import test, {type TestContext} from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp, readFile, readdir, rm, writeFile, symlink} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import path from 'node:path';
import {createCipheriv, createDecipheriv, randomBytes} from 'node:crypto';
import {newId, newSecret, type HostConfiguration} from '@comms/sharing';
import type {CredentialEncryption} from '@siwc/local';
import {SharingStore, HostSharingError, type SavedSharing} from './storage.js';

async function fixture(t:TestContext) {
 const directory=await mkdtemp(path.join(tmpdir(),'comms-sharing-store-'));
 t.after(()=>rm(directory,{recursive:true,force:true}));
 const key=randomBytes(32);
 const encryption:CredentialEncryption={
  id:'test-protected-store',isAvailable:()=>true,
  encrypt(text){const nonce=randomBytes(12),cipher=createCipheriv('aes-256-gcm',key,nonce);return Buffer.concat([nonce,cipher.update(text,'utf8'),cipher.final(),cipher.getAuthTag()]);},
  decrypt(bytes){const data=Buffer.from(bytes),cipher=createDecipheriv('aes-256-gcm',key,data.subarray(0,12));cipher.setAuthTag(data.subarray(-16));return Buffer.concat([cipher.update(data.subarray(12,-16)),cipher.final()]).toString('utf8');}
 };
 const configuration:HostConfiguration={format:'CommsTranslateHost',version:1,relayUrl:'https://relay.example.test',hostId:newId(),hostName:'Private host',publisherToken:newSecret()};
 const value:SavedSharing={version:1,configuration,viewers:[{registered:true,pairing:{format:'CommsTranslateViewer',version:1,relayUrl:configuration.relayUrl,hostId:configuration.hostId,hostName:configuration.hostName,viewerId:newId(),viewerName:'Private friend',viewerToken:newSecret(),captionSecret:newSecret()}}],revocations:[newId()]};
 return {directory,encryption,value,store:new SharingStore(directory,encryption)};
}
const safeError=(error:unknown)=>error instanceof HostSharingError&&error.code==='SHARING_STORAGE_UNAVAILABLE'&&!/secret-provider-detail|PRIVATE_TOKEN/.test(error.message);

test('sharing credentials round-trip encrypted, with no plaintext secrets or leftover temporary files',async t=>{
 const f=await fixture(t);await f.store.save(f.value);
 const file=await readFile(f.store.filename,'utf8');
 for(const secret of [f.value.configuration!.publisherToken,f.value.viewers[0]!.pairing.viewerToken,f.value.viewers[0]!.pairing.captionSecret,'Private host','Private friend'])assert.equal(file.includes(secret),false);
 assert.deepEqual(await f.store.load(),f.value);
 assert.deepEqual(await readdir(f.directory),['host-sharing.json']);
});

test('unavailable encryption never creates a plaintext fallback or replaces saved credentials',async t=>{
 const f=await fixture(t);await f.store.save(f.value);const before=await readFile(f.store.filename);
 f.encryption.isAvailable=()=>false;
 await assert.rejects(f.store.load(),safeError);await assert.rejects(f.store.save(f.value),safeError);
 assert.deepEqual(await readFile(f.store.filename),before);
 const fresh=new SharingStore(path.join(f.directory,'fresh'),f.encryption);
 await assert.rejects(fresh.save(f.value),safeError);await assert.rejects(readFile(fresh.filename),{code:'ENOENT'});
});

test('failed or empty encryption preserves the previous saved pairing',async t=>{
 const f=await fixture(t);await f.store.save(f.value);const before=await readFile(f.store.filename);
 f.encryption.encrypt=()=>{throw new Error('secret-provider-detail PRIVATE_TOKEN');};
 await assert.rejects(f.store.save(f.value),safeError);assert.deepEqual(await readFile(f.store.filename),before);
 f.encryption.encrypt=()=>new Uint8Array();
 await assert.rejects(f.store.save(f.value),safeError);assert.deepEqual(await readFile(f.store.filename),before);
 assert.deepEqual(await readdir(f.directory),['host-sharing.json']);
});

test('corrupt ciphertext and a changed encryption provider fail closed without changing the saved file',async t=>{
 const f=await fixture(t);await f.store.save(f.value);
 f.encryption.id='different-provider';await assert.rejects(f.store.load(),safeError);
 f.encryption.id='test-protected-store';
 const outer=JSON.parse(await readFile(f.store.filename,'utf8')) as {ciphertext:string};
 const ciphertext=Buffer.from(outer.ciphertext,'base64');ciphertext[15]=ciphertext[15]!^1;outer.ciphertext=ciphertext.toString('base64');
 await writeFile(f.store.filename,JSON.stringify(outer));const corrupt=await readFile(f.store.filename);
 await assert.rejects(f.store.load(),safeError);assert.deepEqual(await readFile(f.store.filename),corrupt);
});

test('saved viewer identities must be unique, belong to the configured host, and not remain in revocations',async t=>{
 const f=await fixture(t);await f.store.save(f.value);const before=await readFile(f.store.filename);
 const duplicate=structuredClone(f.value);duplicate.viewers.push(structuredClone(duplicate.viewers[0]!));
 const crossHost=structuredClone(f.value);crossHost.viewers[0]!.pairing.hostId=newId();
 const revoked=structuredClone(f.value);revoked.revocations.push(revoked.viewers[0]!.pairing.viewerId);
 const missingHost=structuredClone(f.value);delete missingHost.configuration;
 const tooMany=structuredClone(f.value);tooMany.viewers=Array.from({length:21},()=>({...structuredClone(f.value.viewers[0]!),pairing:{...f.value.viewers[0]!.pairing,viewerId:newId()}}));
 for(const invalid of [duplicate,crossHost,revoked,missingHost,tooMany])await assert.rejects(f.store.save(invalid),safeError);
 assert.deepEqual(await readFile(f.store.filename),before);
});

test('sharing storage refuses symlink targets and preserves the unrelated destination',async t=>{
 const f=await fixture(t),target=path.join(f.directory,'unrelated');await writeFile(target,'unrelated data');
 try{await symlink(target,f.store.filename);}catch(error){if((error as NodeJS.ErrnoException).code==='EPERM'){t.skip('Symlinks unavailable for this test account');return;}throw error;}
 await assert.rejects(f.store.load(),safeError);await assert.rejects(f.store.save(f.value),safeError);
 assert.equal(await readFile(target,'utf8'),'unrelated data');
});
