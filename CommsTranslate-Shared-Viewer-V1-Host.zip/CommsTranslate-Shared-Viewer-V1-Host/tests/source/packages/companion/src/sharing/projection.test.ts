import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {runInNewContext} from 'node:vm';
import type {CaptionEvent} from '@comms/shared';
import {CaptionProjection} from './projection.js';

const context:Record<string,any>={};
runInNewContext(readFileSync(new URL('../../ui/live-state.js',import.meta.url),'utf8'),context);
const {CaptionTimeline}=context.CommsLiveState;
const captionPresentation=context.CommsLiveState.captionPresentation as (event:CaptionEvent)=>{primary:string;readable:boolean;draft:boolean};
const caption=(overrides:Partial<CaptionEvent>={}):CaptionEvent=>({seq:1,timestamp:1000,type:'caption',sessionId:'session-a',utteranceId:'utterance-a',sourceLanguage:'de',targetLanguage:'en',text:'PRIVATE ORIGINAL',translated:'',provisional:false,translationState:'pending',...overrides});

test('projection matches local reading-only rules for foreign, same-language, uncertain, failed and draft captions',()=>{
 const examples=[
  caption(),caption({translated:'Hold position',translationState:'streaming',provisional:true}),
  caption({translated:'Hold position',translationState:'complete'}),
  caption({translated:'must disappear',translationState:'failed'}),
  caption({translated:'must disappear',translationState:'complete',error:{code:'FAIL',message:'PRIVATE ERROR'}}),
  caption({sourceLanguage:'en',text:'Same-language final',translationState:'complete'}),
  caption({sourceLanguage:'en',text:'Uncertain source',translationState:'complete',languageDetection:{confidence:.4,uncertain:true}}),
  caption({sourceLanguage:'en',text:'Low confidence source',translationState:'complete',languageDetection:{confidence:.84,uncertain:false}}),
  caption({sourceLanguage:'en',text:'Confident source',translationState:'complete',languageDetection:{confidence:.85,uncertain:false}}),
  caption({sourceLanguage:'en-US',targetLanguage:'en-US',text:'Regional source',translationState:'complete'}),
  caption({sourceLanguage:'en',text:'Still provisional',translationState:'complete',provisional:true})
 ];
 for(const event of examples){
  const projection=new CaptionProjection(()=>0),local=captionPresentation(event);
  projection.accept(event);const actual=projection.snapshot().rows;
  assert.deepEqual(actual.map(row=>({text:row.text,provisional:row.provisional})),local.readable?[{text:local.primary,provisional:local.draft}]:[]);
  assert.doesNotMatch(JSON.stringify(projection.snapshot()),/PRIVATE ORIGINAL|PRIVATE ERROR|sourceLanguage|diagnosticId|timing/);
 }
});

test('streaming corrections and pending/failed retractions follow the local timeline and never fall back to foreign originals',()=>{
 const projection=new CaptionProjection(()=>0),timeline=new CaptionTimeline(40,{retainReadable:2});
 const events=[
  caption({seq:1,utteranceId:'older',translated:'Previous useful caption',translationState:'complete'}),
  caption({seq:2,provisional:true}),
  caption({seq:3,translated:'Early draft',translationState:'streaming',provisional:true}),
  caption({seq:4,translated:'',text:'CORRECTED FOREIGN',provisional:true}),
  caption({seq:5,translated:'New draft',translationState:'streaming',provisional:true}),
  caption({seq:6,translated:'',text:'FINAL FOREIGN',provisional:false}),
  caption({seq:7,translated:'Late invalid draft',translationState:'streaming',provisional:true}),
  caption({seq:8,translated:'Final translation',translationState:'complete',provisional:false}),
  caption({seq:9,translated:'Late final mutation',translationState:'complete'})
 ];
 for(const event of events){
  projection.accept(event);timeline.accept(event);
  const expected=([...timeline.rows.values()] as CaptionEvent[]).map(captionPresentation).filter(value=>value.readable).slice(-2).map(value=>({text:value.primary,provisional:value.draft}));
  assert.deepEqual(projection.snapshot().rows.map(row=>({text:row.text,provisional:row.provisional})),expected);
 }
});

test('unchanged text and draft finalization preserve deadline; actual readable correction gets a fresh lifetime',()=>{
 let now=0;const projection=new CaptionProjection(()=>now);
 projection.accept(caption({translated:'Draft',translationState:'streaming',provisional:true}));
 const first=projection.snapshot().rows[0]!;assert.equal(first.remainingMs,15000);
 now=4000;projection.accept(caption({seq:2,translated:'Draft',translationState:'streaming',provisional:true}));
 assert.equal(projection.snapshot().rows[0]!.remainingMs,11000);assert.equal(projection.snapshot().rows[0]!.revision,first.revision);
 now=5000;projection.accept(caption({seq:3,translated:'Corrected draft',translationState:'streaming',provisional:true}));
 const corrected=projection.snapshot().rows[0]!;assert.equal(corrected.id,first.id);assert.equal(corrected.remainingMs,15000);assert.ok(corrected.revision>first.revision);
 now=6000;projection.accept(caption({seq:4,translated:'Corrected draft',translationState:'complete',provisional:false}));
 const final=projection.snapshot().rows[0]!;assert.equal(final.remainingMs,14000);assert.ok(final.revision>corrected.revision);assert.equal(final.provisional,false);
 now=20000;assert.deepEqual(projection.snapshot().rows,[]);assert.deepEqual(projection.snapshot().rows,[]);
});

test('expiry never backfills an older omitted caption even if its last correction was later',()=>{
 let now=0;const projection=new CaptionProjection(()=>now);
 projection.accept(caption({seq:1,utteranceId:'a',translated:'Older A',translationState:'streaming',provisional:true}));
 now=1000;projection.accept(caption({seq:2,utteranceId:'b',translated:'Newer B',translationState:'complete'}));
 now=2000;projection.accept(caption({seq:3,utteranceId:'c',translated:'Newest C',translationState:'complete'}));
 now=10000;projection.accept(caption({seq:4,utteranceId:'a',translated:'Late corrected A',translationState:'complete'}));
 assert.deepEqual(projection.snapshot().rows.map(row=>row.text),['Newer B','Newest C']);
 now=16000;assert.deepEqual(projection.snapshot().rows.map(row=>row.text),['Newest C']);
 now=17000;assert.deepEqual(projection.snapshot().rows,[]);
});

test('out-of-order events and finalized lines cannot mutate or revive displayed content',()=>{
 let now=0;const projection=new CaptionProjection(()=>now);
 projection.accept(caption({seq:3,translated:'Stable',translationState:'complete'}));
 assert.equal(projection.accept(caption({seq:2,translated:'Out of order',translationState:'streaming',provisional:true})),false);
 assert.equal(projection.accept(caption({seq:4,translated:'Late mutation',translationState:'complete'})),false);
 now=15000;assert.deepEqual(projection.snapshot().rows,[]);
 assert.equal(projection.accept(caption({seq:5,translated:'Revived',translationState:'complete'})),false);assert.deepEqual(projection.snapshot().rows,[]);
});

test('session boundary requires explicit clear and foreign-session data cannot mix into current projection',()=>{
 const projection=new CaptionProjection(()=>0);
 projection.accept(caption({translated:'First session',translationState:'complete'}));
 assert.equal(projection.accept(caption({seq:2,sessionId:'session-b',translated:'Unbound session',translationState:'complete'})),false);
 assert.deepEqual(projection.snapshot().rows.map(row=>row.text),['First session']);
 projection.clear();assert.deepEqual(projection.snapshot().rows,[]);
 assert.equal(projection.accept(caption({seq:3,sessionId:'session-b',translated:'New session',translationState:'complete'})),true);
 assert.deepEqual(projection.snapshot().rows.map(row=>row.text),['New session']);
});

test('oversize, control and malformed Unicode text become unavailable rather than truncated or leaked',()=>{
 for(const text of ['x'.repeat(2049),'漢'.repeat(683),'text\u0000hidden','text\u007fhidden','\ud800']){
  const projection=new CaptionProjection(()=>0);projection.accept(caption({translated:text,translationState:'complete'}));
  const result=projection.snapshot();assert.equal(result.unavailable,true);assert.deepEqual(result.rows,[]);
 }
 const projection=new CaptionProjection(()=>0);projection.accept(caption({translated:'Multilingual 日本語\nPolski\tDeutsch',translationState:'complete'}));
 assert.equal(projection.snapshot().unavailable,false);assert.equal(projection.snapshot().rows.length,1);
});
