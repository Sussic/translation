import test,{type TestContext} from 'node:test';
import assert from 'node:assert/strict';
import {once} from 'node:events';
import {mkdtemp,readFile,rm} from 'node:fs/promises';
import path from 'node:path';
import {tmpdir} from 'node:os';
import {createCipheriv,createDecipheriv,randomBytes} from 'node:crypto';
import {WebSocket} from 'ws';
import {newId,newSecret,ViewerCipher,type PairingFile,type Payload,type ViewPayload,type Routing} from '@comms/sharing';
import type {CaptionEvent} from '@comms/shared';
import type {CredentialEncryption} from '@siwc/local';
import {HostSharingService} from './service.js';
import {SharingStore} from './storage.js';

// Exercise the real separately built relay without pulling its source into companion's compilation root.
const {Registry}=await import(new URL('../../../relay/dist/registry.js',import.meta.url).href);
const {createRelay}=await import(new URL('../../../relay/dist/server.js',import.meta.url).href);
const delay=(ms:number)=>new Promise<void>(resolve=>setTimeout(resolve,ms));
async function until(check:()=>boolean,description:string){
 const deadline=Date.now()+5000;
 while(!check()){if(Date.now()>=deadline)throw new Error('Timed out: '+description);await delay(10);}
}
type Incoming={type:'control';value:Record<string,unknown>}|{type:'payload';value:Payload};
class ViewerPeer {
 readonly socket:WebSocket;
 private messages:Incoming[]=[];
 private listeners=new Set<()=>void>();
 private failure:unknown;
 private cipher:ViewerCipher|undefined;
 private route:Routing|undefined;
 lastView:ViewPayload|undefined;
 sealedCount=0;
 constructor(readonly pairing:PairingFile){
  const endpoint=pairing.relayUrl.replace(/^http:/,'ws:')+`/v1/hosts/${pairing.hostId}/viewers/${pairing.viewerId}`;
  this.socket=new WebSocket(endpoint,{headers:{Authorization:'Bearer '+pairing.viewerToken}});
  this.socket.on('error',error=>{this.failure=error;for(const notify of this.listeners)notify();});
  this.socket.on('message',data=>{
   try{
    const value=JSON.parse(data.toString()) as Record<string,unknown>;
    if(value.type==='sealed'){
     if(!this.cipher||value.challenge!==this.route?.challenge)return;
     const payload=this.cipher.open(data.toString());this.sealedCount++;
     if(payload.kind==='view')this.lastView=payload;
     this.messages.push({type:'payload',value:payload});
    }else this.messages.push({type:'control',value});
   }catch(error){this.failure=error;}
   for(const notify of this.listeners)notify();
  });
 }
 async introduce(){
  if(this.socket.readyState!==WebSocket.OPEN)await once(this.socket,'open');
  const connected=await this.control('connected');
  this.hello(connected.connectionId as string);
 }
 async connect(){
  await this.introduce();
  return this.view();
 }
 hello(connectionId=this.route?.connectionId){
  assert.ok(connectionId);
  this.route={hostId:this.pairing.hostId,viewerId:this.pairing.viewerId,connectionId,challenge:newSecret()};
  this.cipher=new ViewerCipher(this.pairing.captionSecret,this.route);
  this.socket.send(JSON.stringify({v:1,type:'hello',...this.route}));
 }
 async probe(requestView=false):Promise<Payload>{
  assert.ok(this.route);const challenge=newSecret();
  this.socket.send(JSON.stringify({v:1,type:'probe',...this.route,challenge,requestView}));
  return (await this.take((item):item is Incoming&{type:'payload'}=>item.type==='payload'&&item.value.probe===challenge)).value;
 }
 private take<T extends Incoming>(predicate:(value:Incoming)=>value is T):Promise<T>{
  return new Promise((resolve,reject)=>{
   const timer=setTimeout(()=>finish(new Error('Timed out waiting for viewer state')),5000);
   const finish=(error?:unknown,value?:T)=>{clearTimeout(timer);this.listeners.delete(check);if(error)reject(error);else resolve(value!);};
   const check=()=>{if(this.failure){finish(this.failure);return;}const index=this.messages.findIndex(predicate);if(index>=0)finish(undefined,this.messages.splice(index,1)[0] as T);};
   this.listeners.add(check);check();
  });
 }
 async control(type:string){return (await this.take((item):item is Incoming&{type:'control'}=>item.type==='control'&&item.value.type===type)).value;}
 async view(predicate:(value:ViewPayload)=>boolean=()=>true){
  return (await this.take((item):item is Incoming&{type:'payload';value:ViewPayload}=>item.type==='payload'&&item.value.kind==='view'&&predicate(item.value))).value;
 }
 async close(){if(this.socket.readyState===WebSocket.CLOSED)return;const closed=once(this.socket,'close');this.socket.terminate();await closed;}
}

async function fixture(t:TestContext){
 const directory=await mkdtemp(path.join(tmpdir(),'comms-sharing-integration-'));
 const registry=new Registry(':memory:'),hostId=newId(),publisherToken=newSecret();registry.provision(hostId,publisherToken);
 let clock=10000;
 const relay=createRelay({registry,bind:'127.0.0.1',port:0,now:()=>clock});
 const port=await relay.listen();
 const key=randomBytes(32);
 const encryption:CredentialEncryption={id:'test-host-encryption',isAvailable:()=>true,
  encrypt(text){const nonce=randomBytes(12),cipher=createCipheriv('aes-256-gcm',key,nonce);return Buffer.concat([nonce,cipher.update(text,'utf8'),cipher.final(),cipher.getAuthTag()]);},
  decrypt(value){const data=Buffer.from(value),decipher=createDecipheriv('aes-256-gcm',key,data.subarray(0,12));decipher.setAuthTag(data.subarray(-16));return Buffer.concat([decipher.update(data.subarray(12,-16)),decipher.final()]).toString('utf8');}
 };
 const service=new HostSharingService({storageDir:directory,credentialEncryption:encryption,allowInsecureLoopback:true,now:()=>clock});
 const peers:ViewerPeer[]=[];
 t.after(async()=>{await Promise.allSettled(peers.map(peer=>peer.close()));await service.close();await relay.close();registry.close();await rm(directory,{recursive:true,force:true});});
 await service.initialize();
 await service.importProvisioning({format:'CommsTranslateHost',version:1,relayUrl:`http://127.0.0.1:${port}`,hostId,hostName:'Host',publisherToken});
 await until(()=>service.getStatus().connected,'publisher connection');
 const binding={sessionId:'asr-session-1',captureId:'capture-session',channelId:'PRIVATE_CHANNEL',sourceId:'PRIVATE_PID',targetLanguage:'en'};
 const voice=(overrides:Record<string,unknown>={})=>({active:true,starting:false,paused:false,...binding,...overrides});
 let seq=0;
 const event=(overrides:Partial<CaptionEvent>={}):CaptionEvent=>({type:'caption',seq:++seq,timestamp:Date.now(),sessionId:binding.sessionId,utteranceId:'speech-1',sourceLanguage:'de',targetLanguage:'en',text:'PRIVATE ORIGINAL',translated:'Translated caption',translationState:'complete',provisional:false,diagnosticId:'PRIVATE_DIAGNOSTIC',timing:{recognitionMs:123},...overrides});
 const add=async(name='Friend')=>{
  const added=await service.addViewer(name),pairing=await service.exportViewer(added.viewerId);
  const peer=new ViewerPeer(pairing);peers.push(peer);await peer.connect();return peer;
 };
 return {service,registry,relay,directory,encryption,binding,voice,event,add,peers,publisherToken,clock:()=>clock,advance:(ms:number)=>{clock+=ms;}};
}

test('real host fans one safe caption out to twenty independently encrypted viewers',async t=>{
 const f=await fixture(t),peers:ViewerPeer[]=[];
 for(let i=0;i<20;i++)peers.push(await f.add('Viewer '+i));
 f.service.syncVoiceState(f.voice());await f.service.start(f.binding);
 f.service.handleEvent(f.event());
 const views=await Promise.all(peers.map(peer=>peer.view(value=>value.rows.some(row=>row.text==='Translated caption'))));
 const ids=new Set(views.map(value=>value.rows[0]!.id));assert.equal(ids.size,1);
 for(const view of views){
  assert.equal(view.status,'sharing');assert.equal(view.outputLanguage,'en');assert.equal(view.rows.length,1);
  assert.doesNotMatch(JSON.stringify(view),/PRIVATE|sourceLanguage|diagnostic|recognition|publisherToken|captionSecret/);
 }
 const saved=await readFile(path.join(f.directory,'host-sharing.json'),'utf8');assert.equal(saved.includes(f.publisherToken),false);
 await assert.rejects(f.service.addViewer('Over limit'));
});

test('real host clears revised/failed drafts and never transmits untranslated foreign source',async t=>{
 const f=await fixture(t),peer=await f.add();f.service.syncVoiceState(f.voice());await f.service.start(f.binding);
 await peer.view(value=>value.status==='sharing');
 f.service.handleEvent(f.event({translated:'Early draft',translationState:'streaming',provisional:true}));
 const draft=await peer.view(value=>value.rows[0]?.text==='Early draft');assert.equal(draft.rows[0]!.provisional,true);
 f.service.handleEvent(f.event({translated:'',translationState:'pending',provisional:false}));
 const cleared=await peer.view(value=>value.status==='sharing'&&value.rows.length===0);assert.doesNotMatch(JSON.stringify(cleared),/PRIVATE ORIGINAL/);
 f.service.handleEvent(f.event({translated:'MUST NOT ESCAPE',translationState:'failed',error:{code:'FAIL',message:'PRIVATE ERROR'}}));
 f.service.handleEvent(f.event({utteranceId:'speech-2',sourceLanguage:'en',text:'Same language caption',translated:'',translationState:'complete'}));
 const same=await peer.view(value=>value.rows.some(row=>row.text==='Same language caption'));
 assert.deepEqual(same.rows.map(row=>row.text),['Same language caption']);assert.doesNotMatch(JSON.stringify(same),/PRIVATE|MUST NOT ESCAPE/);
});

test('pause clears output and resumes a new ASR session only inside the same authorized capture',async t=>{
 const f=await fixture(t),peer=await f.add();f.service.syncVoiceState(f.voice());await f.service.start(f.binding);
 f.service.handleEvent(f.event());const first=await peer.view(value=>value.rows.length===1);
 f.service.syncVoiceState(f.voice({paused:true}));const paused=await peer.view(value=>value.status==='paused');assert.deepEqual(paused.rows,[]);
 f.service.syncVoiceState(f.voice({sessionId:'asr-session-2'}));
 f.service.handleEvent(f.event({sessionId:'asr-session-2',utteranceId:'resumed',translated:'After pause'}));
 const resumed=await peer.view(value=>value.rows[0]?.text==='After pause');assert.equal(resumed.broadcastId,first.broadcastId);
 f.service.syncVoiceState(f.voice({sessionId:'asr-session-2',channelId:'OTHER_CHANNEL'}));
 const stopped=await peer.view(value=>value.status==='off');assert.deepEqual(stopped.rows,[]);assert.equal(f.service.getStatus().enabled,false);
 f.service.handleEvent(f.event({sessionId:'asr-session-2',utteranceId:'after-change',translated:'UNAUTHORIZED NEW CHANNEL'}));
 assert.equal(f.service.getStatus().enabled,false);
});

test('fresh viewer connections omit expired captions and capture stop cannot auto-share on publisher reconnect',async t=>{
 const f=await fixture(t),peer=await f.add();f.service.syncVoiceState(f.voice());await f.service.start(f.binding);
 f.service.handleEvent(f.event());await peer.view(value=>value.rows.length===1);
 f.advance(15001);await peer.close();
 const replacement=new ViewerPeer(peer.pairing);f.peers.push(replacement);const initial=await replacement.connect();
 assert.equal(initial.status,'sharing');assert.deepEqual(initial.rows,[]);
 f.service.syncVoiceState({active:false});await replacement.view(value=>value.status==='off');
 await f.service.reconnect();await replacement.control('publisher-ready');replacement.hello();
 const reconnected=await replacement.view(value=>value.status==='off');assert.deepEqual(reconnected.rows,[]);assert.equal(f.service.getStatus().enabled,false);
});

test('failed relay revocation is durably queued while the removed viewer gets no new host ciphertext',async t=>{
 const f=await fixture(t),removed=await f.add('Remove me'),retained=await f.add('Keep me');
 f.service.syncVoiceState(f.voice());await f.service.start(f.binding);f.service.handleEvent(f.event());
 await removed.view(value=>value.rows.length===1);await retained.view(value=>value.rows.length===1);
 const revoke=f.registry.revokeViewer.bind(f.registry);f.registry.revokeViewer=()=>{throw new Error('Simulated relay storage failure');};
 await Promise.resolve(f.service.removeViewer(removed.pairing.viewerId)).catch(()=>{});
 const count=removed.sealedCount;
 f.service.handleEvent(f.event({utteranceId:'after-revoke',translated:'Only retained viewer'}));
 await retained.view(value=>value.rows.some(row=>row.text==='Only retained viewer'));await delay(30);
 assert.equal(removed.sealedCount,count);
 const saved=await new SharingStore(f.directory,f.encryption,{allowInsecureLoopback:true}).load();
 assert.equal(saved.viewers.some(row=>row.pairing.viewerId===removed.pairing.viewerId),false);
 assert.ok(saved.revocations.includes(removed.pairing.viewerId));
 f.registry.revokeViewer=revoke;
});

test('escaping expansion becomes an unavailable view without disconnecting the publisher',async t=>{
 const f=await fixture(t),peer=await f.add();f.service.syncVoiceState(f.voice());await f.service.start(f.binding);
 f.service.handleEvent(f.event({utteranceId:'large-1',translated:'a'+'\n'.repeat(2047)}));
 await peer.view(value=>value.rows.length===1);
 f.service.handleEvent(f.event({utteranceId:'large-2',translated:'b'+'\n'.repeat(2047)}));
 const unavailable=await peer.view(value=>value.status==='unavailable');
 assert.deepEqual(unavailable.rows,[]);assert.equal(f.service.getStatus().connected,true);assert.equal(f.service.getStatus().enabled,true);
 f.service.handleEvent(f.event({utteranceId:'small-1',translated:'Readable one'}));
 f.service.handleEvent(f.event({utteranceId:'small-2',translated:'Readable two'}));
 const recovered=await peer.view(value=>value.rows.some(row=>row.text==='Readable two'));
 assert.equal(recovered.status,'sharing');assert.equal(f.service.getStatus().connected,true);
});

test('probe replies authenticate current revision, pause/off state and remaining lifetime without refreshing text',async t=>{
 const f=await fixture(t),peer=await f.add();f.service.syncVoiceState(f.voice());await f.service.start(f.binding);
 f.service.handleEvent(f.event());const first=await peer.view(value=>value.rows.length===1);
 f.advance(3000);const unchanged=await peer.probe();
 assert.equal(unchanged.kind,'status');assert.equal(unchanged.viewRevision,first.viewRevision);assert.equal(unchanged.broadcastId,first.broadcastId);
 f.advance(1000);const full=await peer.probe(true);assert.equal(full.kind,'view');
 if(full.kind!=='view')throw new Error('Expected current full view');
 assert.equal(full.rows[0]!.remainingMs,11000);assert.equal(full.viewRevision,first.viewRevision);
 f.service.syncVoiceState(f.voice({paused:true}));await peer.view(value=>value.status==='paused');
 f.advance(1000);const paused=await peer.probe();assert.equal(paused.status,'paused');assert.equal(paused.broadcastId,first.broadcastId);assert.ok(paused.viewRevision>first.viewRevision);
 f.service.stop();await peer.view(value=>value.status==='off');
 f.advance(1000);const stopped=await peer.probe();assert.equal(stopped.status,'off');assert.equal(stopped.broadcastId,null);assert.ok(stopped.viewRevision>paused.viewRevision);
});

test('capture-source change ends authorization and a regional reading language survives unchanged',async t=>{
 const f=await fixture(t),peer=await f.add(),binding={...f.binding,targetLanguage:'en-US'};
 f.service.syncVoiceState({...f.voice(),targetLanguage:'en-US'});await f.service.start(binding);
 f.service.handleEvent(f.event({sourceLanguage:'en-US',targetLanguage:'en-US',text:'Regional caption',translated:''}));
 const regional=await peer.view(value=>value.rows[0]?.text==='Regional caption');assert.equal(regional.outputLanguage,'en-US');
 f.service.syncVoiceState({...f.voice(),targetLanguage:'en-US',sourceId:'different-process'});
 const ended=await peer.view(value=>value.status==='off');assert.equal(ended.broadcastId,null);assert.equal(f.service.getStatus().enabled,false);
 f.service.syncVoiceState({...f.voice(),targetLanguage:'en-US'});assert.equal(f.service.getStatus().enabled,false);
});

test('a failed durable removal stops sharing and never resumes merely because storage recovers',async t=>{
 const f=await fixture(t),peer=await f.add();f.service.syncVoiceState(f.voice());await f.service.start(f.binding);
 f.service.handleEvent(f.event());await peer.view(value=>value.rows.length===1);
 const before=await readFile(path.join(f.directory,'host-sharing.json')),encrypt=f.encryption.encrypt;
 f.encryption.encrypt=()=>{throw new Error('Simulated protected-store failure');};
 await assert.rejects(f.service.removeViewer(peer.pairing.viewerId));
 assert.equal(f.service.getStatus().enabled,false);assert.deepEqual(await readFile(path.join(f.directory,'host-sharing.json')),before);
 f.encryption.encrypt=encrypt;f.service.syncVoiceState(f.voice());assert.equal(f.service.getStatus().enabled,false);
 await f.service.removeViewer(peer.pairing.viewerId);
 assert.equal(f.service.getStatus().viewers.some(viewer=>viewer.viewerId===peer.pairing.viewerId),false);
});

test('rapid viewer replacement shares one crypto budget, keeps only the latest hello and cancels revoked pending work',async t=>{
 const f=await fixture(t),original=await f.add('Reconnect'),observer=await f.add('Unaffected');
 f.service.syncVoiceState(f.voice());await f.service.start(f.binding);f.service.handleEvent(f.event());
 await original.view(value=>value.rows.length===1);await observer.view(value=>value.rows.length===1);
 const superseded=new ViewerPeer(original.pairing);f.peers.push(superseded);await superseded.introduce();
 await until(()=>!f.service.getStatus().viewers.find(viewer=>viewer.viewerId===original.pairing.viewerId)?.connected,'replacement handshake is deferred');
 const latest=new ViewerPeer(original.pairing);f.peers.push(latest);await latest.introduce();
 await delay(30);
 assert.equal(superseded.sealedCount,0);assert.equal(latest.sealedCount,0);
 f.service.handleEvent(f.event({utteranceId:'during-handshake',translated:'While reconnecting'}));
 await observer.view(value=>value.rows.some(row=>row.text==='While reconnecting'));
 assert.equal(latest.sealedCount,0,'pending peer cannot use the retired cipher for caption delivery');
 f.service.stop();await observer.view(value=>value.status==='off');
 f.advance(1000);
 const fresh=await latest.view();assert.equal(fresh.status,'off');assert.deepEqual(fresh.rows,[]);
 assert.equal(superseded.sealedCount,0,'superseded pending hello must never encrypt a response');
 assert.equal(f.service.getStatus().connected,true);
 const revoked=new ViewerPeer(original.pairing);f.peers.push(revoked);await revoked.introduce();
 await until(()=>!f.service.getStatus().viewers.find(viewer=>viewer.viewerId===original.pairing.viewerId)?.connected,'revocable handshake is deferred');
 await f.service.removeViewer(original.pairing.viewerId);f.advance(1000);await delay(1050);
 assert.equal(revoked.sealedCount,0);assert.equal(revoked.socket.readyState,WebSocket.CLOSED);
 assert.equal(f.service.getStatus().connected,true);
});
