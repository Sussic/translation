import test from 'node:test';
import assert from 'node:assert/strict';
import {validateRequest} from '@comms/shared';
import {SharingUiController,type SharingUiService,type SharingVoiceState} from './sharingUi.js';

function fixture(){
    let voice:SharingVoiceState={active:true,sessionId:'voice-1',channelId:'channel-1',sourceId:'100',targetLanguage:'en'};
    let enabled=false, savePath:string|undefined='/chosen/viewer.commsviewer';
    let reads=0, adds=0, starts=0, removed=0, stops=0;
    const saved:unknown[]=[];
    const viewerId='AAAAAAAAAAAAAAAAAAAAAA';
    const secret={viewerId,captionSecret:'PRIVATE CAPTION KEY',viewerToken:'PRIVATE VIEW TOKEN'};
    const service:SharingUiService={
        getStatus:()=>({configured:true,enabled,connected:true,viewers:[{viewerId,name:'Friend',connected:false}]}),
        syncVoiceState(value){if(!value.active||value.sessionId!=='voice-1')enabled=false;},
        async importProvisioning(_data){},
        async addViewer(_name){adds++;return {viewerId};},
        exportViewer:()=>secret,
        removeViewer:()=>{removed++;},
        start(binding){assert.deepEqual(binding,{sessionId:'voice-1',channelId:'channel-1',sourceId:'100',targetLanguage:'en'});enabled=true;starts++;},
        stop(){enabled=false;stops++;},reconnect(){}
    };
    const ports={sharing:()=>service,voice:()=>voice,readHostSetup:async()=>{reads++;return {publisherToken:'PRIVATE HOST TOKEN'};},chooseViewerPath:async()=>savePath,writeViewerSetup:async(_path:string,value:unknown)=>{saved.push(value);}};
    return {controller:new SharingUiController(ports),ports,service,viewerId,saved,setVoice:(v:SharingVoiceState)=>{voice=v;},setPath:(p:string|undefined)=>{savePath=p;},counts:()=>({reads,adds,starts,removed,stops})};
}
test('sharing is denied to overlay/untrusted senders and absent from the Discord RPC contract',async()=>{
    const f=fixture();
    for(const method of ['sharing.status','sharing.start','sharing.stop','sharing.import','sharing.reconnect','sharing.viewer.add','sharing.viewer.export','sharing.viewer.remove']){
        await assert.rejects(f.controller.handle(false,method,{}),/companion dashboard/);
        assert.throws(()=>validateRequest({v:1,id:'id',method,params:{}}));
    }
    assert.deepEqual(f.counts(),{reads:0,adds:0,starts:0,removed:0,stops:0});
});
test('strict argument validation rejects extra fields, host RPC injection and malformed identifiers',async()=>{
    const f=fixture();
    for(const [method,params] of [
        ['sharing.translate',{text:'call the model'}],['sharing.start',{publisherToken:'evil'}],
        ['sharing.viewer.add',{name:'x',captionSecret:'evil'}],['sharing.viewer.add',{name:'\n'}],
        ['sharing.viewer.export',{viewerId:'../config'}],['sharing.status',[]]
    ] as const)await assert.rejects(f.controller.handle(true,method,params),/Invalid|Enter a viewer/);
    assert.equal(f.counts().starts,0);
});
test('start requires running, unpaused captions and binds to local voice context only',async()=>{
    const f=fixture();
    for(const voice of [{active:false},{active:true,starting:true},{active:true,paused:true}]){
        f.setVoice(voice);await assert.rejects(f.controller.handle(true,'sharing.start',{}),/Start captions/);
    }
    f.setVoice({active:true,sessionId:'voice-1',channelId:'channel-1',sourceId:'100',targetLanguage:'en'});
    await f.controller.handle(true,'sharing.start',{});
    assert.equal(f.counts().starts,1);
});
test('viewer export sends secrets only to main-process save callback and never returns them',async()=>{
    const f=fixture();
    const result=await f.controller.handle(true,'sharing.viewer.export',{viewerId:f.viewerId});
    assert.deepEqual(result,{saved:true});
    assert.equal(f.saved.length,1);assert.match(JSON.stringify(f.saved[0]),/PRIVATE CAPTION KEY/);
    assert.doesNotMatch(JSON.stringify(result),/PRIVATE|Token|Secret/);
    const imported=await f.controller.handle(true,'sharing.import',{});
    assert.deepEqual(imported,{imported:true});assert.doesNotMatch(JSON.stringify(imported),/PRIVATE/);
});
test('cancelled save creates no persistent viewer; failed write keeps viewer available for re-export',async()=>{
    const f=fixture();f.setPath(undefined);
    assert.deepEqual(await f.controller.handle(true,'sharing.viewer.add',{name:'Friend'}),{saved:false});
    assert.equal(f.counts().adds,0);
    f.setPath('/chosen/file');f.ports.writeViewerSetup=async()=>{throw Error('PRIVATE PATH OR TOKEN');};
    await assert.rejects(f.controller.handle(true,'sharing.viewer.add',{name:'Friend'}),/viewer was added, but its setup file/);
    assert.equal(f.counts().adds,1);assert.equal(f.counts().removed,0);
});
test('stop remains available while an export dialog is pending',async()=>{
    const f=fixture();await f.controller.handle(true,'sharing.start',{});
    let resolve!:(value:undefined)=>void;
    f.ports.chooseViewerPath=()=>new Promise<string|undefined>(done=>{resolve=done;});
    const pending=f.controller.handle(true,'sharing.viewer.export',{viewerId:f.viewerId});
    await assert.rejects(f.controller.handle(true,'sharing.start',{}),/Finish the current/);
    await f.controller.handle(true,'sharing.stop',{});
    assert.equal(f.counts().stops,1);
    resolve(undefined);await pending;
    assert.equal(f.controller.status().enabled,false);
});
test('changed capture context is reconciled and provider exceptions do not expose secret text',async()=>{
    const f=fixture();await f.controller.handle(true,'sharing.start',{});
    f.setVoice({active:false});assert.equal(f.controller.status().enabled,false);
    f.service.reconnect=()=>{throw Error('https://secret.invalid?token=PRIVATE');};
    await assert.rejects(f.controller.handle(true,'sharing.reconnect',{}),e=>e instanceof Error&&!/PRIVATE|secret.invalid/.test(e.message));
});
