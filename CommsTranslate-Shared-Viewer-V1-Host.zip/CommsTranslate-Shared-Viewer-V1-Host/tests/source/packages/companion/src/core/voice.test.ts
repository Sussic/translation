import assert from 'node:assert/strict';
import {EventEmitter} from 'node:events';
import {test, type TestContext} from 'node:test';
import {DEFAULT_SETTINGS, ProtocolError} from '@comms/shared';
import {EventBuffer} from './events.js';
import {VoicePipeline} from './voice.js';
import type {LocalRuntime} from './local.js';
import type {TranslationService} from './translation.js';
import type {DraftDiagnosticEvent} from './translationDiagnostics.js';

interface SessionFixture {
 id:string;captureId:string;channelId:string;pid:number;sourceName:string;sourceLanguage:string;targetLanguage:string;
 mode:'local'|'chatgpt';lastHeartbeat:number;createdAt:number;ready:boolean;paused:boolean;profile:'eve';model:string;
 speechLanguageMode?:'fixed'|'auto';expectedLanguages?:string[];latencyMode?:'live'|'balanced';
}
interface WorkerCall {type:string;params:Record<string,unknown>;timeout?:number}

function fixture(t:TestContext) {
 const local=new EventEmitter() as EventEmitter & {worker:{request:(type:string,params?:Record<string,unknown>,timeout?:number)=>Promise<unknown>;send:()=>void};ensure:()=>Promise<void>;capabilities:{asrLanguages:string[];localPairs:any[]}};
 local.capabilities={asrLanguages:['en','ja','pl'],localPairs:[]};
 const calls:WorkerCall[]=[];
 let respond=(call:WorkerCall):Promise<unknown>=>Promise.resolve({});
 local.worker={request:async(type,params={},timeout)=>{const call={type,params,timeout};calls.push(call);return respond(call);},send:()=>{}};
 local.ensure=async()=>{};
 let captureStarts=0,clears=0,translations=0;
 let translate:(...args:any[])=>Promise<any>=async()=>({text:'Hold.',elapsedMs:1});
 const cancellations:string[]=[];
 const translator={clear:()=>{clears++;},cancel:(id:string)=>cancellations.push(id),translate:async(...args:any[])=>{translations++;return translate(...args);}};
 const events=new EventBuffer(100);
 const settings=structuredClone(DEFAULT_SETTINGS);settings.privacyAcknowledged=true;
 const pipeline=new VoicePipeline('unused-native-helper',local as unknown as LocalRuntime,translator as unknown as TranslationService,events,()=>settings,async()=>true);
 const state=pipeline as unknown as {session:SessionFixture|undefined;leaseTimer:ReturnType<typeof setInterval>;startCapture:()=>Promise<void>};
 state.startCapture=async()=>{captureStarts++;};
 t.after(()=>{clearInterval(state.leaseTimer);});
 const session:SessionFixture={id:'current-session',captureId:'capture-lifetime',channelId:'current-channel',pid:10,sourceName:'Discord test',sourceLanguage:'ja',targetLanguage:'en',mode:'local',lastHeartbeat:Date.now(),createdAt:Date.now(),ready:true,paused:true,profile:'eve',model:''};
 state.session=session;
 return {pipeline,state,local,events,calls,session,cancellations,settings,setTranslate:(next:typeof translate)=>{translate=next;},setResponder:(next:typeof respond)=>{respond=next;},captureStarts:()=>captureStarts,clears:()=>clears,translations:()=>translations};
}

const turn=()=>new Promise(resolve=>setImmediate(resolve));
function speech(f:ReturnType<typeof fixture>,id:string,duration=1000){f.local.emit('event',{type:'transcriptFinal',sessionId:f.session.id,utteranceId:id,text:`Speech ${id}`,startMs:0,endMs:duration,timing:{recognitionMs:42,recognitionQueueMs:3,speechMs:duration,endpointWaitMs:300}});}

test('Same-language captions bypass translation and preserve measured speech timings',async t=>{
 const f=fixture(t);f.session.paused=false;f.session.sourceLanguage='en';f.session.targetLanguage='en';
 speech(f,'same');await turn();
 assert.equal(f.translations(),0);
 const caption=f.events.poll(0).events.at(-1)!;
 assert.equal(caption.translated,'Speech same');assert.equal(caption.translationState,'complete');assert.equal(caption.timing?.recognitionMs,42);
});

test('Two translation requests can progress independently but a third waits for capacity',async t=>{
 const f=fixture(t);f.session.paused=false;
 const jobs=new Map<string,{resolve:(value:any)=>void;options:any}>();
 f.setTranslate((id,_request,_timeout,options)=>new Promise(resolve=>jobs.set(id,{resolve,options})));
 speech(f,'one');speech(f,'two');speech(f,'three');assert.equal(jobs.size,2);
 const id=(utterance:string)=>`voice-${f.session.id}-${utterance}`;
 jobs.get(id('two'))!.options.onPreview('Second draft',{firstTextMs:8,translationMs:9});
 jobs.get(id('two'))!.resolve({text:'Second complete',elapsedMs:12});await turn();assert.equal(jobs.size,3);
 jobs.get(id('one'))!.resolve({text:'First complete',elapsedMs:20});jobs.get(id('three'))!.resolve({text:'Third complete',elapsedMs:10});await turn();
 const events=f.events.poll(0).events.filter(x=>x.type==='caption');
 assert.deepEqual(events.filter(x=>x.translationState==='complete').map(x=>x.utteranceId),['two','one','three']);
 assert.equal(events.find(x=>x.translationState==='streaming')?.provisional,false);
 assert.equal(events.find(x=>x.utteranceId==='two'&&x.translationState==='complete')?.timing?.firstTextMs,8);
});

test('Pausing clears in-flight drafts and rejects later preview and completion events',async t=>{
 const f=fixture(t);f.session.paused=false;
 let options:any,resolve:(value:any)=>void=()=>{};
 f.setTranslate((_id,_request,_timeout,opts)=>{options=opts;return new Promise(done=>{resolve=done;});});
 speech(f,'one');options.onPreview('Draft',{firstTextMs:1,translationMs:1});
 await f.pipeline.pause(true);
 let caption=f.events.poll(0).events.filter(x=>x.type==='caption').at(-1)!;
 assert.equal(caption.translated,'');assert.equal(caption.translationState,'failed');assert.equal(f.cancellations.length,1);
 const count=f.events.poll(0).events.length;
 options.onPreview('Late draft',{firstTextMs:1,translationMs:10});resolve({text:'Late final',elapsedMs:11});await turn();
 assert.equal(f.events.poll(0).events.length,count);
});

test('Translation timeout removes its draft and retains the original caption',async t=>{
 const f=fixture(t);f.session.paused=false;
 f.setTranslate(async(_id,_request,_timeout,options)=>{options.onPreview('Draft',{firstTextMs:2,translationMs:2});throw new ProtocolError('TRANSLATION_TIMEOUT','Private raw failure');});
 speech(f,'timeout');await turn();
 const caption=f.events.poll(0).events.filter(x=>x.type==='caption').at(-1)!;
 assert.equal(caption.text,'Speech timeout');assert.equal(caption.translated,'');assert.equal(caption.translationState,'failed');
 assert.doesNotMatch(JSON.stringify(f.events.poll(0)),/Private raw failure/);
});

test('Late successful translation cannot commit after the live age deadline',async t=>{
 const f=fixture(t);f.session.paused=false;
 let resolve:(value:any)=>void=()=>{},options:any;
 f.setTranslate((_id,_request,_timeout,opts)=>{options=opts;return new Promise(done=>{resolve=done;});});
 speech(f,'old');options.onPreview('Earlier draft',{firstTextMs:1,translationMs:1});
 const job=[...(f.pipeline as any).translating.values()][0] as any;job.time-=10001;
 options.onPreview('Too late draft',{firstTextMs:1,translationMs:10002});resolve({text:'Too late final',elapsedMs:10002});await turn();
 const captions=f.events.poll(0).events.filter(x=>x.type==='caption');
 assert.equal(captions.at(-1)?.translated,'');assert.equal(captions.at(-1)?.translationState,'failed');
 assert.equal(captions.some(x=>x.translated==='Too late draft'||x.translated==='Too late final'),false);
});

test('Queue overload marks skipped original rows and never starts stale queued work',async t=>{
 const f=fixture(t);f.session.paused=false;
 const jobs:Array<(value:any)=>void>=[];
 f.setTranslate(()=>new Promise(resolve=>jobs.push(resolve)));
 speech(f,'one');speech(f,'two');speech(f,'three',6000);speech(f,'four',6000);
 assert.equal(f.events.poll(0).events.find(x=>x.utteranceId==='three'&&x.translationState==='failed')?.error?.code,'CAPTION_SKIPPED');
 const internals=f.pipeline as any;internals.queue[0].time-=10001;
 jobs[0]!({text:'First',elapsedMs:1});await turn();assert.equal(f.translations(),2);
 assert.equal(f.events.poll(0).events.find(x=>x.utteranceId==='four'&&x.translationState==='failed')?.error?.code,'CAPTION_SKIPPED');
 jobs[1]!({text:'Second',elapsedMs:2});await turn();
});

test('A speech-worker failure during resume stops the session before capture can start',async t=>{
 const f=fixture(t);
 f.setResponder(async call=>{if(call.type==='start')throw new ProtocolError('ASR_START_FAILED','Synthetic ASR start failure.');return {};});
 await assert.rejects(f.pipeline.pause(false),{code:'ASR_START_FAILED'});
 assert.equal(f.pipeline.status().active,false);
 assert.equal(f.captureStarts(),0);
 assert.deepEqual(f.calls.map(call=>call.type),['stop','start','stop']);
 assert.equal(f.clears(),1);
});

test('Stopping while resume awaits the worker prevents late native capture startup',async t=>{
 const f=fixture(t);
 let releaseStart:((value:unknown)=>void)|undefined;
 let started:()=>void=()=>{};
 const startRequested=new Promise<void>(resolve=>{started=resolve;});
 f.setResponder(call=>{
  if(call.type==='start'){started();return new Promise(resolve=>{releaseStart=resolve;});}
  return Promise.resolve({});
 });
 const resume=f.pipeline.pause(false);
 await startRequested;
 await f.pipeline.stop();
 releaseStart!({});
 await resume;
 assert.equal(f.pipeline.status().active,false);
 assert.equal(f.captureStarts(),0);
 assert.equal(f.events.poll(0).events.some(event=>event.text==='Captions resumed.'),false);
});

test('Stop clears captions immediately and gives the worker only a two-second deadline',async t=>{
 t.mock.timers.enable({apis:['setTimeout']});
 const f=fixture(t);
 f.session.paused=false;
 f.events.push({type:'caption',sessionId:f.session.id,text:'Private session caption'});
 f.setResponder(call=>new Promise((_resolve,reject)=>{
  assert.equal(call.type,'stop');
  assert.equal(call.timeout,2000);
  setTimeout(()=>reject(new ProtocolError('WORKER_TIMEOUT','Synthetic stalled worker.')),call.timeout);
 }));
 let completed=false;
 const stopping=f.pipeline.stop().then(()=>{completed=true;});
 assert.equal(f.pipeline.status().active,false);
 assert.equal(f.events.poll(0).events.some(event=>event.type==='caption'),false);
 t.mock.timers.tick(1999);await Promise.resolve();
 assert.equal(completed,false);
 t.mock.timers.tick(1);await stopping;
 assert.equal(completed,true);
 assert.equal(f.pipeline.status().active,false);
});

test('Transcripts from stale sessions are ignored while current partial captions remain visible',async t=>{
 const f=fixture(t);f.session.paused=false;
 for(const type of ['transcriptPartial','transcriptFinal'])f.local.emit('event',{type,sessionId:'previous-session',utteranceId:'old-utterance',text:'Old private speech',startMs:0,endMs:1000});
 assert.deepEqual(f.events.poll(0).events,[]);
 assert.equal(f.translations(),0);
 f.local.emit('event',{type:'transcriptPartial',sessionId:f.session.id,utteranceId:'current-utterance',text:'Current speech'});
 const captions=f.events.poll(0).events;
 assert.equal(captions.length,1);
 const caption=captions[0];assert.ok(caption);
 assert.equal(caption.text,'Current speech');
 assert.equal(caption.provisional,true);
 assert.equal(f.translations(),0);
});

function detectedSpeech(f:ReturnType<typeof fixture>,id:string,sourceLanguage:string,uncertain=false,confidence=.95){
 f.local.emit('event',{type:'transcriptFinal',sessionId:f.session.id,utteranceId:id,text:`Speech ${id}`,startMs:0,endMs:1500,sourceLanguage,languageDetection:{confidence,uncertain,...(uncertain?{reason:'low_confidence'}:{})}});
}

test('Auto language is immutable per queued phrase through previews and out-of-order completion',async t=>{
 const f=fixture(t);f.session.paused=false;f.session.speechLanguageMode='auto';
 const jobs:Array<{request:any;options:any;resolve:(value:any)=>void}>=[];
 f.setTranslate((_id,request,_timeout,options)=>new Promise(resolve=>jobs.push({request,options,resolve})));
 detectedSpeech(f,'polish','pl');detectedSpeech(f,'japanese','ja');detectedSpeech(f,'queued-polish','pl');
 assert.deepEqual(jobs.map(j=>j.request.sourceLanguage),['pl','ja']);
 jobs[1]!.options.onPreview('Japanese preview',{firstTextMs:2,translationMs:3});jobs[1]!.resolve({text:'Japanese complete',elapsedMs:5});await turn();
 assert.deepEqual(jobs.map(j=>j.request.sourceLanguage),['pl','ja','pl']);
 jobs[2]!.resolve({text:'Queued Polish',elapsedMs:6});jobs[0]!.resolve({text:'Polish',elapsedMs:7});await turn();
 const captions=f.events.poll(0).events.filter(x=>x.type==='caption');
 for(const c of captions){assert.equal(c.sourceLanguage,c.utteranceId==='japanese'?'ja':'pl');assert.equal(c.languageDetection?.confidence,.95);}
});

test('Auto bypasses confidently detected target language but translates uncertain target-language guesses',async t=>{
 const f=fixture(t);f.session.paused=false;f.session.speechLanguageMode='auto';f.session.mode='chatgpt';
 detectedSpeech(f,'english','en');await turn();assert.equal(f.translations(),0);
 assert.equal(f.events.poll(0).events.at(-1)?.translationState,'complete');
 detectedSpeech(f,'maybe-english','en',true,.4);await turn();assert.equal(f.translations(),1);
 assert.equal(f.events.poll(0).events.find(x=>x.utteranceId==='maybe-english')?.languageDetection?.uncertain,true);
});

test('Auto retains original speech with an actionable error when language metadata is invalid',async t=>{
 const f=fixture(t);f.session.paused=false;f.session.speechLanguageMode='auto';
 detectedSpeech(f,'bad','../../invalid');detectedSpeech(f,'nan','en',false,NaN);await turn();
 assert.equal(f.translations(),0);
 const failed=f.events.poll(0).events.filter(x=>x.translationState==='failed');
 assert.equal(failed.length,2);assert.ok(failed.every(x=>x.text?.startsWith('Speech ')&&x.error?.code==='LANGUAGE_UNAVAILABLE'));
});

test('Auto missing offline language pair retains original and continues listening',async t=>{
 const f=fixture(t);f.session.paused=false;f.session.speechLanguageMode='auto';
 f.setTranslate(async()=>{throw new ProtocolError('PAIR_NOT_INSTALLED','internal');});
 detectedSpeech(f,'polish','pl');await turn();
 const failed=f.events.poll(0).events.find(x=>x.translationState==='failed');
 assert.equal(failed?.sourceLanguage,'pl');assert.match(failed?.error?.message??'',/pl → en/);
 assert.equal(failed?.text,'Speech polish');assert.equal(f.session.paused,false);
});

test('Auto start uses saved detection settings and rejects unsupported hint languages before capture',async t=>{
 const f=fixture(t);f.state.session=undefined;f.settings.speechLanguageMode='auto';f.settings.expectedLanguages=['pl','en'];
 f.pipeline.sources=async()=>[{pid:10,name:'Discord test'}];
 await f.pipeline.start({pid:10,channelId:'channel',sourceLanguage:'ja',targetLanguage:'en',mode:'local'});
 const start=f.calls.find(x=>x.type==='start');assert.equal(start?.params.speechLanguageMode,'auto');assert.deepEqual(start?.params.expectedLanguages,['pl','en']);
 assert.equal(f.pipeline.status().speechLanguageMode,'auto');await f.pipeline.stop();
 f.settings.expectedLanguages=['xx'];
 await assert.rejects(f.pipeline.start({pid:10,channelId:'channel',sourceLanguage:'ja',targetLanguage:'en',mode:'local'}),{code:'LANGUAGE_UNSUPPORTED'});
 assert.equal(f.captureStarts(),1);
});

test('Auto mode requires plan consent even when the manual text pair matches',async t=>{
 const f=fixture(t);f.state.session=undefined;f.settings.speechLanguageMode='auto';
 (f.pipeline as any).canUsePlan=async()=>false;
 await assert.rejects(f.pipeline.start({pid:10,channelId:'channel',sourceLanguage:'en',targetLanguage:'en',mode:'chatgpt'}),{code:'SIGN_IN_REQUIRED'});
 assert.equal(f.captureStarts(),0);assert.equal(f.calls.some(c=>c.type==='start'),false);
});

interface PendingTranslation {id:string;request:any;options:any;resolve:(value:any)=>void;reject:(error:Error)=>void;diagnostics:DraftDiagnosticEvent[]}
function liveFixture(t:TestContext){
 const f=fixture(t);f.session.paused=false;f.session.mode='chatgpt';f.session.latencyMode='live';
 const jobs:PendingTranslation[]=[];
 f.setTranslate((id,request,_timeout,options)=>new Promise((resolve,reject)=>{
  const job:PendingTranslation={id,request,options,resolve,reject,diagnostics:[]};
  options.onDraftDiagnostic?.((event:DraftDiagnosticEvent)=>{if(!job.diagnostics.includes(event))job.diagnostics.push(event);});jobs.push(job);
 }));
 return {...f,jobs};
}
function transcript(f:ReturnType<typeof fixture>,type:'transcriptPartial'|'transcriptFinal',id:string,text:string,extra:Record<string,unknown>={}){
 f.local.emit('event',{type,sessionId:f.session.id,utteranceId:id,text,startMs:0,endMs:2400,timing:{recognitionMs:300,speechMs:2400},...extra});
}
function captions(f:ReturnType<typeof fixture>,id:string){return f.events.poll(0).events.filter(event=>event.type==='caption'&&event.utteranceId===id);}
const preview=(job:PendingTranslation,text='Early translation')=>job.options.onPreview(text,{firstTextMs:20,translationMs:25});

test('Live ChatGPT starts one early request and growing ASR partials keep it running with current source',async t=>{
 const f=liveFixture(t);
 transcript(f,'transcriptPartial','one','攻撃を開始');assert.equal(f.jobs.length,1);assert.equal(f.jobs[0]!.options.voicePhase,'draft');
 transcript(f,'transcriptPartial','one','攻撃を開始してください');
 assert.equal(f.jobs.length,1);assert.equal(f.cancellations.length,0);
 preview(f.jobs[0]!);let row=captions(f,'one').at(-1)!;
 assert.equal(row.text,'攻撃を開始してください');assert.equal(row.translated,'Early translation');assert.equal(row.provisional,true);assert.equal(row.translationState,'streaming');
 f.jobs[0]!.resolve({text:'Begin the attack',elapsedMs:30});await turn();
 transcript(f,'transcriptPartial','one','攻撃を開始してください 今');
 row=captions(f,'one').at(-1)!;assert.equal(row.translated,'Begin the attack');assert.equal(row.translationState,'streaming');assert.equal(f.jobs.length,1);
});

test('Early request needs enough speech, meaningful text, and reliable recognition',t=>{
 const f=liveFixture(t);
 transcript(f,'transcriptPartial','one','hello',{timing:{speechMs:1199}});
 transcript(f,'transcriptPartial','one','...!!!!');transcript(f,'transcriptPartial','one','abc');
 transcript(f,'transcriptPartial','one','hello',{uncertain:true});
 assert.equal(f.jobs.length,0);
 transcript(f,'transcriptPartial','one','hello');assert.equal(f.jobs.length,1);
});

test('Only one speculative request runs globally, busy partials can retry after capacity returns',async t=>{
 const f=liveFixture(t);
 transcript(f,'transcriptPartial','one','First sentence');transcript(f,'transcriptPartial','two','Second sentence');assert.equal(f.jobs.length,1);
 f.jobs[0]!.resolve({text:'First',elapsedMs:25});await turn();
 transcript(f,'transcriptPartial','two','Second sentence grows');assert.equal(f.jobs.length,2);
});

test('Corrections clear earlier translation immediately and reject stale callbacks without rerequesting',async t=>{
 const f=liveFixture(t);transcript(f,'transcriptPartial','one','Attack this target');preview(f.jobs[0]!);
 transcript(f,'transcriptPartial','one','Do not attack this target');
 let row=captions(f,'one').at(-1)!;assert.equal(row.translated,'');assert.equal(row.translationState,'pending');assert.equal(row.timing?.firstTextMs,undefined);
 assert.deepEqual(f.cancellations,[f.jobs[0]!.id]);const count=captions(f,'one').length;
 preview(f.jobs[0]!,'Stale attack');f.jobs[0]!.resolve({text:'Stale final',elapsedMs:30});await turn();
 assert.equal(captions(f,'one').length,count);
 transcript(f,'transcriptPartial','one','Do not attack this target now');assert.equal(f.jobs.length,1);
 transcript(f,'transcriptFinal','one','Do not attack this target now');assert.equal(f.jobs.length,2);assert.equal(f.jobs[1]!.options.voicePhase,'final');
});

test('A detected language change or uncertain language clears the old draft',async t=>{
 for(const next of [{sourceLanguage:'pl',languageDetection:{confidence:.95,uncertain:false}},{sourceLanguage:'ja',languageDetection:{confidence:.4,uncertain:true,reason:'low_confidence'}}]){
  const f=liveFixture(t);f.session.speechLanguageMode='auto';
  transcript(f,'transcriptPartial','one','Some speech',{sourceLanguage:'ja',languageDetection:{confidence:.95,uncertain:false}});preview(f.jobs[0]!);
  transcript(f,'transcriptPartial','one','Some speech continues',next);
  const row=captions(f,'one').at(-1)!;assert.equal(row.translated,'');assert.equal(row.sourceLanguage,next.sourceLanguage);assert.equal(f.cancellations.length,1);
  preview(f.jobs[0]!,'Late wrong language');f.jobs[0]!.resolve({text:'Late wrong language',elapsedMs:40});await turn();assert.equal(captions(f,'one').at(-1)?.translated,'');
 }
});

test('A completed exact draft is finalized without another translation request',async t=>{
 const f=liveFixture(t);transcript(f,'transcriptPartial','one','Hold position');preview(f.jobs[0]!,'Hold here');
 f.jobs[0]!.resolve({text:'Hold position',elapsedMs:30});await turn();
 transcript(f,'transcriptFinal','one','  Hold   position  ');
 const row=captions(f,'one').at(-1)!;assert.equal(f.jobs.length,1);assert.equal(row.provisional,false);assert.equal(row.translationState,'complete');assert.equal(row.text,'  Hold   position  ');assert.equal(row.translated,'Hold position');assert.equal(row.timing?.translationMs,30);assert.ok(typeof row.timing?.draftLeadMs==='number');
});

test('An exact final adopts a running draft and later output becomes final source text',async t=>{
 const f=liveFixture(t);transcript(f,'transcriptPartial','one','Hold position');preview(f.jobs[0]!,'Hold');
 transcript(f,'transcriptFinal','one','Hold position');assert.equal(f.jobs.length,1);assert.equal(captions(f,'one').at(-1)?.provisional,false);
 preview(f.jobs[0]!,'Hold position');assert.equal(captions(f,'one').at(-1)?.provisional,false);
 f.jobs[0]!.resolve({text:'Hold position',elapsedMs:35});await turn();assert.equal(captions(f,'one').at(-1)?.translationState,'complete');
});

test('An extended final clears early text until its full translation replaces it',async t=>{
 const f=liveFixture(t);transcript(f,'transcriptPartial','one','Hold position');preview(f.jobs[0]!,'Hold here');
 transcript(f,'transcriptFinal','one','Hold position and wait');assert.equal(f.jobs.length,2);
 let row=captions(f,'one').at(-1)!;assert.equal(row.provisional,false);assert.equal(row.translationState,'pending');assert.equal(row.translated,'');assert.ok(typeof row.timing?.draftLeadMs==='number');assert.equal(row.timing?.firstTextMs,undefined);
 assert.equal(f.cancellations.length,1);
 preview(f.jobs[0]!,'Late old response');f.jobs[0]!.resolve({text:'Old result',elapsedMs:50});await turn();
 assert.equal((f.pipeline as any).translating.size,1);assert.equal(captions(f,'one').at(-1)?.translated,'');
 preview(f.jobs[1]!,'Hold here and wait');f.jobs[1]!.resolve({text:'Hold here and wait',elapsedMs:40});await turn();
 row=captions(f,'one').at(-1)!;assert.equal(row.translated,'Hold here and wait');assert.equal(row.translationState,'complete');
});

test('Finals preempt an unrelated draft at the two-slot limit and late abort cannot release newer work',async t=>{
 const f=liveFixture(t);speech(f,'final-one');transcript(f,'transcriptPartial','draft','Keep the fleet together');preview(f.jobs[1]!);
 speech(f,'final-two');assert.equal(f.jobs.length,3);assert.deepEqual(f.cancellations,[f.jobs[1]!.id]);
 assert.equal(captions(f,'draft').at(-1)?.translated,'');assert.equal((f.pipeline as any).translating.size,2);
 transcript(f,'transcriptPartial','draft','Keep the fleet together now');assert.equal(f.jobs.length,3);
 preview(f.jobs[1]!,'Stale preempted');f.jobs[1]!.reject(new Error('late abort'));await turn();assert.equal((f.pipeline as any).translating.size,2);assert.equal(f.session.paused,false);
 speech(f,'final-three');assert.equal(f.jobs.length,3);
 f.jobs[0]!.resolve({text:'Done',elapsedMs:20});await turn();assert.equal(f.jobs.length,4);
});

test('Busy final slots prevent draft requests until a later partial finds capacity',async t=>{
 const f=liveFixture(t);speech(f,'one');speech(f,'two');speech(f,'three');
 transcript(f,'transcriptPartial','draft','Meaningful early speech');assert.equal(f.jobs.length,2);
 f.jobs[0]!.resolve({text:'One',elapsedMs:25});await turn();assert.equal(f.jobs.length,3);
 transcript(f,'transcriptPartial','draft','Meaningful early speech grows');assert.equal(f.jobs.length,3);
 f.jobs[1]!.resolve({text:'Two',elapsedMs:25});await turn();
 transcript(f,'transcriptPartial','draft','Meaningful early speech grows more');assert.equal(f.jobs.length,4);assert.equal(f.jobs[3]!.options.voicePhase,'draft');
});

test('A speculative failure clears its draft without pausing and final translation still works',async t=>{
 const f=liveFixture(t);transcript(f,'transcriptPartial','one','Start moving now');preview(f.jobs[0]!);
 f.jobs[0]!.reject(new ProtocolError('SYNTHETIC_FAILURE','private details'));await turn();
 assert.equal(f.session.paused,false);assert.equal(captions(f,'one').at(-1)?.translated,'');assert.equal(f.events.poll(0).events.some(e=>e.type==='error'),false);
 transcript(f,'transcriptPartial','one','Start moving now please');assert.equal(f.jobs.length,1);
 transcript(f,'transcriptFinal','one','Start moving now please');f.jobs[1]!.resolve({text:'Move now',elapsedMs:20});await turn();assert.equal(captions(f,'one').at(-1)?.translationState,'complete');
});

test('An adopted request failure follows final error behavior and pauses ChatGPT captions',async t=>{
 const f=liveFixture(t);transcript(f,'transcriptPartial','one','Start moving now');transcript(f,'transcriptFinal','one','Start moving now');
 f.jobs[0]!.reject(new ProtocolError('SYNTHETIC_FAILURE','private details'));await turn();
 assert.equal(f.session.paused,true);assert.equal(captions(f,'one').at(-1)?.translationState,'failed');assert.equal(captions(f,'one').at(-1)?.translated,'');
 assert.doesNotMatch(JSON.stringify(f.events.poll(0)),/private details/);
});

test('Pause and stop invalidate speculative output immediately and ignore late completion',async t=>{
 for(const action of ['pause','stop'] as const){
  const f=liveFixture(t);transcript(f,'transcriptPartial','one','Start moving now');preview(f.jobs[0]!);
  if(action==='pause')await f.pipeline.pause(true);else await f.pipeline.stop();
  const count=f.events.poll(0).events.length;preview(f.jobs[0]!,'Late draft');f.jobs[0]!.resolve({text:'Late complete',elapsedMs:50});await turn();
  assert.equal(f.events.poll(0).events.length,count);assert.equal((f.pipeline as any).drafts.size,0);assert.equal((f.pipeline as any).activeDraft,undefined);
  if(action==='pause')assert.equal(captions(f,'one').at(-1)?.translated,'');
 }
});

test('Worker gaps discard unfinished drafts while allowing final jobs to continue',async t=>{
 for(const type of ['audioGap']){
  const f=liveFixture(t);speech(f,'final');transcript(f,'transcriptPartial','draft','Start moving now');preview(f.jobs[1]!);
  f.local.emit('event',{type,sessionId:f.session.id});assert.equal(captions(f,'draft').at(-1)?.translated,'');assert.deepEqual(f.cancellations,[f.jobs[1]!.id]);
  transcript(f,'transcriptPartial','draft','Start moving now again');transcript(f,'transcriptFinal','draft','Start moving now again');assert.equal(f.jobs.length,2);
  preview(f.jobs[1]!,'Late draft');f.jobs[1]!.resolve({text:'Late result',elapsedMs:40});f.jobs[0]!.resolve({text:'Final succeeds',elapsedMs:40});await turn();
  assert.equal(captions(f,'final').at(-1)?.translationState,'complete');assert.equal(captions(f,'draft').at(-1)?.translated,'');assert.equal(f.session.paused,false);
 }
});

test('An orphaned speculative draft expires, clears its display and never starts again',async t=>{
 const f=liveFixture(t);transcript(f,'transcriptPartial','one','Start moving now');preview(f.jobs[0]!);
 const state=f.pipeline as any;state.drafts.get('one').request.time-=10001;state.pruneDrafts();
 assert.equal(state.drafts.size,0);assert.equal(state.translating.size,0);assert.equal(captions(f,'one').at(-1)?.translated,'');
 transcript(f,'transcriptPartial','one','Start moving now please');assert.equal(f.jobs.length,1);
 f.jobs[0]!.resolve({text:'Late',elapsedMs:10002});await turn();assert.equal(captions(f,'one').at(-1)?.translated,'');
});

test('Completed speculative records are bounded if the worker never finalizes utterances',async t=>{
 const f=liveFixture(t);
 for(let i=0;i<40;i++){
  transcript(f,'transcriptPartial',`orphan-${i}`,'Start moving now');f.jobs.at(-1)!.resolve({text:'Move',elapsedMs:20});await turn();
 }
 assert.equal((f.pipeline as any).drafts.size,32);assert.equal((f.pipeline as any).translating.size,0);assert.equal(captions(f,'orphan-7').at(-1)?.translated,'');
});

test('Balanced, offline, same-language, and uncertain auto captions never start early translations',t=>{
 for(const variant of ['balanced','local','same','uncertain-auto','invalid-auto']){
  const f=liveFixture(t);let extra={};
  if(variant==='balanced')f.session.latencyMode='balanced';if(variant==='local')f.session.mode='local';if(variant==='same')f.session.sourceLanguage='en';
  if(variant.endsWith('auto')){f.session.speechLanguageMode='auto';extra=variant==='uncertain-auto'?{sourceLanguage:'ja',languageDetection:{confidence:.4,uncertain:true}}:{sourceLanguage:'bad'};}
  transcript(f,'transcriptPartial','one','Some meaningful words',extra);assert.equal(f.jobs.length,0,variant);
 }
});


test('Worker overload clears a speculative draft but a later viable final still translates',async t=>{
 const f=liveFixture(t);transcript(f,'transcriptPartial','draft','Start moving now');preview(f.jobs[0]!);
 f.local.emit('event',{type:'overload',sessionId:f.session.id});assert.equal(captions(f,'draft').at(-1)?.translated,'');assert.deepEqual(f.cancellations,[f.jobs[0]!.id]);
 transcript(f,'transcriptPartial','draft','Start moving now please');assert.equal(f.jobs.length,1);
 transcript(f,'transcriptFinal','draft','Start moving now please');assert.equal(f.jobs.length,2);
 preview(f.jobs[0]!,'Stale overload result');f.jobs[0]!.resolve({text:'Stale',elapsedMs:30});await turn();assert.equal((f.pipeline as any).translating.size,1);
 f.jobs[1]!.resolve({text:'Move now please',elapsedMs:30});await turn();assert.equal(captions(f,'draft').at(-1)?.translationState,'complete');assert.equal(captions(f,'draft').at(-1)?.translated,'Move now please');
});


test('A word extension such as can to cannot invalidates a provisional translation immediately',async t=>{
 const f=liveFixture(t);transcript(f,'transcriptPartial','one','They can');preview(f.jobs[0]!,'They can');
 transcript(f,'transcriptPartial','one','They cannot attack');
 assert.equal(captions(f,'one').at(-1)?.translated,'');assert.equal(captions(f,'one').at(-1)?.translationState,'pending');assert.equal(f.cancellations.length,1);
 preview(f.jobs[0]!,'They can attack');f.jobs[0]!.resolve({text:'They can attack',elapsedMs:30});await turn();assert.equal(captions(f,'one').at(-1)?.translated,'');
 transcript(f,'transcriptFinal','one','They cannot attack');assert.equal(f.jobs.length,2);assert.equal(f.jobs[1]!.request.text,'They cannot attack');
});

test('A final Japanese negation never retains the earlier positive command while awaiting translation',async t=>{
 const f=liveFixture(t);transcript(f,'transcriptPartial','one','攻撃を開始');preview(f.jobs[0]!,'Begin the attack');
 transcript(f,'transcriptFinal','one','攻撃を開始しない');
 let row=captions(f,'one').at(-1)!;assert.equal(row.text,'攻撃を開始しない');assert.equal(row.translated,'');assert.equal(row.translationState,'pending');assert.equal(row.provisional,false);assert.ok(typeof row.timing?.draftLeadMs==='number');
 assert.equal(f.jobs.length,2);assert.equal(f.cancellations.length,1);
 preview(f.jobs[0]!,'Begin the attack now');f.jobs[0]!.resolve({text:'Begin the attack',elapsedMs:40});await turn();assert.equal(captions(f,'one').at(-1)?.translated,'');
 f.jobs[1]!.resolve({text:'Do not begin the attack',elapsedMs:45});await turn();row=captions(f,'one').at(-1)!;assert.equal(row.translated,'Do not begin the attack');assert.equal(row.translationState,'complete');
});


test('A declarative full stop disappearing in a partial retains the sole early request and records formatting',async t=>{
 const f=liveFixture(t);transcript(f,'transcriptPartial','one','Hold position.');
 transcript(f,'transcriptPartial','one','Hold position and wait');
 assert.equal(f.jobs.length,1);assert.equal(f.cancellations.length,0);assert.deepEqual(f.jobs[0]!.diagnostics,['formatting_retained']);
 preview(f.jobs[0]!,'Hold here');assert.equal(captions(f,'one').at(-1)?.text,'Hold position and wait');assert.equal(captions(f,'one').at(-1)?.translated,'Hold here');
 assert.equal(f.jobs[0]!.request.text,'Hold position.');
 f.jobs[0]!.resolve({text:'Hold here',elapsedMs:35});await turn();
 transcript(f,'transcriptPartial','one','Hold position and wait for the fleet');assert.equal(f.jobs.length,1);
 transcript(f,'transcriptFinal','one','Hold position and wait for the fleet');
 assert.equal(captions(f,'one').at(-1)?.translated,'');assert.equal(captions(f,'one').at(-1)?.translationState,'pending');assert.equal(f.jobs.length,2);
 assert.deepEqual(f.jobs[0]!.diagnostics,['formatting_retained','final_changed']);
 assert.ok(typeof captions(f,'one').at(-1)?.timing?.draftLeadMs==='number','formatting-tolerated early text still has an observed lead after final invalidation');
});

test('Changed finals remain exact even when a partial formatting comparison would tolerate them',t=>{
 for(const [draft,final] of [['Hold position.','Hold position'],['攻撃を開始。','攻撃を開始']]){
  const f=liveFixture(t);transcript(f,'transcriptPartial','one',draft!);preview(f.jobs[0]!);
  transcript(f,'transcriptFinal','one',final!);
  assert.equal(f.jobs.length,2);assert.equal(captions(f,'one').at(-1)?.translated,'');assert.equal(captions(f,'one').at(-1)?.translationState,'pending');
  assert.deepEqual(f.jobs[0]!.diagnostics,['final_changed']);
 }
});

test('Exact final reuse records lifecycle after both completed and still-running draft requests',async t=>{
 for(const completed of [false,true]){
  const f=liveFixture(t);transcript(f,'transcriptPartial','one','Hold position.');
  if(completed){f.jobs[0]!.resolve({text:'Hold here',elapsedMs:25});await turn();}
  transcript(f,'transcriptFinal','one','Hold position.');assert.equal(f.jobs.length,1);assert.deepEqual(f.jobs[0]!.diagnostics,['final_reused']);
 }
});

test('Draft invalidation diagnostics distinguish text, language, confidence and recognition causes before cancelling',t=>{
 const cases:Array<{reason:DraftDiagnosticEvent;change:(f:ReturnType<typeof liveFixture>)=>Record<string,unknown>;text?:string}>=[
  {reason:'source_revised',change:()=>({}),text:'Do not hold position'},
  {reason:'language_unavailable',change:f=>{f.session.speechLanguageMode='auto';return {sourceLanguage:'invalid'};}},
  {reason:'language_uncertain',change:f=>{f.session.speechLanguageMode='auto';return {sourceLanguage:'ja',languageDetection:{confidence:.3,uncertain:true}};}},
  {reason:'recognition_uncertain',change:()=>({uncertain:true})},
  {reason:'language_changed',change:f=>{f.session.speechLanguageMode='auto';return {sourceLanguage:'pl',languageDetection:{confidence:.95,uncertain:false}};}},
  {reason:'target_language',change:f=>{f.session.targetLanguage='ja';return {};}}
 ];
 for(const item of cases){
  const f=liveFixture(t);transcript(f,'transcriptPartial','one','Hold position');
  (f.pipeline as any).translator.cancel=()=>{assert.ok(f.jobs[0]!.diagnostics.includes(item.reason),'diagnostic must precede cancellation');};
  const extra=item.change(f);transcript(f,'transcriptPartial','one',item.text??'Hold position and wait',extra);
  assert.deepEqual(f.jobs[0]!.diagnostics,[item.reason]);assert.equal(captions(f,'one').at(-1)?.translated,item.reason==='target_language'?'Hold position and wait':'');
 }
});

test('Draft lifecycle records scheduling, gaps, errors, expiry and retained-record eviction',async t=>{
 {
  const f=liveFixture(t);speech(f,'final-one');transcript(f,'transcriptPartial','draft','Hold position');speech(f,'final-two');
  assert.deepEqual(f.jobs[1]!.diagnostics,['final_priority']);
 }
 for(const [type,reason] of [['audioGap','audio_gap'],['overload','overload']] as const){
  const f=liveFixture(t);transcript(f,'transcriptPartial','draft','Hold position');f.local.emit('event',{type,sessionId:f.session.id});assert.deepEqual(f.jobs[0]!.diagnostics,[reason]);
 }
 {
  const f=liveFixture(t);transcript(f,'transcriptPartial','draft','Hold position');f.jobs[0]!.reject(new ProtocolError('SYNTHETIC_FAILURE','private'));await turn();assert.deepEqual(f.jobs[0]!.diagnostics,['translation_error']);
 }
 {
  const f=liveFixture(t);transcript(f,'transcriptPartial','draft','Hold position');const state=f.pipeline as any;state.drafts.get('draft').request.time-=10001;state.pruneDrafts();assert.deepEqual(f.jobs[0]!.diagnostics,['expired']);
 }
 {
  const f=liveFixture(t);
  for(let i=0;i<33;i++){transcript(f,'transcriptPartial',`draft-${i}`,'Hold position');f.jobs.at(-1)!.resolve({text:'Hold here',elapsedMs:25});await turn();}
  assert.deepEqual(f.jobs[0]!.diagnostics,['capacity']);
 }
});

test('Pause and stop record all extant drafts including ones already adopted as final requests',async t=>{
 for(const action of ['pause','stop'] as const){
  const f=liveFixture(t);transcript(f,'transcriptPartial','adopted','Hold position');transcript(f,'transcriptFinal','adopted','Hold position');
  transcript(f,'transcriptPartial','draft','Start moving now');assert.equal(f.jobs.length,2);
  if(action==='pause')await f.pipeline.pause(true);else await f.pipeline.stop();
  const event=action==='pause'?'paused':'stopped';assert.deepEqual(f.jobs[0]!.diagnostics,['final_reused',event]);assert.deepEqual(f.jobs[1]!.diagnostics,[event]);
 }
});

test('Early drafts work when analysis does not admit a diagnostic recorder',async t=>{
 const f=liveFixture(t);let resolve:(value:any)=>void=()=>{};
 f.setTranslate((_id,_request,_timeout,_options)=>new Promise(done=>{resolve=done;}));
 transcript(f,'transcriptPartial','one','Hold position.');transcript(f,'transcriptPartial','one','Hold position and wait');
 resolve({text:'Hold here',elapsedMs:20});await turn();assert.equal(captions(f,'one').at(-1)?.translated,'Hold here');
 await f.pipeline.pause(true);assert.equal(captions(f,'one').at(-1)?.translated,'');
});


test('Final timing excludes early lead when the draft is empty or was already cleared',t=>{
 for(const state of ['never-shown','empty-preview','source-revised']){
  const f=liveFixture(t);transcript(f,'transcriptPartial','one','Hold position.');
  if(state!=='never-shown')preview(f.jobs[0]!,'Hold here');
  if(state==='empty-preview')preview(f.jobs[0]!,'');
  if(state==='source-revised')transcript(f,'transcriptPartial','one','Do not hold position');
  transcript(f,'transcriptFinal','one','Hold position and wait');
  const row=captions(f,'one').at(-1)!;assert.equal(row.timing?.draftLeadMs,undefined,state);assert.equal(row.translated,'');assert.equal(row.translationState,'pending');
 }
});

test('Capture identity survives pause/resume while stale transcript identity rotates',async t=>{
 const f=fixture(t);
 const previous=f.pipeline.status();
 await f.pipeline.pause(false);
 const resumed=f.pipeline.status();
 assert.equal(resumed.captureId,'capture-lifetime');
 assert.notEqual(resumed.sessionId,previous.sessionId);
 await f.pipeline.stop();
 assert.equal(f.pipeline.status().captureId,undefined);
});

test('Pause publishes its state before a slow worker-stop acknowledgement',async t=>{
 const f=fixture(t);f.session.paused=false;
 let release!:()=>void;
 f.setResponder(call=>call.type==='stop'?new Promise<void>(done=>{release=done;}):Promise.resolve({}));
 const pending=f.pipeline.pause(true);
 assert.equal(f.pipeline.status().paused,true);
 assert.ok(f.events.poll(0).events.some(event=>event.type==='status'&&event.text==='Captions paused.'));
 release();await pending;
});
