# Assembly audit

`build-shared-viewer-v1.py` is the release builder used to select the host payload and create the final archives. It requires the complete final source tree and exact earlier source snapshots named by its command-line arguments. The packaged baseline fixtures contain only files needed for the installer regression suite; they are not complete application source snapshots.

The builder rejects unexpected changed source files, emits an exact target allowlist into the installer, pins unchanged prerequisite files, and records SHA-256 before/after values in `manifest.json`. It packages compiled sharing code so the host patch needs no dependency installation. Runtime credentials, models, Node packages and the .NET SDK/cache are excluded.

From the extracted host patch, run the installer regressions without installing anything else:

```sh
node --test apply-sharing-v1.test.mjs
```

These use temporary directories and mocked Windows process results. They do not install the patch into the real application or prove native Windows process-query behaviour. `tests/source` preserves additional changed application tests for auditing; those run from the full source workspace with its development dependencies.
