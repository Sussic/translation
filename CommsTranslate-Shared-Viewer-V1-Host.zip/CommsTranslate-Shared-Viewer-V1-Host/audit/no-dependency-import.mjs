// Release gate: evaluate only the bundled service outside every workspace dependency tree.
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import {pathToFileURL} from 'node:url';
const source=process.argv[2];
if(!source)throw Error('Usage: node no-dependency-import.mjs path/to/dist/sharing/service.js');
const root=await fs.mkdtemp(path.join(os.tmpdir(),'comms-sharing-no-dependencies-'));
try{
 for(let directory=root;;directory=path.dirname(directory)){
  await assert.rejects(fs.access(path.join(directory,'node_modules')),undefined,'The clean probe must have no ancestor node_modules.');
  if(path.dirname(directory)===directory)break;
 }
 await fs.writeFile(path.join(root,'package.json'),' {"type":"module"}\n');
 await fs.copyFile(source,path.join(root,'service.js'));
 const {HostSharingService,parseHostConfiguration}=await import(pathToFileURL(path.join(root,'service.js')).href);
 assert.equal(typeof HostSharingService,'function');assert.equal(typeof parseHostConfiguration,'function');
 const configuration={format:'CommsTranslateHost',version:1,relayUrl:'https://relay.example.invalid',hostId:'A'.repeat(22),hostName:'Offline verification',publisherToken:'A'.repeat(43)};
 assert.deepEqual(parseHostConfiguration(JSON.stringify(configuration)),configuration);
 assert.throws(()=>parseHostConfiguration(JSON.stringify({...configuration,relayUrl:'http://relay.example.invalid'})));
 const service=new HostSharingService({storageDir:path.join(root,'private-state'),credentialEncryption:{id:'probe-only',isAvailable:()=>true,encrypt:()=>{throw Error('Unexpected secret write');},decrypt:()=>{throw Error('Unexpected secret read');}}});
 await service.initialize();assert.equal(service.getStatus().configured,false);await service.close();
 console.log('PASS: isolated bundled service import, public configuration parser, and unconfigured startup/close without node_modules.');
}finally{await fs.rm(root,{recursive:true,force:true});}
