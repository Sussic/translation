#!/usr/bin/env python3
"""Assemble the prebuilt Sharing V1 host patch; never installs or launches anything.

Run only after application owners finish builds:
  python verification/build-shared-viewer-v1.py
  node --test shared-viewer-v1-package/host/apply-sharing-v1.test.mjs

Then use --archives to produce release ZIPs from already-verified artifacts.
SDK/toolchain caches, credentials, models, and node_modules are never archived.
"""
from pathlib import Path
import argparse
import hashlib
import json
import re
import shutil
import zipfile

BASE = Path(__file__).resolve().parents[1]
p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--source', type=Path, default=BASE/'recovered/comms-translate')
p.add_argument('--baseline', type=Path, default=BASE/'recovered/shared-v1-before')
p.add_argument('--baseline-no-c1', type=Path, default=BASE/'recovered/controls-c1-before')
p.add_argument('--output', type=Path, default=BASE/'shared-viewer-v1-package/host')
p.add_argument('--archives', action='store_true')
p.add_argument('--source-archive', action='store_true')
p.add_argument('--viewer-publish', type=Path, default=BASE/'shared-viewer-v1-package/build/CommsViewer-win-x64')
p.add_argument('--relay-release', type=Path, default=BASE/'shared-viewer-v1-package/relay')
a = p.parse_args()
source, baseline, output = a.source.resolve(), a.baseline.resolve(), a.output.resolve()
no_c1=a.baseline_no_c1.resolve()
if len({source,baseline,output}) != 3 or any(x in y.parents for x in (source,baseline,output) for y in (source,baseline,output) if x != y):
    raise SystemExit('Source, baseline and output must be separate non-nested directories.')

def sha(data): return hashlib.sha256(data).hexdigest()
def read(root, rel):
    file=root/rel
    if file.is_symlink(): raise SystemExit('Linked input refused: '+str(file))
    return file.read_bytes() if file.is_file() else None

def audit(rel):
    return ('.test.' in rel or rel.endswith(('/dom-smoke.mjs','/browser-smoke.mjs','/MANUAL-QA.md'))
            or '/__pycache__/' in rel or rel.endswith('.pyc'))

def ts_paths(rel):
    stem=rel.replace('/src/','/dist/')[:-3]
    return {rel,*(stem+suffix for suffix in ['.js','.js.map','.d.ts','.d.ts.map'])}

ALLOW = {
    'package.json','package-lock.json','packages/companion/package.json',
    'packages/companion/scripts/build-ui.mjs','packages/companion/dist/preload.cjs',
    'packages/companion/dist/core/service.d.ts',
    'packages/companion/ui/index.html','packages/companion/ui/styles.css',
    'packages/companion/ui/sharing-ui.js','scripts/runtime-checks.mjs',
    'docs/SHARING-PROTOCOL-V1.md','docs/SHARED-VIEWER-V1-DESIGN.md',
    'docs/SHARED-VIEWER-V1.md','docs/CommsTranslate-Shared-Viewer-V1-Design.md',
}
for rel in ['packages/companion/src/main.ts','packages/companion/src/preload.ts','packages/companion/src/core/sharingUi.ts','packages/companion/src/core/voice.ts']:
    ALLOW.update(ts_paths(rel))
# These are new, owned feature directories. Expand only source/declaration/map,
# package metadata, deployment text and documentation into exact fixed paths.
NEW_FEATURES=['packages/companion/src/sharing','packages/sharing-protocol','packages/relay']
for directory in NEW_FEATURES:
    for file in (source/directory).rglob('*'):
        if not file.is_file(): continue
        rel=file.relative_to(source).as_posix()
        if any(part in ['node_modules','bin','obj'] for part in file.relative_to(source).parts) or (audit(rel) and directory=='packages/companion/src/sharing'): continue
        local=file.relative_to(source/directory)
        if directory != 'packages/companion/src/sharing' and len(local.parts)>1 and local.parts[0] not in {'src','dist','deploy','fixtures'}:raise SystemExit('Unexpected feature subdirectory: '+rel)
        if len(local.parts)==1 and directory != 'packages/companion/src/sharing' and file.name not in {'package.json','tsconfig.json','README.md','LICENSE'}:raise SystemExit('Unexpected feature root file: '+rel)
        if file.suffix not in ['.ts','.js','.map','.json','.md','.yaml','.yml','.mjs','.cjs','.txt'] and file.name not in ['Dockerfile','Caddyfile','LICENSE']: raise SystemExit('Review unexpected feature artifact: '+rel)
        ALLOW.add(rel)
        if rel.startswith('packages/companion/src/sharing/'):
            if file.suffix!='.ts':raise SystemExit('Unexpected host sharing file: '+rel)
            ALLOW.update(ts_paths(rel))
ALLOW.add('packages/companion/dist/sharing/service.js')
ALLOW.add('packages/companion/dist/sharing/service.js.LEGAL.txt')

SCAN=['packages/companion/src','packages/companion/dist','packages/companion/ui','packages/companion/scripts',
      'packages/shared/src','packages/shared/dist','packages/sharing-protocol','packages/relay',
      'packages/vencord-plugin','vendor/siwc-local/src','vendor/siwc-local/dist','workers/local','scripts']
observed=set(ALLOW)
for directory in SCAN:
    for root in [baseline,source]:
        for file in (root/directory).rglob('*'):
            if file.is_file() and not any(part in ['node_modules','__pycache__'] for part in file.relative_to(root).parts):observed.add(file.relative_to(root).as_posix())
unexpected=[rel for rel in sorted(observed) if rel not in ALLOW and not audit(rel) and read(source,rel)!=read(baseline,rel)]
if unexpected:raise SystemExit('Review and explicitly allow unexpected changes:\n'+'\n'.join(unexpected))
changed=[rel for rel in sorted(ALLOW) if read(source,rel)!=read(baseline,rel)]
if any(read(source,rel) is None for rel in changed):raise SystemExit('This patch does not delete source/runtime files.')
required=['packages/companion/src/core/sharingUi.ts','packages/companion/dist/core/sharingUi.js',
          'packages/companion/src/sharing/service.ts','packages/companion/dist/sharing/service.js',
          'packages/companion/dist/main.js','packages/companion/dist/preload.cjs',
          'packages/companion/ui/sharing-ui.js','packages/sharing-protocol/src/index.ts']
for rel in required:
    if rel not in changed or not read(source,rel):raise SystemExit('Complete built feature missing: '+rel)
# The changed main/preload must still import the bundled service and expose sharing.
if 'sharing/service' not in read(source,'packages/companion/dist/main.js').decode():raise SystemExit('Compiled main lacks Sharing V1 service wiring.')
if b'sharing' not in read(source,'packages/companion/dist/preload.cjs'):raise SystemExit('Compiled preload lacks Sharing V1 IPC.')

PINS=[
    'packages/companion/dist/core/translation.js',
    'packages/companion/dist/core/translationDiagnostics.js','packages/companion/dist/core/draftMatching.js',
    'packages/companion/dist/core/service.js','packages/companion/dist/core/startup.js','packages/companion/dist/core/accountStatus.js',
    'packages/companion/dist/core/events.js','packages/companion/ui/live-state.js','packages/companion/ui/overlay.js',
    'packages/shared/dist/index.js','packages/shared/dist/bridgeProtection.js','packages/shared/dist/bridgeProtectionProcess.js','packages/shared/dist/bridgeProtectionPublisher.js',
    'workers/local/worker.py','workers/local/backends.py','workers/local/cuda_runtime.py','workers/local/language_detection.py',
    'vendor/siwc-local/dist/index.js','vendor/siwc-local/dist/responses.js',
]
pins=[]
for rel in PINS:
    if rel in changed:raise SystemExit('Fixed prerequisite became target; review: '+rel)
    current=read(source,rel)
    if not current or current!=read(baseline,rel) or current!=read(no_c1,rel):raise SystemExit('Required unchanged baseline pin differs: '+rel)
    pins.append({'path':rel,'sha256':sha(current)})
manifest={'revision':'SHARING_V1','requires':'CommsTranslate T4 + S1 (Caption Controls C1 optional)','files':[]}
for rel in changed:
    before,after=read(baseline,rel),read(source,rel)
    previous=[before,read(no_c1,rel)]
    entry={'path':rel,'beforeSha256':list(dict.fromkeys(sha(value) for value in previous if value is not None)),'afterSha256':sha(after)}
    if any(value is None for value in previous) or rel.endswith(('.map','.d.ts','/preload.js')):entry['optionalBefore']=True
    manifest['files'].append(entry)
installer=output/'apply-sharing-v1.mjs'
text=installer.read_text()
text,n=re.subn(r'export const FILES = Object.freeze\(\[[\s\S]*?\]\);','export const FILES = Object.freeze('+json.dumps(changed,indent=4)+');',text,count=1)
text,m=re.subn(r'export const PREREQUISITES = Object.freeze\(\[[\s\S]*?\]\);','export const PREREQUISITES = Object.freeze('+json.dumps(pins,indent=4)+');',text,count=1)
if (n,m)!=(1,1):raise SystemExit('Installer fixed-list anchors missing.')
for folder in ['payload','tests/baseline','tests/baseline-no-c1','tests/prerequisites','tests/source']:
    shutil.rmtree(output/folder,ignore_errors=True);(output/folder).mkdir(parents=True)
def copy(root,rel,dest):
    target=dest/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(root/rel,target)
for rel in changed:
    copy(source,rel,output/'payload')
    if read(baseline,rel) is not None:copy(baseline,rel,output/'tests/baseline')
    if read(no_c1,rel) is not None:copy(no_c1,rel,output/'tests/baseline-no-c1')
for pin in pins:
    copy(baseline,pin['path'],output/'tests/baseline');copy(baseline,pin['path'],output/'tests/prerequisites');copy(no_c1,pin['path'],output/'tests/baseline-no-c1')
for rel in ['package.json','packages/companion/package.json','Start-CommsTranslate.cmd']:
    if read(baseline,rel) is not None:copy(baseline,rel,output/'tests/baseline')
    if read(no_c1,rel) is not None:copy(no_c1,rel,output/'tests/baseline-no-c1')
for directory in SCAN:
    for file in (source/directory).rglob('*'):
        if not file.is_file():continue
        rel=file.relative_to(source).as_posix()
        if audit(rel) and not rel.endswith('.pyc') and read(source,rel)!=read(baseline,rel):copy(source,rel,output/'tests/source')
installer.write_text(text)
(output/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(output/'assembly-targets.json').write_text(json.dumps({'baseline':str(baseline),'baselineWithoutC1':str(no_c1),'source':str(source),'files':changed,'prerequisites':pins},indent=2)+'\n')
(output/'audit').mkdir(exist_ok=True);shutil.copy2(Path(__file__),output/'audit/build-shared-viewer-v1.py')
(output/'audit/licenses').mkdir(exist_ok=True)
ws=source/'node_modules/ws/LICENSE'
if json.loads((source/'node_modules/ws/package.json').read_text()).get('version')!='8.22.0':raise SystemExit('Expected pinned ws 8.22.0 for bundled-runtime provenance.')
if not ws.is_file():raise SystemExit('Bundled ws license missing.')
shutil.copy2(ws,output/'audit/licenses/ws-LICENSE.txt')
print(f'Host assembled: {len(changed)} exact targets; {len(pins)} unchanged prerequisites. No archive created.' if not a.archives else f'Host assembled: {len(changed)} targets.')

if a.archives:
    validation_path=BASE/'shared-viewer-v1-package/validation-summary.json'
    validation=json.loads(validation_path.read_text())
    if validation.get('releaseChecksComplete') is not True:raise SystemExit('Record completed release checks before archiving.')
    import_gate=next(check for check in validation['checks'] if check['id']=='host-bundle-without-node-modules')
    installer_gate=next(check for check in validation['checks'] if check['id']=='host-installer-real-payload')
    if import_gate.get('bundleSHA256')!=sha(read(source,'packages/companion/dist/sharing/service.js')):raise SystemExit('Host bundle changed since isolated no-dependency import verification.')
    if installer_gate.get('manifestSHA256')!=sha((output/'manifest.json').read_bytes()):raise SystemExit('Payload changed since installer regression verification.')
    shutil.copy2(validation_path,output/'validation-summary.json')
    # Complete standalone Docker build context; no live registry or private setup files.
    relay=a.relay_release.resolve()
    if relay==source or source in relay.parents:raise SystemExit('Relay staging must be outside source.')
    shutil.rmtree(relay,ignore_errors=True);relay.mkdir(parents=True)
    for rel in ['package.json','package-lock.json','tsconfig.base.json','LICENSE',
                'packages/companion/package.json','packages/shared/package.json','vendor/siwc-local/package.json']:
        copy(source,rel,relay)
    for directory in ['packages/relay','packages/sharing-protocol']:
        for file in (source/directory).rglob('*'):
            if not file.is_file():continue
            rel=file.relative_to(source).as_posix()
            if any(part in ['node_modules','bin','obj'] for part in file.relative_to(source).parts):continue
            if file.suffix not in ['.ts','.js','.map','.json','.md','.yaml','.yml','.mjs','.cjs','.txt'] and file.name not in ['Dockerfile','Caddyfile','LICENSE']:raise SystemExit('Unexpected relay release file: '+rel)
            copy(source,rel,relay)
    shutil.copy2(source/'packages/relay/README.md',relay/'README.md')
    (relay/'licenses').mkdir();shutil.copy2(ws,relay/'licenses/ws-LICENSE.txt')
    viewer=a.viewer_publish.resolve()
    if not (viewer/'CommsViewer.exe').is_file():raise SystemExit('Native viewer publish is missing CommsViewer.exe.')
    viewer_validation=next(check for check in validation['checks'] if check['id']=='viewer-self-contained-win-x64-publish')
    for name,expected in viewer_validation['dllSHA256'].items():
        if sha((viewer/name).read_bytes())!=expected:raise SystemExit('Viewer changed since validation: '+name)
    shutil.copy2(source/'viewer/README.md',viewer/'README.md');shutil.copy2(source/'LICENSE',viewer/'LICENSE.txt')
    (viewer/'licenses').mkdir(exist_ok=True)
    cache=BASE/'shared-viewer-v1-package/toolchain/nuget'
    for component in ['microsoft.netcore.app.runtime.win-x64','microsoft.windowsdesktop.app.runtime.win-x64']:
        versions=sorted((cache/component).iterdir())
        if len(versions)!=1:raise SystemExit('Review runtime-license version selection for '+component)
        for file in versions[0].iterdir():
            if file.is_file() and ('LICENSE' in file.name.upper() or 'NOTICE' in file.name.upper()):shutil.copy2(file,viewer/'licenses'/(component+'-'+file.name+'.txt'))
    shutil.copy2(BASE/'shared-viewer-v1-package/toolchain/sdk-provenance.json',viewer/'BUILD-SDK-PROVENANCE.json')
    release=BASE/'shared-viewer-v1-package/releases';release.mkdir(exist_ok=True)
    def archive(root,label,exclude=()):
        destination=release/(label+'.zip')
        with zipfile.ZipFile(destination,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
            for file in sorted(root.rglob('*')):
                if not file.is_file() or any(part in exclude for part in file.relative_to(root).parts):continue
                if file.is_symlink():raise SystemExit('Linked release artifact refused: '+str(file))
                z.write(file,label+'/'+file.relative_to(root).as_posix())
        print(destination)
    archive(output,'CommsTranslate-Shared-Viewer-V1-Host',('diagnostics',))
    viewer=a.viewer_publish.resolve()
    if not (viewer/'CommsViewer.exe').is_file():raise SystemExit('Native viewer publish is missing CommsViewer.exe.')
    archive(viewer,'CommsTranslate-Viewer-V1-win-x64')
    relay=a.relay_release.resolve()
    if not (relay/'README.md').is_file():raise SystemExit('Verified relay release staging is incomplete.')
    archive(relay,'CommsTranslate-Relay-V1')
    if a.source_archive:
        destination=release/'CommsTranslate-Shared-Viewer-V1-Source.zip'
        excluded={'node_modules','bin','obj','build','.venv','release','.validation','__pycache__','.git','diagnostics'}
        allowed_roots={'docs','packages','scripts','vendor','viewer','workers','data'}
        with zipfile.ZipFile(destination,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
            records=[]
            for file in sorted(source.rglob('*')):
                if not file.is_file():continue
                rel=file.relative_to(source)
                if any(part in excluded or part.endswith('-backups') for part in rel.parts):continue
                if len(rel.parts)>1 and rel.parts[0] not in allowed_roots:continue
                if file.suffix in ['.log','.pyc','.sqlite','.db','.commshost','.commsviewer'] or file.name.startswith('.env') or file.name=='SOURCE-MANIFEST.sha256':continue
                if file.is_symlink():raise SystemExit('Linked source artifact refused: '+str(file))
                z.write(file,'comms-translate/'+rel.as_posix());records.append(sha(file.read_bytes())+'  '+rel.as_posix())
            z.writestr('comms-translate/SOURCE-MANIFEST.sha256','\n'.join(records)+'\n')
        print(destination)
    guide=BASE/'shared-viewer-v1-package/CommsTranslate-Shared-Viewer-V1-Start-Here.md'
    shutil.copy2(guide,release/guide.name)
    shutil.copy2(validation_path,release/'validation-summary.json')
    sums=[]
    for file in sorted([*release.glob('CommsTranslate-*.zip'),release/guide.name,release/'validation-summary.json']):
        sums.append(sha(file.read_bytes())+'  '+file.name)
    (release/'SHA256SUMS.txt').write_text('\n'.join(sums)+'\n')
