// Guarded, prebuilt host patch. No dependency installer, build command, or Vencord mutation.
import {promises as fs} from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import {randomUUID} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {execFile} from 'node:child_process';
import {fail,digest,samePath,within,exists,readBounded,jsonFile,noLinks,inventory,identical,atomicWrite,safeText,safeReportJson,Transaction} from './transaction.mjs';

const here=path.dirname(fileURLToPath(import.meta.url));
export const FILES = Object.freeze([
    "docs/CommsTranslate-Shared-Viewer-V1-Design.md",
    "docs/SHARED-VIEWER-V1.md",
    "docs/SHARING-PROTOCOL-V1.md",
    "package-lock.json",
    "package.json",
    "packages/companion/dist/core/service.d.ts",
    "packages/companion/dist/core/sharingUi.d.ts",
    "packages/companion/dist/core/sharingUi.js",
    "packages/companion/dist/core/sharingUi.js.map",
    "packages/companion/dist/core/voice.d.ts",
    "packages/companion/dist/core/voice.js",
    "packages/companion/dist/core/voice.js.map",
    "packages/companion/dist/main.js",
    "packages/companion/dist/main.js.map",
    "packages/companion/dist/preload.cjs",
    "packages/companion/dist/preload.js",
    "packages/companion/dist/preload.js.map",
    "packages/companion/dist/sharing/projection.d.ts",
    "packages/companion/dist/sharing/projection.js",
    "packages/companion/dist/sharing/projection.js.map",
    "packages/companion/dist/sharing/service.d.ts",
    "packages/companion/dist/sharing/service.js",
    "packages/companion/dist/sharing/service.js.map",
    "packages/companion/dist/sharing/storage.d.ts",
    "packages/companion/dist/sharing/storage.js",
    "packages/companion/dist/sharing/storage.js.map",
    "packages/companion/package.json",
    "packages/companion/scripts/build-ui.mjs",
    "packages/companion/src/core/sharingUi.ts",
    "packages/companion/src/core/voice.ts",
    "packages/companion/src/main.ts",
    "packages/companion/src/preload.ts",
    "packages/companion/src/sharing/projection.ts",
    "packages/companion/src/sharing/service.ts",
    "packages/companion/src/sharing/storage.ts",
    "packages/companion/ui/index.html",
    "packages/companion/ui/sharing-ui.js",
    "packages/companion/ui/styles.css",
    "packages/relay/README.md",
    "packages/relay/deploy/Caddyfile",
    "packages/relay/deploy/Dockerfile",
    "packages/relay/deploy/compose.yaml",
    "packages/relay/dist/cli.d.ts",
    "packages/relay/dist/cli.js",
    "packages/relay/dist/cli.js.map",
    "packages/relay/dist/registry.d.ts",
    "packages/relay/dist/registry.js",
    "packages/relay/dist/registry.js.map",
    "packages/relay/dist/registry.test.d.ts",
    "packages/relay/dist/registry.test.js",
    "packages/relay/dist/registry.test.js.map",
    "packages/relay/dist/server.d.ts",
    "packages/relay/dist/server.js",
    "packages/relay/dist/server.js.map",
    "packages/relay/dist/server.test.d.ts",
    "packages/relay/dist/server.test.js",
    "packages/relay/dist/server.test.js.map",
    "packages/relay/package.json",
    "packages/relay/src/cli.ts",
    "packages/relay/src/registry.test.ts",
    "packages/relay/src/registry.ts",
    "packages/relay/src/server.test.ts",
    "packages/relay/src/server.ts",
    "packages/relay/tsconfig.json",
    "packages/sharing-protocol/dist/index.d.ts",
    "packages/sharing-protocol/dist/index.js",
    "packages/sharing-protocol/dist/index.js.map",
    "packages/sharing-protocol/dist/index.test.d.ts",
    "packages/sharing-protocol/dist/index.test.js",
    "packages/sharing-protocol/dist/index.test.js.map",
    "packages/sharing-protocol/fixtures/v1-vectors.json",
    "packages/sharing-protocol/package.json",
    "packages/sharing-protocol/src/index.test.ts",
    "packages/sharing-protocol/src/index.ts",
    "packages/sharing-protocol/tsconfig.json",
    "scripts/runtime-checks.mjs"
]);
export const PREREQUISITES = Object.freeze([
    {
        "path": "packages/companion/dist/core/translation.js",
        "sha256": "4d26ff79d7a987c6b32ebf1953f73abd1ddf05016a2fb3d7c1abeee4f8ce9b7a"
    },
    {
        "path": "packages/companion/dist/core/translationDiagnostics.js",
        "sha256": "3ce2dfed5e75f439a9c8b226466b14b1ea4d96e94ca9876ea7ce202a3e3955a9"
    },
    {
        "path": "packages/companion/dist/core/draftMatching.js",
        "sha256": "857dec71e8081ee51c37a2be69e762f612e33a296fd322f8309cb012fe4047fc"
    },
    {
        "path": "packages/companion/dist/core/service.js",
        "sha256": "e3fb27f9459c0e94b2f3bd540190116b178869c79d710a55fd081c0b25a821ec"
    },
    {
        "path": "packages/companion/dist/core/startup.js",
        "sha256": "f900be6ae240a888dc3579821c3c12a116a85cd08f82aeb58f630211c7e98d07"
    },
    {
        "path": "packages/companion/dist/core/accountStatus.js",
        "sha256": "3f02e60c70b2e35ad9c56e87ba45e2fdab64984d3f0a77de5ba956c382d13f9a"
    },
    {
        "path": "packages/companion/dist/core/events.js",
        "sha256": "b980bf45eb9626c43d12d10032d4605882a64d39345dc1823e417205d7294ee8"
    },
    {
        "path": "packages/companion/ui/live-state.js",
        "sha256": "fb7da4b76a44ee74161b5d17c23c953fd5e0e791374c9062be02b74c4d5ab65d"
    },
    {
        "path": "packages/companion/ui/overlay.js",
        "sha256": "e44ab324181519049caf5134740a7304af4d0d89a3329de43fa9118e68a66405"
    },
    {
        "path": "packages/shared/dist/index.js",
        "sha256": "067795e5ec033471d6855f7e0da3f99b8834dd200122a35b48226d824e01a37d"
    },
    {
        "path": "packages/shared/dist/bridgeProtection.js",
        "sha256": "b1bb5886f61f885ef3e10f02c20e2d0582616d1d99b72f50afa645d3e7f10aba"
    },
    {
        "path": "packages/shared/dist/bridgeProtectionProcess.js",
        "sha256": "18ec40fac02d0b62cd3afad3ab95f379beafea4e4820734d09c737eba993aa4c"
    },
    {
        "path": "packages/shared/dist/bridgeProtectionPublisher.js",
        "sha256": "e367030d1992a05867339dbb6c1957b19582d538cc25e2d53cec690506564732"
    },
    {
        "path": "workers/local/worker.py",
        "sha256": "bd9b2e44f54e64d18b2371133b6ad4682e3737d42ab88bcb255514d42f8bdd8d"
    },
    {
        "path": "workers/local/backends.py",
        "sha256": "2775a6b6a7931aebcc7d87bce0ba2e68c102d9b39b4b4aea8cda571257449dda"
    },
    {
        "path": "workers/local/cuda_runtime.py",
        "sha256": "dd5b6a4b0614f20867423bd8fd771798231f3e34b8df983f5d2ed757bbfd9d7b"
    },
    {
        "path": "workers/local/language_detection.py",
        "sha256": "09dcd837e828d004df6745c391654ca4f13ca3149e33c3de3b57a2d2eb7df059"
    },
    {
        "path": "vendor/siwc-local/dist/index.js",
        "sha256": "4e77b3acf1588925fba08dfe5e2853ce895de8a89f2eee3375668c355736e95b"
    },
    {
        "path": "vendor/siwc-local/dist/responses.js",
        "sha256": "9779372bb54d467e9deb3b8d3769ae824c63899b7b8725bbf75901dbf469e8c7"
    }
]);
const REVISION='SHARING_V1';
const isHash=value=>typeof value==='string' && /^[0-9a-f]{64}$/.test(value);
const safeRelative=value=>typeof value==='string' && /^[A-Za-z0-9_.-]+(?:\/[A-Za-z0-9_.-]+)*$/.test(value) && value.split('/').every(part=>part!=='.' && part!=='..');
const defaultProject=()=>path.join(process.env.USERPROFILE || os.homedir(),'Downloads/CommsTranslate-0.1.0-source/comms-translate');
const defaultLocal=()=>process.env.LOCALAPPDATA || path.join(os.homedir(),'AppData/Local');

export function validateManifest(manifest) {
    if(manifest?.revision!==REVISION || !FILES.length || !Array.isArray(manifest.files) || manifest.files.length!==FILES.length || new Set(FILES).size!==FILES.length || !FILES.every(safeRelative))fail('MANIFEST_INVALID','Unexpected Sharing V1 manifest.');
    for(const [i,file] of manifest.files.entries()) {
        if(file?.path!==FILES[i] || !safeRelative(file.path))fail('MANIFEST_INVALID','Unexpected target path in the Sharing V1 manifest.');
        if(!isHash(file.afterSha256) || !Array.isArray(file.beforeSha256) || !file.beforeSha256.every(isHash) || (!file.beforeSha256.length && file.optionalBefore!==true) || (file.optionalBefore!==undefined && typeof file.optionalBefore!=='boolean'))fail('MANIFEST_INVALID','Invalid file hashes or optional-file rule: '+file.path);
    }
    return manifest;
}
export async function assertRoots(project,bundle) {
    for(const root of [project,bundle]) {
        let current=path.resolve(root);
        while(true) { if((await fs.lstat(current)).isSymbolicLink())fail('REPARSE_POINT','The project and patch must not use symbolic links or junctions, including parent folders.'); const parent=path.dirname(current);if(parent===current)break;current=parent; }
    }
    const p=await fs.realpath(project),b=await fs.realpath(bundle);
    if(samePath(p,b) || within(p,b) || within(b,p))fail('WRONG_TARGET','Keep the extracted patch separate from the original project. Select the original comms-translate folder, not the patch or payload.');
}
export async function assertProject(project,bundle) {
    await assertRoots(project,bundle);
    try {
        for(const file of ['package.json','packages/companion/package.json','Start-CommsTranslate.cmd'])await noLinks(project,path.join(project,file));
        const p=await jsonFile(path.join(project,'package.json'),1048576),c=await jsonFile(path.join(project,'packages/companion/package.json'),1048576);
        if(p.name!=='comms-translate' || c.name!=='@comms/companion' || c.main!=='dist/main.js' || !(await readBounded(path.join(project,'Start-CommsTranslate.cmd'))).length)throw Error();
    }catch{fail('WRONG_TARGET','The original CommsTranslate project was not found. Supply its comms-translate folder path; do not run setup or the payload.');}
    for(const pin of PREREQUISITES) {
        const target=path.join(project,pin.path);await noLinks(project,target);
        if(!await exists(target) || digest(await readBounded(target,16777216))!==pin.sha256)fail('BASELINE_REQUIRED','An unchanged T4 + S1 prerequisite is missing or differs: '+pin.path+'. No application files changed; send this report.');
    }
}
export async function prepareFiles(project,bundle,manifest) {
    const result=[];
    for(const entry of manifest.files) {
        const target=path.join(project,entry.path),payload=path.join(bundle,'payload',entry.path);
        await noLinks(project,target);await noLinks(bundle,payload);
        const bytes=await readBounded(payload,16777216),before=await exists(target)?await readBounded(target,16777216):null;
        if(digest(bytes)!==entry.afterSha256)fail('PAYLOAD_INVALID','Patch integrity check failed: '+entry.path);
        if(before===null && !entry.optionalBefore)fail('REQUIRED_FILE_MISSING','Required installed file missing: '+entry.path);
        if(before!==null && ![...entry.beforeSha256,entry.afterSha256].includes(digest(before)))fail('UNKNOWN_VERSION_PRESERVED','An unrecognized or modified file was preserved: '+entry.path);
        result.push({relative:entry.path,target,before,bytes,sha256:entry.afterSha256,changed:before===null || digest(before)!==entry.afterSha256});
    }
    return result;
}
const PROCESS_CHECK=String.raw`
$ErrorActionPreference='Stop'
try {
 $root=[IO.Path]::GetFullPath($env:COMMS_SHARING_V1_PROJECT).TrimEnd([char[]]'\/')
 $prefix=$root+'\'; $application=$root+'\packages\companion'; $running=$false; $unknown=$false
 foreach($p in @(Get-CimInstance Win32_Process -Filter "Name='electron.exe' OR Name='CommsTranslate.exe'" -ErrorAction Stop)) {
  $exe=[string]$p.ExecutablePath; $cmd=[string]$p.CommandLine
  if(!$exe -and !$cmd){$unknown=$true;continue}
  if(($exe -and $exe.Replace('/','\').StartsWith($prefix,[StringComparison]::OrdinalIgnoreCase)) -or ($cmd -and $cmd.Replace('/','\').IndexOf($application,[StringComparison]::OrdinalIgnoreCase) -ge 0)){$running=$true}
 }
 @{running=$running;unknown=$unknown} | ConvertTo-Json -Compress
} catch { exit 3 }
`;
async function queryProcesses(project) {
    return new Promise((resolve,reject)=>execFile(path.join(process.env.SystemRoot || 'C:\\Windows','System32/WindowsPowerShell/v1.0/powershell.exe'),['-NoLogo','-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-Command',PROCESS_CHECK],{shell:false,windowsHide:true,timeout:15000,maxBuffer:16384,encoding:'utf8',env:{...process.env,NODE_OPTIONS:'',NODE_PATH:'',ELECTRON_RUN_AS_NODE:'',COMMS_SHARING_V1_PROJECT:project}},(error,stdout)=>{if(error)return reject(error);try{resolve(JSON.parse(stdout.trim().replace(/^\uFEFF/,'')));}catch(error){reject(error);}}));
}
export async function assertClosed(project,query=queryProcesses) {
    let state;try{state=await query(project);}catch{fail('PROCESS_CHECK_FAILED','Could not verify that CommsTranslate is closed. Close the companion and overlay, then retry. No process was stopped.');}
    if(!state || typeof state.running!=='boolean' || typeof state.unknown!=='boolean' || state.unknown)fail('PROCESS_CHECK_FAILED','Windows could not identify an Electron process. Close the companion and overlay, then retry. No process was stopped.');
    if(state.running)fail('COMPANION_RUNNING','Close CommsTranslate and its overlay, then retry. Discord can stay open. No process was stopped.');
}
export async function pendingRecovery(project,except=null) {
    for(const [folder,revision] of [['startup-r7-backups','R7'],['live-r8-backups','R8'],['caption-controls-c1-backups','C1'],['sharing-v1-backups',REVISION]]) {
        const base=path.join(project,folder);if(!await exists(base))continue;await noLinks(project,base);
        const names=await fs.readdir(base);if(names.length>1000)fail('RECOVERY_CHECK_FAILED','Too many recovery records to inspect.');
        for(const name of names){const file=path.join(base,name,'recovery.json');if(except && samePath(file,except))continue;if(!await exists(file))continue;await noLinks(project,file);const record=await jsonFile(file,16777216);if(record.revision!==revision || !['Committed','RolledBack'].includes(record.status))fail('PENDING_RECOVERY','An unfinished '+revision+' update exists. Finish its recorded recovery before applying Sharing V1.');}
    }
}
const OLD_LOCKS=['.comms-translation-t1.lock','.comms-auto-a1.lock','.comms-analysis-t2.lock','.comms-live-t3.lock','.comms-startup-s1.lock','.comms-live-t4.lock','.comms-sharing-v1.lock'];
export const lockPaths=(local,project)=>[path.join(local,'CommsTranslate/.startup-r7-update.lock'),...OLD_LOCKS.map(name=>path.join(project,name))];
async function releaseLocks(locks){for(const lock of locks || []){try{await lock.handle.close();const saved=await jsonFile(lock.file,4096);if(saved.pid===process.pid && saved.revision===REVISION && saved.recoveryPath===lock.recoveryPath)await fs.rm(lock.file);}catch{}}}
async function closeLocks(locks){for(const lock of locks || [])try{await lock.handle.close();}catch{}}
async function acquireLocks(local,project,recoveryPath) {
    const locks=[];
    try {
        for(const file of lockPaths(local,project)){
            await noLinks(within(project,file)?project:local,file);await fs.mkdir(path.dirname(file),{recursive:true});
            let handle;try{handle=await fs.open(file,'wx');}catch{fail('UPDATE_BUSY','Another CommsTranslate updater lock exists. Finish that update or recovery first. No existing lock was removed.');}
            const lock={file,handle,recoveryPath};locks.push(lock);await handle.writeFile(JSON.stringify({v:1,pid:process.pid,revision:REVISION,recoveryPath})+'\n');
        }
        return locks;
    }catch(error){await releaseLocks(locks);throw error;}
}
export async function applySharing(options={},deps={}) {
    const project=path.resolve(options.projectRoot || defaultProject()),bundle=path.resolve(options.bundleRoot || here),local=path.resolve(options.localAppData || defaultLocal());
    if((deps.platform || process.platform)!=='win32')fail('WINDOWS_REQUIRED','Run this patch on the Windows PC containing CommsTranslate.');
    let tx,locks,stage='preflight';const announce=name=>{stage=name;deps.onStage?.(name);};
    try{
        await assertProject(project,bundle);const manifest=validateManifest(await jsonFile(path.join(bundle,'manifest.json'),1048576));
        const files=await prepareFiles(project,bundle,manifest);await pendingRecovery(project);await assertClosed(project,deps.queryProcesses);
        if(!files.some(file=>file.changed))return {revision:REVISION,status:'ALREADY_APPLIED'};
        const id=deps.id?.() || new Date().toISOString().replace(/[:.]/g,'-')+'-'+randomUUID().slice(0,8);if(!/^[A-Za-z0-9_-]{1,80}$/.test(id))fail('TRANSACTION_INVALID','Invalid backup name.');
        tx=new Transaction(project,local,id);locks=await acquireLocks(local,project,tx.file);
        await assertProject(project,bundle);await pendingRecovery(project);
        announce('backup');await tx.begin();
        for(const file of files.filter(file=>file.changed))await tx.track(file.target,project,file.relative);
        for(const file of files){const current=await exists(file.target)?await readBounded(file.target,16777216):null;if(current===null?file.before!==null:file.before===null || !current.equals(file.before))fail('CONCURRENT_CHANGE','A project file changed during preflight: '+file.relative);}
        await assertClosed(project,deps.queryProcesses);announce('install');
        for(const file of files.filter(file=>file.changed))await tx.modify(file.target,()=> (deps.writer || atomicWrite)(file.target,file.bytes),{type:'file',size:file.bytes.length,sha256:file.sha256});
        announce('verification');for(const file of files)if(digest(await readBounded(file.target,16777216))!==file.sha256)fail('VERIFY_FAILED','Updated file verification failed: '+file.relative);
        tx.journal.status='Committed';await tx.save();return {revision:REVISION,status:'APPLIED_AND_VERIFIED',changedFiles:files.filter(file=>file.changed).map(file=>file.relative),backupDirectory:tx.directory,recoveryPath:tx.file};
    }catch(error){
        error.updateStage=stage;
        if(tx?.started){try{error.rollbackErrors=await tx.rollback();error.recoveryPath=tx.file;error.restored=!error.rollbackErrors.length;}catch(rollbackError){error.recoveryPath=tx.file;error.rollbackErrors=[{code:rollbackError.code || 'ROLLBACK_FAILED'}];}}
        throw error;
    }finally{if(!tx?.started || ['Committed','RolledBack'].includes(tx.journal.status))await releaseLocks(locks);else await closeLocks(locks);}
}
export async function rollbackSharing(journalPath,options={},deps={}) {
    if((deps.platform || process.platform)!=='win32')fail('WINDOWS_REQUIRED','Run recovery on the Windows PC containing CommsTranslate.');
    const file=path.resolve(journalPath),directory=path.dirname(file),record=await jsonFile(file,16777216),project=record.projectRoot,local=path.resolve(options.localAppData || defaultLocal()),bundle=path.resolve(options.bundleRoot || here);
    if(record.schema!==1 || record.revision!==REVISION || !path.isAbsolute(project || '') || !samePath(record.localAppData || '',local) || !Array.isArray(record.entries) || record.entries.length>FILES.length || path.basename(file)!=='recovery.json' || !samePath(path.dirname(directory),path.join(project,'sharing-v1-backups')))fail('RECOVERY_INVALID','Invalid Sharing V1 recovery record.');
    await assertProject(project,bundle);await noLinks(project,file);
    const manifest=validateManifest(await jsonFile(path.join(bundle,'manifest.json'),1048576)),seen=new Set();
    for(const [index,entry] of record.entries.entries()) {
        const item=manifest.files.find(item=>samePath(entry.target,path.join(project,item.path)));
        if(!item || seen.has(item.path) || !samePath(entry.root,project) || entry.directory || !samePath(entry.backup,path.join(directory,'files',String(index))) || !['file','missing'].includes(entry.before?.type))fail('RECOVERY_INVALID','Recovery contains an unexpected target or backup.');
        seen.add(item.path);
        if(entry.before.type==='missing'?!item.optionalBefore:![...item.beforeSha256,item.afterSha256].includes(entry.before.sha256))fail('RECOVERY_INVALID','Recovery contains unrecognized original bytes.');
        const expected=entry.expected;if(entry.modified && (!expected || expected.type!=='file' || expected.sha256!==item.afterSha256))fail('RECOVERY_INVALID','Recovery contains an unrecognized installed version.');
        if(entry.after && !identical(entry.after,entry.before) && !identical(entry.after,expected))fail('RECOVERY_INVALID','Recovery contains unexpected post-update bytes.');
    }
    await pendingRecovery(project,file);await assertClosed(project,deps.queryProcesses);
    if(record.status==='RolledBack')return {revision:REVISION,status:'ALREADY_ROLLED_BACK'};
    for(const lock of lockPaths(local,project))if(await exists(lock)){
        await noLinks(within(project,lock)?project:local,lock);const saved=await jsonFile(lock,4096);let alive=true;try{process.kill(saved.pid,0);}catch(error){alive=error.code!=='ESRCH';}
        if(saved.revision!==REVISION || saved.recoveryPath!==file || alive)fail('UPDATE_BUSY','A live or unrelated update lock exists. It was preserved.');
    }
    for(const lock of lockPaths(local,project))if(await exists(lock))await fs.rm(lock);
    const locks=await acquireLocks(local,project,file),tx=new Transaction(project,local,path.basename(directory));tx.journal=record;tx.directory=directory;tx.file=file;tx.started=true;
    try{await pendingRecovery(project,file);await assertClosed(project,deps.queryProcesses);const errors=await tx.rollback();return {revision:REVISION,status:errors.length?'RECOVERY_REQUIRED':'ROLLED_BACK',errors,recoveryPath:file};}
    finally{if(tx.journal.status==='RolledBack')await releaseLocks(locks);else await closeLocks(locks);}
}
export async function main(argv=process.argv.slice(2)) {
    const stamp=new Date().toISOString().replace(/[:.]/g,'-')+'-'+randomUUID().slice(0,8),report={revision:REVISION,createdUTC:new Date().toISOString()};
    console.log('CommsTranslate Shared Viewer V1 — prebuilt host patch.');console.log('Close CommsTranslate and its overlay. Discord can stay open.');
    try{
        let project,rollback;for(let i=0;i<argv.length;i++){if(argv[i]==='--rollback'){if(!argv[++i] || rollback)fail('ARGUMENT_INVALID','Use --rollback "full path to recovery.json".');rollback=argv[i];}else if(argv[i].startsWith('--') || project)fail('ARGUMENT_INVALID','Use an optional quoted project folder, or --rollback "full path to recovery.json".');else project=argv[i];}
        if(project && rollback)fail('ARGUMENT_INVALID','Select either apply or rollback.');
        Object.assign(report,rollback?await rollbackSharing(rollback):await applySharing({projectRoot:project},{onStage:name=>console.log('V1: '+name)}));
    }catch(error){Object.assign(report,{status:error.rollbackErrors?.length?'RECOVERY_REQUIRED':error.restored?'ROLLED_BACK':'UPDATE_STOPPED',code:error.code || 'UPDATE_FAILED',message:safeText(error.message),stage:error.updateStage,recoveryPath:error.recoveryPath,rollbackErrors:error.rollbackErrors});}
    const reportFile=path.join(here,'diagnostics','CommsTranslate-Sharing-V1-'+stamp+'.txt');await fs.mkdir(path.dirname(reportFile),{recursive:true});await fs.writeFile(reportFile,safeReportJson(report));
    console.log(report.status);if(report.status==='RECOVERY_REQUIRED')console.log('Automatic restoration could not finish. Keep the backup and send this report before continuing.');if(report.message)console.log(report.message);if(report.recoveryPath)console.log('Recovery record: '+report.recoveryPath);console.log('Report: '+reportFile);
    const ok=['APPLIED_AND_VERIFIED','ALREADY_APPLIED','ROLLED_BACK','ALREADY_ROLLED_BACK'].includes(report.status) && !report.code;
    if(['APPLIED_AND_VERIFIED','ALREADY_APPLIED'].includes(report.status))console.log('Start CommsTranslate using its usual launcher. Shared captions are available in the companion. No dependencies or Vencord files were changed.');
    return ok?0:1;
}
if(process.argv[1] && path.resolve(process.argv[1])===fileURLToPath(import.meta.url))main().then(code=>{process.exitCode=code;}).catch(error=>{console.error('Sharing V1 could not write its report: '+safeText(error.message));process.exitCode=1;});
