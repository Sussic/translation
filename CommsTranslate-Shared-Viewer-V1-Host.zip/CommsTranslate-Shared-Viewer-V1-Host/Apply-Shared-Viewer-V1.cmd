@echo off
setlocal EnableExtensions DisableDelayedExpansion
set "NODE_OPTIONS="
set "NODE_PATH="
set "ELECTRON_RUN_AS_NODE="
set "COMMS_V1_NODE=node"
if exist "%ProgramFiles%\nodejs\node.exe" set "COMMS_V1_NODE=%ProgramFiles%\nodejs\node.exe"
"%COMMS_V1_NODE%" "%~dp0apply-sharing-v1.mjs" %*
set "COMMS_V1_EXIT=%ERRORLEVEL%"
echo.
pause
exit /b %COMMS_V1_EXIT%
