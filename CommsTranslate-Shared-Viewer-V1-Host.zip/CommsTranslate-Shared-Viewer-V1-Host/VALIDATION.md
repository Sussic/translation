# Shared Viewer V1 — recorded validation

## Passed

- **20 installer regressions** against the actual 76-file payload and both exact T4 + S1 baselines (with and without C1). Covers complete installation, rerun, unknown edits, payload tampering, missing/optional files, linked/nested paths, running-companion guards, backup preservation, cross-updater locks, rollback and interrupted atomic restoration.
- **365 JavaScript tests** across the project: 60 vendor, 29 shared, 16 protocol, 11 relay, 201 companion and 48 plugin. The final companion rerun used the bundled runtime. Host integration includes real encrypted delivery to 20 loopback viewers; this is a functional test, not a capacity benchmark.
- Project TypeScript builds/typechecks and the final companion build passed.
- **No-install host gate:** the final sharing service imported from a fresh directory with no ancestor `node_modules`. Its configuration parser and unconfigured startup/shutdown worked with `NODE_PATH` and `NODE_OPTIONS` cleared. The new runtime dependencies are bundled; the host installer does not install them.
- **32 portable C# tests** and **6 actual C# receiver ↔ Node relay TLS integration checks** passed.
- The native **Windows x64 WPF viewer** cross-published successfully with .NET SDK **10.0.401**, runtime **10.0.12**, with no compiler warnings/errors. All self-contained runtime files are included.
- A fresh Docker-equivalent relay build context installed only the selected workspaces (7 packages), then built protocol and relay and passed their 16 + 11 tests on Node **24.19.0** / npm **11.9.0**. No prior `node_modules` or compiled `dist` was reused.

The machine-readable `validation-summary.json` records these checks and relevant hashes. Runtime .NET and ws licenses are included in their packages. `SHA256SUMS.txt` accompanies the final downloads.

## Not verified here

No access to the user's Windows PC was available. Windows process-query execution, native WPF rendering/tray/hotkeys, click-through in games, mixed-DPI recovery, and an actual Windows host/viewer session still need acceptance testing. The installer tests mock Windows process results while exercising real filesystem transactions.

The Docker image itself was not built or deployed. No public server/hostname was selected, no Internet TLS deployment was performed, and no real friend-to-host WAN session was measured. CPU, memory, sustained load, latency and long-duration soak results are not available. The design's performance figures remain targets.

Installation verification means the expected files were safely installed. It does not claim that Discord, live audio, account access, a relay deployment or remote sharing has been tested on the user's machine.
