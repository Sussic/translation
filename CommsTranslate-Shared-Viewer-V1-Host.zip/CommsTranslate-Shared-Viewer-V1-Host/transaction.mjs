// Transaction primitives adapted from the tested R8 updater.
import {promises as fs} from 'node:fs';
import path from 'node:path';
import {createHash, randomUUID} from 'node:crypto';
const REVISION = 'SHARING_V1';
export class SharingUpdateError extends Error {
    constructor(code, message, details = {}) { super(message); this.name = 'SharingUpdateError'; this.code = code; Object.assign(this, details); }
}
const fail = (code, message) => { throw new SharingUpdateError(code, message); };
const digest = bytes => createHash('sha256').update(bytes).digest('hex');
const samePath = (a, b) => path.resolve(a).toLowerCase() === path.resolve(b).toLowerCase();
const within = (root, target) => { const rel = path.relative(path.resolve(root), path.resolve(target)); return !!rel && !rel.startsWith(`..${path.sep}`) && rel !== '..' && !path.isAbsolute(rel); };
async function exists(target) { try { await fs.lstat(target); return true; } catch (error) { if (error.code === 'ENOENT') return false; throw error; } }
async function readBounded(target, max = 1048576) {
    const stat = await fs.stat(target);
    if (!stat.isFile() || stat.size > max) fail('FILE_INVALID', 'A required local file is absent, too large, or is not a file.');
    return fs.readFile(target);
}
async function jsonFile(target, max) { return JSON.parse((await readBounded(target, max)).toString('utf8').replace(/^\uFEFF/, '')); }
async function plainFile(target) { const stat = await fs.lstat(target); if (!stat.isFile() || stat.isSymbolicLink()) fail('FILE_INVALID', 'A required local file is not an ordinary file.'); }
async function noLinks(root, target) {
    if (!samePath(root, target) && !within(root, target)) fail('PATH_ESCAPE', 'An update path leaves its declared root.');
    let current = path.resolve(target);
    while (true) {
        if (await exists(current)) { const stat = await fs.lstat(current); if (stat.isSymbolicLink()) fail('REPARSE_POINT', 'Update targets must not be symbolic links or junctions.'); }
        if (samePath(root, current)) break;
        const parent = path.dirname(current); if (parent === current) fail('PATH_ESCAPE', 'An update root could not be verified.'); current = parent;
    }
}
async function inventory(target) {
    if (!await exists(target)) return { type: 'missing' };
    const stat = await fs.lstat(target);
    if (stat.isSymbolicLink()) fail('REPARSE_POINT', 'A tracked update tree contains a symbolic link or junction.');
    if (stat.isFile()) return { type: 'file', size: stat.size, sha256: digest(await fs.readFile(target)) };
    if (!stat.isDirectory()) fail('FILE_INVALID', 'A tracked update path is not an ordinary file or directory.');
    const entries = [];
    for (const name of (await fs.readdir(target)).sort()) entries.push({ name, value: await inventory(path.join(target, name)) });
    return { type: 'directory', entries };
}
const identical = (a, b) => JSON.stringify(a) === JSON.stringify(b);
async function copyTree(from, to) { await fs.mkdir(path.dirname(to), { recursive: true }); await fs.cp(from, to, { recursive: true, dereference: false, errorOnExist: true, force: false }); }
async function atomicWrite(target, bytes) {
    await fs.mkdir(path.dirname(target), { recursive: true });
    const temporary = `${target}.sharing-v1-${randomUUID()}`;
    try { await fs.writeFile(temporary, bytes, { flag: 'wx' }); await fs.rename(temporary, target); }
    finally { await fs.rm(temporary, { force: true }); }
}
function safeText(value) {
    return String(value).replace(/[A-Za-z]:[\\/]Users[\\/][^\\/\s"']+/gi, '%USERPROFILE%')
        .replace(/https?:\/\/[^\s"']+/g, value => value.replace(/\/\/[^/@]+@/, '//[redacted]@').replace(/([?&][^=&\s]+)=([^&#\s]*)/g, '$1=[redacted]'))
        .replace(/\b(token|secret|password|api[_-]?key|authorization)\s*[:=]\s*[^\s,;]+/gi, '$1=[redacted]')
        .replace(/\bsk-[A-Za-z0-9_-]+/g, '[redacted]').slice(0, 32768);
}
export function safeReportJson(value) { return JSON.stringify(value, (_key, item) => typeof item === 'string' ? safeText(item) : item, 2) + '\n'; }

class Transaction {
    constructor(root, localAppData, id) { this.root = root; this.directory = path.join(root, 'sharing-v1-backups', id); this.file = path.join(this.directory, 'recovery.json'); this.started = false; this.journal = { schema: 1, revision: REVISION, status: 'InProgress', projectRoot: root, localAppData, entries: [], stages: [], errors: [] }; }
    async save() { await atomicWrite(this.file, Buffer.from(JSON.stringify(this.journal, null, 2) + '\n')); }
    async begin() { await noLinks(this.root, this.directory); if (await exists(this.directory)) fail('TRANSACTION_EXISTS', 'This backup transaction already exists; no recovery record was overwritten.'); await fs.mkdir(path.dirname(this.directory), { recursive: true }); await fs.mkdir(this.directory); this.started = true; await this.save(); }
    async track(target, root, label, directory = false) {
        if (this.journal.entries.some(entry => samePath(entry.target, target))) return;
        await noLinks(root, target); const before = await inventory(target); const backup = path.join(this.directory, 'files', String(this.journal.entries.length));
        if (before.type !== 'missing') { await copyTree(target, backup); if (!identical(before, await inventory(backup))) fail('BACKUP_FAILED', 'An update backup failed verification.'); }
        this.journal.entries.push({ target, root, label, before, backup, directory, modified: false, after: null }); await this.save();
    }
    async modify(target, action, expected = null) {
        const entry = this.journal.entries.find(entry => samePath(entry.target, target)); if (!entry) fail('TRANSACTION_UNTRACKED', 'An update target was not backed up.');
        await noLinks(entry.root, target);
        if (!identical(await inventory(target), entry.modified ? entry.after : entry.before)) fail('CONCURRENT_CHANGE', 'A tracked path changed before the updater could replace it.');
        entry.modified = true; entry.expected = expected; await this.save();
        let actionError;
        try { await action(); } catch (error) { actionError = error; }
        if (actionError?.quiescent === false) { entry.after = null; entry.unconfirmedBuild = true; try { await this.save(); } catch { actionError.recoveryRecordFailed = true; } throw actionError; }
        try {
            const observed = await inventory(target);
            if (expected && !identical(observed, expected) && !identical(observed, entry.before)) {
                entry.after = expected; await this.save();
                fail('CONCURRENT_CHANGE', 'An updated file changed outside the expected atomic write; its current bytes were preserved.');
            }
            entry.after = observed; await this.save();
        }
        catch (recordError) { if (!actionError) throw recordError; actionError.recoveryRecordFailed = true; }
        if (actionError) throw actionError;
    }
    async stage(name, status, details) { this.journal.stages.push({ name, status, ...(details ? { details } : {}) }); await this.save(); }
    async rollback() {
        this.journal.status = 'RollingBack'; await this.save(); const errors = [];
        for (const entry of [...this.journal.entries].reverse()) {
            if (!entry.modified) continue;
            try {
                await noLinks(entry.root, entry.target);
                const current = await inventory(entry.target);
                if (identical(entry.before, current)) { entry.restored = true; await this.save(); continue; }
                if (entry.after ? !identical(entry.after, current) : (!identical(entry.before, current) && (!entry.expected || !identical(entry.expected, current)))) fail('ROLLBACK_CONFLICT', 'A tracked path changed after the updater wrote it, or an interrupted write cannot be identified; automatic restoration was skipped.');
                if (!['file', 'missing'].includes(entry.before.type)) fail('RECOVERY_INVALID', 'Sharing V1 only restores individual files.');
                if (entry.before.type === 'file') {
                    await noLinks(this.root, entry.backup);
                    const backupBytes = await readBounded(entry.backup, 16777216);
                    if (backupBytes.length !== entry.before.size || digest(backupBytes) !== entry.before.sha256) fail('BACKUP_INVALID', 'A rollback backup no longer matches its recorded hash.');
                    // Keep the current owned file intact until replacement is ready.
                    // A failed/interrupted restore can then be retried without a missing-file gap.
                    await atomicWrite(entry.target, backupBytes);
                } else await fs.rm(entry.target, { force: true });
                if (!identical(entry.before, await inventory(entry.target))) fail('ROLLBACK_VERIFY_FAILED', 'Restored files did not match their original inventory.');
                entry.restored = true; await this.save();
            } catch (error) { errors.push({ label: entry.label, code: error.code || 'ROLLBACK_FAILED' }); }
        }
        this.journal.errors.push(...errors); this.journal.status = errors.length ? 'RollbackIncomplete' : 'RolledBack'; await this.save(); return errors;
    }
}


export {fail,digest,samePath,within,exists,readBounded,jsonFile,plainFile,noLinks,inventory,identical,copyTree,atomicWrite,safeText,Transaction};
