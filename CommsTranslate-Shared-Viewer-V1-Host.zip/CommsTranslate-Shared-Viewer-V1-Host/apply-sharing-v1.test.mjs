import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import {fileURLToPath} from 'node:url';
import {applySharing,rollbackSharing,validateManifest,assertClosed,assertRoots,FILES,PREREQUISITES,lockPaths} from './apply-sharing-v1.mjs';
import {atomicWrite,digest} from './transaction.mjs';
const here=path.dirname(fileURLToPath(import.meta.url));
const closed=async()=>({running:false,unknown:false});
async function fixture(t,baseline='baseline') {
    const root=await fs.mkdtemp(path.join(os.tmpdir(),'comms-sharing-v1-'));t.after(()=>fs.rm(root,{recursive:true,force:true}));
    const project=path.join(root,'project'),bundle=path.join(root,'bundle'),local=path.join(root,'local');
    await fs.cp(path.join(here,'tests',baseline),project,{recursive:true});await fs.mkdir(bundle);await fs.mkdir(local);
    await fs.cp(path.join(here,'payload'),path.join(bundle,'payload'),{recursive:true});await fs.copyFile(path.join(here,'manifest.json'),path.join(bundle,'manifest.json'));
    const manifest=JSON.parse(await fs.readFile(path.join(bundle,'manifest.json'),'utf8'));
    const options={projectRoot:project,bundleRoot:bundle,localAppData:local},deps={platform:'win32',queryProcesses:closed,id:()=> 'test-transaction'};
    return {root,project,bundle,local,manifest,options,deps};
}
async function originals(f){for(const file of f.manifest.files){const expected=await fs.readFile(path.join(here,'tests/baseline',file.path)).catch(error=>error.code==='ENOENT'?null:Promise.reject(error));const actual=await fs.readFile(path.join(f.project,file.path)).catch(error=>error.code==='ENOENT'?null:Promise.reject(error));assert.deepEqual(actual,expected,file.path);}}
async function noBackup(f){await assert.rejects(fs.access(path.join(f.project,'sharing-v1-backups')));}
async function allLocksGone(f){for(const file of lockPaths(f.local,f.project))await assert.rejects(fs.access(file));}

test('actual T4 + S1 baseline installs complete payload, preserves private files, and is idempotent',async t=>{
 const f=await fixture(t);await fs.writeFile(path.join(f.project,'private-settings.json'),'private settings unchanged');
 await fs.mkdir(path.join(f.project,'node_modules/electron/dist'),{recursive:true});await fs.writeFile(path.join(f.project,'node_modules/electron/dist/electron.exe'),'runtime unchanged');
 const result=await applySharing(f.options,f.deps);assert.equal(result.status,'APPLIED_AND_VERIFIED');
 for(const file of f.manifest.files)assert.equal(digest(await fs.readFile(path.join(f.project,file.path))),file.afterSha256,file.path);
 assert.equal(await fs.readFile(path.join(f.project,'private-settings.json'),'utf8'),'private settings unchanged');assert.equal(await fs.readFile(path.join(f.project,'node_modules/electron/dist/electron.exe'),'utf8'),'runtime unchanged');
 assert.equal((await applySharing(f.options,f.deps)).status,'ALREADY_APPLIED');await allLocksGone(f);
});
test('T4 + S1 without C1 launchers is accepted and its launcher remains untouched',async t=>{
 const f=await fixture(t,'baseline-no-c1');const cmd=await fs.readFile(path.join(f.project,'Start-CommsTranslate.cmd'),'utf8');
 await fs.rm(path.join(f.project,'Start-CommsTranslate-Debug.cmd'),{force:true});
 assert.equal((await applySharing(f.options,f.deps)).status,'APPLIED_AND_VERIFIED');assert.equal(await fs.readFile(path.join(f.project,'Start-CommsTranslate.cmd'),'utf8'),cmd);
});
test('last target unknown modification blocks all writes and backup creation',async t=>{
 const f=await fixture(t),last=f.manifest.files.at(-1).path;await fs.mkdir(path.dirname(path.join(f.project,last)),{recursive:true});await fs.writeFile(path.join(f.project,last),'user edit');
 await assert.rejects(applySharing(f.options,f.deps),{code:'UNKNOWN_VERSION_PRESERVED'});assert.equal(await fs.readFile(path.join(f.project,last),'utf8'),'user edit');await noBackup(f);await allLocksGone(f);
});
test('late payload corruption blocks all writes including optional parents',async t=>{
 const f=await fixture(t);await fs.appendFile(path.join(f.bundle,'payload',FILES.at(-1)),'tampered');await assert.rejects(applySharing(f.options,f.deps),{code:'PAYLOAD_INVALID'});await originals(f);await noBackup(f);
});
test('missing required installed runtime blocks update; absent optional generated files are restored',async t=>{
 const f=await fixture(t),required=f.manifest.files.find(x=>!x.optionalBefore);assert.ok(required);await fs.rm(path.join(f.project,required.path));await assert.rejects(applySharing(f.options,f.deps),{code:'REQUIRED_FILE_MISSING'});await noBackup(f);
 const g=await fixture(t);for(const file of g.manifest.files.filter(x=>x.optionalBefore))await fs.rm(path.join(g.project,file.path),{force:true});assert.equal((await applySharing(g.options,g.deps)).status,'APPLIED_AND_VERIFIED');
});
test('unknown new-file collision is preserved',async t=>{
 const f=await fixture(t),fresh=f.manifest.files.find(x=>!x.beforeSha256.length);assert.ok(fresh);await fs.mkdir(path.dirname(path.join(f.project,fresh.path)),{recursive:true});await fs.writeFile(path.join(f.project,fresh.path),'existing unrelated file');await assert.rejects(applySharing(f.options,f.deps),{code:'UNKNOWN_VERSION_PRESERVED'});await noBackup(f);
});
test('post-write failure rolls back every attempted file and releases locks',async t=>{
 const f=await fixture(t);let n=0;await assert.rejects(applySharing(f.options,{...f.deps,writer:async(file,bytes)=>{await atomicWrite(file,bytes);if(++n===2)throw Error('simulated write failure');}}),/simulated/);await originals(f);await allLocksGone(f);
 const journal=JSON.parse(await fs.readFile(path.join(f.project,'sharing-v1-backups/test-transaction/recovery.json')));assert.equal(journal.status,'RolledBack');
});
test('unexpected concurrent bytes survive rollback and locks are retained',async t=>{
 const f=await fixture(t);let changed;await assert.rejects(applySharing(f.options,{...f.deps,writer:async(file,bytes)=>{await atomicWrite(file,bytes);changed=file;await fs.writeFile(file,'external edit during update');}}),{code:'CONCURRENT_CHANGE'});assert.equal(await fs.readFile(changed,'utf8'),'external edit during update');for(const file of lockPaths(f.local,f.project))await fs.access(file);
});
test('successful update can be explicitly rolled back with exact original bytes',async t=>{
 const f=await fixture(t),r=await applySharing(f.options,f.deps);assert.equal((await rollbackSharing(r.recoveryPath,f.options,f.deps)).status,'ROLLED_BACK');await originals(f);await allLocksGone(f);assert.equal((await rollbackSharing(r.recoveryPath,f.options,f.deps)).status,'ALREADY_ROLLED_BACK');
});
test('rollback preserves later user edits',async t=>{
 const f=await fixture(t),r=await applySharing(f.options,f.deps);const file=FILES[0];await fs.writeFile(path.join(f.project,file),'later user edit');const result=await rollbackSharing(r.recoveryPath,f.options,f.deps);assert.equal(result.status,'RECOVERY_REQUIRED');assert.equal(await fs.readFile(path.join(f.project,file),'utf8'),'later user edit');
});
test('manifest traversal, unexpected paths and unguarded hashes are rejected',async t=>{
 const f=await fixture(t);for(const bad of ['../outside','C:/outside','/absolute','packages/../outside']){const m=structuredClone(f.manifest);m.files[0].path=bad;assert.throws(()=>validateManifest(m),{code:'MANIFEST_INVALID'});}
 const m=structuredClone(f.manifest);m.files[0].afterSha256='bad';assert.throws(()=>validateManifest(m),{code:'MANIFEST_INVALID'});
});
test('nested roots and symlink ancestor aliases are refused',async t=>{
 const f=await fixture(t);await assert.rejects(assertRoots(f.project,f.project),{code:'WRONG_TARGET'});await assert.rejects(assertRoots(f.project,path.join(f.project,'packages')),{code:'WRONG_TARGET'});
 const alias=path.join(f.root,'alias');await fs.symlink(f.project,alias,'dir');await assert.rejects(assertRoots(path.join(alias,'packages'),f.bundle),{code:'REPARSE_POINT'});
});
test('running or unidentifiable Electron stops before writes; Discord does not block',async t=>{
 const f=await fixture(t);await assert.rejects(applySharing(f.options,{...f.deps,queryProcesses:async()=>({running:true,unknown:false})}),{code:'COMPANION_RUNNING'});await noBackup(f);
 await assert.rejects(assertClosed(f.project,async()=>({running:false,unknown:true})),{code:'PROCESS_CHECK_FAILED'});await assertClosed(f.project,async()=>({running:false,unknown:false,discord:true}));
});
test('another updater lock is preserved without source changes',async t=>{
 const f=await fixture(t),lock=lockPaths(f.local,f.project)[0];await fs.mkdir(path.dirname(lock),{recursive:true});await fs.writeFile(lock,'another updater');await assert.rejects(applySharing(f.options,f.deps),{code:'UPDATE_BUSY'});assert.equal(await fs.readFile(lock,'utf8'),'another updater');await originals(f);await noBackup(f);
});
test('unfinished C1 journal blocks sharing update',async t=>{
 const f=await fixture(t),journal=path.join(f.project,'caption-controls-c1-backups/old/recovery.json');await fs.mkdir(path.dirname(journal),{recursive:true});await fs.writeFile(journal,JSON.stringify({revision:'C1',status:'RollbackIncomplete'}));await assert.rejects(applySharing(f.options,f.deps),{code:'PENDING_RECOVERY'});await noBackup(f);
});
test('unchanged prerequisites are rechecked after shared locks acquired',async t=>{
 const f=await fixture(t);let calls=0;await assert.rejects(applySharing(f.options,{...f.deps,queryProcesses:async()=>{if(++calls===1)await fs.appendFile(path.join(f.project,PREREQUISITES[0].path),'changed meanwhile');return {running:false,unknown:false};}}),{code:'BASELINE_REQUIRED'});await noBackup(f);await allLocksGone(f);
});
test('forged recovery outside fixed targets is rejected',async t=>{
 const f=await fixture(t),r=await applySharing(f.options,f.deps),j=JSON.parse(await fs.readFile(r.recoveryPath));j.entries[0].target=path.join(f.root,'outside');await fs.writeFile(r.recoveryPath,JSON.stringify(j));await assert.rejects(rollbackSharing(r.recoveryPath,f.options,f.deps),{code:'RECOVERY_INVALID'});
});
test('interrupted known transaction can recover after its updater exited',async t=>{
 const f=await fixture(t),r=await applySharing(f.options,f.deps),record=JSON.parse(await fs.readFile(r.recoveryPath));record.status='InProgress';await fs.writeFile(r.recoveryPath,JSON.stringify(record));
 for(const lock of lockPaths(f.local,f.project)){await fs.mkdir(path.dirname(lock),{recursive:true});await fs.writeFile(lock,JSON.stringify({v:1,pid:2147483647,revision:'SHARING_V1',recoveryPath:r.recoveryPath}));}
 assert.equal((await rollbackSharing(r.recoveryPath,f.options,f.deps)).status,'ROLLED_BACK');await originals(f);await allLocksGone(f);
});
test('existing backup directory is preserved without writing target files',async t=>{
 const f=await fixture(t),backup=path.join(f.project,'sharing-v1-backups/test-transaction');await fs.mkdir(backup,{recursive:true});await fs.writeFile(path.join(backup,'keep.txt'),'prior backup');await assert.rejects(applySharing(f.options,f.deps),{code:'TRANSACTION_EXISTS'});assert.equal(await fs.readFile(path.join(backup,'keep.txt'),'utf8'),'prior backup');await originals(f);await allLocksGone(f);
});
test('failed atomic restore leaves installed bytes intact and recovery can retry after exit',async t=>{
 const f=await fixture(t),r=await applySharing(f.options,f.deps),existing=f.manifest.files.find(file=>file.beforeSha256.length && !file.optionalBefore),target=path.join(f.project,existing.path);
 const rename=fs.rename;let interrupted=false;
 fs.rename=async(from,to)=>{if(to===target && from.startsWith(target+'.sharing-v1-')){interrupted=true;const error=new Error('simulated restore interruption');error.code='EACCES';throw error;}return rename(from,to);};
 try{assert.equal((await rollbackSharing(r.recoveryPath,f.options,f.deps)).status,'RECOVERY_REQUIRED');}finally{fs.rename=rename;}
 assert.equal(interrupted,true);assert.equal(digest(await fs.readFile(target)),existing.afterSha256,'original installed file must remain until atomic replacement succeeds');
 for(const lock of lockPaths(f.local,f.project)){const saved=JSON.parse(await fs.readFile(lock));saved.pid=2147483647;await fs.writeFile(lock,JSON.stringify(saved));}
 assert.equal((await rollbackSharing(r.recoveryPath,f.options,f.deps)).status,'ROLLED_BACK');await originals(f);await allLocksGone(f);
});
